import { useQuery } from "@tanstack/react-query";

import { apiGet } from "@/lib/api";
import type { AuthMe } from "@/lib/types";

// GET /api/auth/me answers "who am I" — the httpOnly cookie rides along automatically.
export function useMe() {
  return useQuery({
    queryKey: ["auth", "me"],
    queryFn: () => apiGet<AuthMe>("/auth/me"),
    staleTime: 5 * 60 * 1000,
    retry: false,
  });
}
