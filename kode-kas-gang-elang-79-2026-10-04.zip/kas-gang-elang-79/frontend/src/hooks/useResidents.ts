import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { ApiError, apiDelete, apiGet, apiPost, apiPut } from "@/lib/api";
import type {
  ImportResult,
  KasSettings,
  OkResult,
  Resident,
  ResidentCreate,
} from "@/lib/types";

export function useResidents() {
  return useQuery({
    queryKey: ["residents"],
    queryFn: () => apiGet<Resident[]>("/residents"),
  });
}

export function useKasSettings() {
  return useQuery({
    queryKey: ["kas-settings"],
    queryFn: () => apiGet<KasSettings>("/auth/settings"),
    staleTime: 60_000,
  });
}

export function useResidentMutations() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["residents"] });

  const tambah = useMutation<Resident, ApiError, ResidentCreate>({
    mutationFn: (body) => apiPost<Resident>("/residents", body),
    onSuccess: invalidate,
  });

  const ubah = useMutation<Resident, ApiError, { id: string; body: ResidentCreate }>({
    mutationFn: ({ id, body }) => apiPut<Resident>(`/residents/${id}`, body),
    onSuccess: invalidate,
  });

  const hapus = useMutation<OkResult, ApiError, string>({
    mutationFn: (id) => apiDelete<OkResult>(`/residents/${id}`),
    onSuccess: invalidate,
  });

  const impor = useMutation<ImportResult, ApiError, void>({
    mutationFn: () => apiPost<ImportResult>("/residents/import"),
    onSuccess: invalidate,
  });

  return { tambah, ubah, hapus, impor };
}

export function useSaveKasSettings() {
  const qc = useQueryClient();
  return useMutation<KasSettings, ApiError, KasSettings>({
    mutationFn: (body) => apiPut<KasSettings>("/auth/settings", body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["kas-settings"] }),
  });
}
