import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { ApiError, apiGet, apiPost } from "@/lib/api";
import type { AuditEntry, Reminder, ReminderState } from "@/lib/types";

// Pengingat iuran yang disiapkan otomatis penjadwal (tanggal 10 tiap bulan).
export function useReminder() {
  return useQuery({
    queryKey: ["reminder", "current"],
    queryFn: () => apiGet<ReminderState>("/reminders/current"),
    staleTime: 60_000,
  });
}

export function useReminderActions() {
  const qc = useQueryClient();
  const invalidate = () => qc.invalidateQueries({ queryKey: ["reminder", "current"] });

  const tandaiTerkirim = useMutation<Reminder, ApiError, string>({
    mutationFn: (month) => apiPost<Reminder>(`/reminders/${month}/sent`),
    onSuccess: invalidate,
  });

  const siapkan = useMutation<Reminder, ApiError, void>({
    mutationFn: () => apiPost<Reminder>("/reminders/siapkan"),
    onSuccess: invalidate,
  });

  return { tandaiTerkirim, siapkan };
}

export function useAudit(limit = 100) {
  return useQuery({
    queryKey: ["audit", limit],
    queryFn: () => apiGet<AuditEntry[]>(`/audit?limit=${limit}`),
  });
}
