import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";

import { ApiError, apiGet, apiPut } from "@/lib/api";
import type { MeetingNote } from "@/lib/types";

// Catatan rapat warga disimpan per tahun laporan.
export function useMeetingNote(year: string) {
  return useQuery({
    queryKey: ["notes", year],
    queryFn: () => apiGet<MeetingNote>(`/notes/${year}`),
    enabled: Boolean(year),
  });
}

export function useSaveMeetingNote(year: string) {
  const qc = useQueryClient();
  return useMutation<MeetingNote, ApiError, string>({
    mutationFn: (text) => apiPut<MeetingNote>(`/notes/${year}`, { text }),
    onSuccess: (note) => {
      qc.setQueryData(["notes", year], note);
    },
  });
}
