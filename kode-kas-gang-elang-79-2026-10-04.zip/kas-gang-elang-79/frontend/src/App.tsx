import { Navigate, Route, Routes } from "react-router-dom";
import type { ReactNode } from "react";
import { Loader2 } from "lucide-react";

import { Toaster } from "@/components/ui/sonner";
import { useMe } from "@/hooks/useAuth";
import Catat from "@/pages/Catat";
import Home from "@/pages/Home";
import Laporan from "@/pages/Laporan";
import Login from "@/pages/Login";
import Pengaturan from "@/pages/Pengaturan";
import Rekap from "@/pages/Rekap";
import Riwayat from "@/pages/Riwayat";
import Warga from "@/pages/Warga";

function Splash() {
  return (
    <div className="flex min-h-svh flex-col items-center justify-center gap-3 bg-background text-muted-foreground">
      <Loader2 className="h-6 w-6 animate-spin text-emerald-600" aria-hidden />
      <p className="text-sm">Memuat buku kas...</p>
    </div>
  );
}

// Semua halaman aplikasi di balik sandi bendahara; /masuk tetap terjangkau.
function Protected({ children }: { children: ReactNode }) {
  const { data, isPending } = useMe();
  if (isPending) return <Splash />;
  if (!data?.authenticated) return <Navigate to="/masuk" replace />;
  return <>{children}</>;
}

// One <Route> per page in src/pages; BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <>
      <Routes>
        <Route path="/masuk" element={<Login />} />
        <Route
          path="/"
          element={
            <Protected>
              <Home />
            </Protected>
          }
        />
        <Route
          path="/catat"
          element={
            <Protected>
              <Catat />
            </Protected>
          }
        />
        <Route
          path="/rekap"
          element={
            <Protected>
              <Rekap />
            </Protected>
          }
        />
        <Route
          path="/warga"
          element={
            <Protected>
              <Warga />
            </Protected>
          }
        />
        <Route
          path="/laporan"
          element={
            <Protected>
              <Laporan />
            </Protected>
          }
        />
        <Route
          path="/riwayat"
          element={
            <Protected>
              <Riwayat />
            </Protected>
          }
        />
        <Route
          path="/pengaturan"
          element={
            <Protected>
              <Pengaturan />
            </Protected>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster position="top-center" toastOptions={{ duration: 3000 }} />
    </>
  );
}
