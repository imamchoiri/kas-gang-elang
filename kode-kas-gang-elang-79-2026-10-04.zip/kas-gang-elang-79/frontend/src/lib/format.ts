// Indonesian formatting helpers — Rupiah amounts and dates (no client-side date math).

import { BULAN_ID } from "@/lib/types";

const angkaFormatter = new Intl.NumberFormat("id-ID", { maximumFractionDigits: 0 });

export const angka = (n: number): string => angkaFormatter.format(n);

export const rupiah = (n: number): string => `Rp ${angkaFormatter.format(n)}`;

export const tanggalIndo = (iso: string): string => {
  const [y, m, d] = iso.split("-");
  if (!y || !m || !d) return iso;
  return `${Number(d)} ${BULAN_ID[Number(m) - 1]} ${y}`;
};

// Versi ringkas untuk sumbu grafik: 1500000 -> "1,5 jt", 25000 -> "25 rb".
export const rupiahPendek = (n: number): string => {
  if (Math.abs(n) >= 1_000_000) {
    return `${(n / 1_000_000).toLocaleString("id-ID", { maximumFractionDigits: 1 })} jt`;
  }
  if (Math.abs(n) >= 1_000) return `${Math.round(n / 1_000)} rb`;
  return String(n);
};
