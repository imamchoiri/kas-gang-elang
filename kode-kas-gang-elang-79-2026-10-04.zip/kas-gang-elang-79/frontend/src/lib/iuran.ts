// Perhitungan iuran per warga: riwayat bulanan, tunggakan berjalan, dan total setoran.
// Dipakai halaman Iuran Warga, dialog riwayat, dan kartu iuran — satu sumber kebenaran.

import { BULAN_ID, BULAN_SINGKAT, type Transaction } from "@/lib/types";

export interface BulanStatus {
  key: string; // YYYY-MM
  label: string; // "Oktober 2026"
  labelPendek: string; // "Okt"
  dibayar: number;
  kurang: number;
  lunas: boolean;
}

export interface RingkasanWarga {
  perBulan: BulanStatus[]; // bulan mulai → bulan terpilih (dasar tunggakan)
  tahunIni: BulanStatus[]; // 12 bulan pada tahun bulan terpilih (untuk kartu)
  setoran: Transaction[]; // seluruh setoran warga ini, terbaru dulu
  dibayarBulanIni: number;
  tunggakan: number; // akumulasi kekurangan s/d bulan terpilih
  totalSetor: number; // sepanjang masa
  bulanLunas: number; // jumlah bulan lunas dalam rentang tunggakan
}

const labelBulan = (key: string): string => {
  const [y, m] = key.split("-");
  return `${BULAN_ID[Number(m) - 1]} ${y}`;
};

const labelPendek = (key: string): string => BULAN_SINGKAT[Number(key.split("-")[1]) - 1];

/** Daftar key bulan dari `start` sampai `end` (inklusif). */
export function rentangBulan(start: string, end: string): string[] {
  if (start > end) return [];
  const keys: string[] = [];
  let [y, m] = start.split("-").map(Number);
  const [ey, em] = end.split("-").map(Number);
  while (y < ey || (y === ey && m <= em)) {
    keys.push(`${y}-${String(m).padStart(2, "0")}`);
    m += 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
  }
  return keys;
}

const statusBulan = (key: string, dibayar: number, target: number): BulanStatus => ({
  key,
  label: labelBulan(key),
  labelPendek: labelPendek(key),
  dibayar,
  kurang: target > 0 ? Math.max(0, target - dibayar) : 0,
  lunas: target > 0 ? dibayar >= target : dibayar > 0,
});

/**
 * Hitung ringkasan iuran satu warga.
 * Tunggakan dihitung dari bulan paling awal antara pendaftaran warga dan setoran
 * pertamanya, sampai bulan yang dipilih bendahara.
 */
export function hitungWarga(
  nama: string,
  target: number,
  terdaftarSejak: string | undefined, // ISO datetime warga terdaftar
  transactions: Transaction[],
  bulanTerpilih: string, // YYYY-MM
): RingkasanWarga {
  const kunci = nama.trim().toLowerCase();
  const setoran = transactions
    .filter((t) => t.type === "masuk" && (t.warga || "").trim().toLowerCase() === kunci)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0));

  const perBulanMap = new Map<string, number>();
  setoran.forEach((t) => {
    const k = t.date.slice(0, 7);
    perBulanMap.set(k, (perBulanMap.get(k) ?? 0) + t.amount);
  });

  const bulanDaftar = terdaftarSejak ? terdaftarSejak.slice(0, 7) : "";
  const bulanSetorPertama = setoran.length > 0 ? setoran[setoran.length - 1].date.slice(0, 7) : "";
  const kandidat = [bulanDaftar, bulanSetorPertama].filter(Boolean).sort();
  const mulai = kandidat.length > 0 ? kandidat[0] : bulanTerpilih;

  const perBulan = rentangBulan(mulai > bulanTerpilih ? bulanTerpilih : mulai, bulanTerpilih).map((k) =>
    statusBulan(k, perBulanMap.get(k) ?? 0, target),
  );

  const tahun = bulanTerpilih.slice(0, 4);
  const tahunIni = Array.from({ length: 12 }, (_, i) => {
    const k = `${tahun}-${String(i + 1).padStart(2, "0")}`;
    return statusBulan(k, perBulanMap.get(k) ?? 0, target);
  });

  return {
    perBulan,
    tahunIni,
    setoran,
    dibayarBulanIni: perBulanMap.get(bulanTerpilih) ?? 0,
    tunggakan: perBulan.reduce((s, b) => s + b.kurang, 0),
    totalSetor: setoran.reduce((s, t) => s + t.amount, 0),
    bulanLunas: perBulan.filter((b) => b.lunas).length,
  };
}
