// Kwitansi digital: gambar 1080x1350 dirender di canvas klien — siap dibagikan ke WhatsApp.
// Selalu bergaya terang (tampilan struk), tidak mengikuti mode gelap.

import { rupiah, tanggalIndo } from "@/lib/format";
import type { Transaction } from "@/lib/types";

const W = 1080;
const H = 1350;
const SANS = '"Plus Jakarta Sans Variable", sans-serif';
const MONO = '"IBM Plex Mono", monospace';

async function loadBitmap(src: string): Promise<ImageBitmap | null> {
  try {
    const res = await fetch(src);
    if (!res.ok) return null;
    return await createImageBitmap(await res.blob());
  } catch {
    return null;
  }
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number | number[],
) {
  const radii = Array.isArray(r) ? r : [r, r, r, r];
  const [tl, tr, br, bl] = radii;
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") {
    ctx.roundRect(x, y, w, h, radii);
    return;
  }
  ctx.moveTo(x + tl, y);
  ctx.lineTo(x + w - tr, y);
  ctx.arcTo(x + w, y, x + w, y + tr, tr);
  ctx.lineTo(x + w, y + h - br);
  ctx.arcTo(x + w, y + h, x + w - br, y + h, br);
  ctx.lineTo(x + bl, y + h);
  ctx.arcTo(x, y + h, x, y + h - bl, bl);
  ctx.lineTo(x, y + tl);
  ctx.arcTo(x, y, x + tl, y, tl);
  ctx.closePath();
}

function wrapText(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxLines: number,
): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (ctx.measureText(next).width <= maxWidth || !line) {
      line = next;
      continue;
    }
    lines.push(line);
    line = word;
  }
  if (line) lines.push(line);
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines);
    kept[maxLines - 1] = `${kept[maxLines - 1].replace(/[.…]$/, "")}…`;
    return kept;
  }
  return lines;
}

export async function renderKwitansi(tx: Transaction, saldoSaatIni: number): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Kanvas tidak tersedia");

  try {
    await Promise.all([
      document.fonts.load(`800 44px ${SANS}`),
      document.fonts.load(`600 28px ${SANS}`),
      document.fonts.load(`700 62px ${MONO}`),
    ]);
  } catch {
    // font fallback tetap terbaca
  }

  // Latar mint lembut + kartu putih
  ctx.fillStyle = "#ECFDF5";
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.shadowColor = "rgba(6, 78, 59, 0.20)";
  ctx.shadowBlur = 36;
  ctx.shadowOffsetY = 14;
  ctx.fillStyle = "#FFFFFF";
  roundedRect(ctx, 40, 40, W - 80, H - 80, 48);
  ctx.fill();
  ctx.restore();

  // Pita header zamrud
  ctx.save();
  roundedRect(ctx, 40, 40, W - 80, 240, [48, 48, 0, 0]);
  ctx.clip();
  const grad = ctx.createLinearGradient(40, 40, W - 40, 280);
  grad.addColorStop(0, "#065F46");
  grad.addColorStop(1, "#022C22");
  ctx.fillStyle = grad;
  ctx.fillRect(40, 40, W - 80, 240);
  ctx.restore();

  // Lambang gang (dipotong melingkar)
  const crest = await loadBitmap("/elang-crest.jpg");
  ctx.save();
  ctx.beginPath();
  ctx.arc(150, 160, 62, 0, Math.PI * 2);
  ctx.clip();
  if (crest) {
    ctx.drawImage(crest, 88, 98, 124, 124);
  } else {
    ctx.fillStyle = "#10B981";
    ctx.fillRect(88, 98, 124, 124);
  }
  ctx.restore();

  ctx.textBaseline = "alphabetic";
  ctx.font = `800 44px ${SANS}`;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillText("Kas Gang Elang 79", 240, 148);
  ctx.font = `600 28px ${SANS}`;
  ctx.fillStyle = "#A7F3D0";
  ctx.fillText("Kwitansi Kas Warga", 240, 194);

  let cursorY = 350;
  const step = tx.warga.trim() ? 105 : 120;

  // Foto bukti (kanan, di bawah header)
  const photo = tx.photo_id ? await loadBitmap(`/api/photos/${tx.photo_id}`) : null;
  if (photo) {
    const boxW = 300;
    const boxH = 220;
    const scale = Math.min(boxW / photo.width, boxH / photo.height);
    const dw = photo.width * scale;
    const dh = photo.height * scale;
    const bx = W - 140 - boxW;
    const by = cursorY - 40;
    ctx.save();
    roundedRect(ctx, bx, by, boxW, boxH, 24);
    ctx.fillStyle = "#F1F5F9";
    ctx.fill();
    ctx.clip();
    ctx.drawImage(photo, bx + (boxW - dw) / 2, by + (boxH - dh) / 2, dw, dh);
    ctx.restore();
    ctx.font = `600 22px ${SANS}`;
    ctx.fillStyle = "#64748B";
    ctx.fillText("Foto Bukti", bx, by + boxH + 30);
  }

  const left = 100;
  const label = (t: string) => {
    ctx.font = `600 24px ${SANS}`;
    ctx.fillStyle = "#94A3B8";
    ctx.fillText(t.toUpperCase(), left, cursorY);
  };
  const value = (t: string, color = "#0F172A") => {
    ctx.font = `600 36px ${SANS}`;
    ctx.fillStyle = color;
    ctx.fillText(t, left, cursorY + 46);
  };

  label("Tanggal");
  value(tanggalIndo(tx.date));
  cursorY += step;

  label("Jenis");
  value(tx.type === "masuk" ? "Pemasukan" : "Pengeluaran", tx.type === "masuk" ? "#047857" : "#B91C1C");
  cursorY += step;

  label("Kategori");
  value(tx.category || "-");
  cursorY += step;

  if (tx.warga.trim()) {
    label("Nama Warga");
    value(tx.warga.trim());
    cursorY += step;
  }

  label("Keterangan");
  ctx.font = `500 32px ${SANS}`;
  ctx.fillStyle = "#334155";
  const descLines = wrapText(ctx, tx.description || "Tanpa keterangan", photo ? 460 : W - 240, 2);
  descLines.forEach((l, i) => ctx.fillText(l, left, cursorY + 44 + i * 42));
  cursorY += 80 + (descLines.length - 1) * 42;

  // Panel jumlah
  cursorY += 40;
  ctx.save();
  roundedRect(ctx, 60, cursorY - 60, W - 120, 170, 32);
  ctx.fillStyle = tx.type === "masuk" ? "#ECFDF5" : "#FEF2F2";
  ctx.fill();
  ctx.strokeStyle = tx.type === "masuk" ? "#A7F3D0" : "#FECACA";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();

  ctx.font = `700 24px ${SANS}`;
  ctx.fillStyle = tx.type === "masuk" ? "#047857" : "#B91C1C";
  ctx.fillText(tx.type === "masuk" ? "JUMLAH DITERIMA" : "JUMLAH DIKELUARKAN", left, cursorY - 5);
  ctx.font = `700 62px ${MONO}`;
  ctx.fillStyle = tx.type === "masuk" ? "#047857" : "#B91C1C";
  ctx.fillText(`${tx.type === "masuk" ? "+" : "−"}${rupiah(tx.amount)}`, left, cursorY + 70);

  cursorY += 230;

  // Kaki kwitansi
  ctx.strokeStyle = "#E2E8F0";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(100, cursorY);
  ctx.lineTo(W - 100, cursorY);
  ctx.stroke();

  ctx.font = `600 28px ${SANS}`;
  ctx.fillStyle = "#475569";
  ctx.fillText("Saldo Kas Saat Ini", left, cursorY + 50);
  ctx.font = `700 34px ${MONO}`;
  ctx.fillStyle = "#047857";
  ctx.textAlign = "right";
  ctx.fillText(rupiah(saldoSaatIni), W - 100, cursorY + 50);
  ctx.textAlign = "left";

  ctx.font = `500 24px ${SANS}`;
  ctx.fillStyle = "#94A3B8";
  ctx.fillText("Dibuat otomatis — Kas Gang Elang 79", left, cursorY + 105);
  ctx.fillText(
    `Dicetak: ${new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })}`,
    left,
    cursorY + 143,
  );

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Gagal membuat gambar kwitansi"))), "image/png");
  });
}
