// Session boundaries own the react-query cache: wipe it so one login's data never
// renders for the next login on this device.
import { apiPost } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";
import type { OkResult } from "@/lib/types";

export async function beginSession(): Promise<void> {
  await queryClient.invalidateQueries();
}

export async function endSession(): Promise<void> {
  try {
    await apiPost<OkResult>("/auth/logout");
  } finally {
    queryClient.clear();
  }
}
