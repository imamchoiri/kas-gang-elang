// Hand-written mirrors of the Pydantic models in backend/models/kas.py — nothing infers
// across the HTTP boundary, so keep these in sync in the same edit.

export type TxType = "masuk" | "keluar";

export interface Transaction {
  id: string;
  type: TxType;
  category: string;
  amount: number;
  description: string;
  date: string; // YYYY-MM-DD
  photo_id: string; // id foto bukti ("" = tanpa foto)
  warga: string; // nama warga ("" = tanpa nama)
  created_at: string; // ISO datetime
}

export interface TransactionCreate {
  type: TxType;
  category: string;
  amount: number;
  description: string;
  date: string;
  photo_id: string;
  warga: string;
}

export interface OkResult {
  ok: boolean;
}

export interface AuthMe {
  authenticated: boolean;
}

export interface MetaInfo {
  today: string; // YYYY-MM-DD (WIB)
  month: string; // YYYY-MM
}

export interface PasswordChangeInput {
  password_lama: string;
  password_baru: string;
}

export interface PhotoRef {
  id: string;
}

export interface Resident {
  id: string;
  nama: string;
  iuran_bulanan: number;
  created_at: string;
}

export interface ResidentCreate {
  nama: string;
  iuran_bulanan: number;
}

export interface KasSettings {
  iuran_default: number;
}

export interface ImportResult {
  ditambahkan: number;
}

export interface MeetingNote {
  year: string;
  text: string;
  updated_at: string | null;
}

export interface RestoreResult {
  transaksi: number;
  warga: number;
  dilewati: number;
  foto_hilang: number;
}

export interface AuditEntry {
  id: string;
  at: string;
  aksi: string;
  entitas: string;
  ringkasan: string;
  detail: string;
}

export interface Reminder {
  month: string;
  text: string;
  belum_lunas: number;
  total_kurang: number;
  created_at: string;
  sent_at: string | null;
}

export interface ReminderState {
  reminder: Reminder | null;
}

export interface BulkResult {
  dibuat: number;
  ids: string[];
}

export const KATEGORI_MASUK = [
  "Uang Kas",
  "Donatur",
  "Denda Kerja Bhakti",
  "Denda Ronda",
  "Kolektif Warga",
] as const;

export const BULAN_ID = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
] as const;

export const BULAN_SINGKAT = [
  "Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des",
] as const;
