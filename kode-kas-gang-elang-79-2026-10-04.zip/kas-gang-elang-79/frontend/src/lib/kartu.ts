// Kartu Iuran: gambar 1080x1350 berisi ceklis 12 bulan setoran satu warga.
// Dirender di canvas klien, siap dibagikan ke warga lewat WhatsApp.

import { rupiah } from "@/lib/format";
import type { BulanStatus } from "@/lib/iuran";

const W = 1080;
const H = 1350;
const SANS = '"Plus Jakarta Sans Variable", sans-serif';
const MONO = '"IBM Plex Mono", monospace';

async function loadCrest(): Promise<ImageBitmap | null> {
  try {
    const res = await fetch("/elang-crest.jpg");
    if (!res.ok) return null;
    return await createImageBitmap(await res.blob());
  } catch {
    return null;
  }
}

function roundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number | number[],
) {
  const radii = Array.isArray(r) ? r : [r, r, r, r];
  if (typeof ctx.roundRect === "function") {
    ctx.beginPath();
    ctx.roundRect(x, y, w, h, radii);
    return;
  }
  const [tl, tr, br, bl] = radii;
  ctx.beginPath();
  ctx.moveTo(x + tl, y);
  ctx.lineTo(x + w - tr, y);
  ctx.arcTo(x + w, y, x + w, y + tr, tr);
  ctx.lineTo(x + w, y + h - br);
  ctx.arcTo(x + w, y + h, x + w - br, y + h, br);
  ctx.lineTo(x + bl, y + h);
  ctx.arcTo(x, y + h, x, y + h - bl, bl);
  ctx.lineTo(x, y + tl);
  ctx.arcTo(x, y, x + tl, y, tl);
  ctx.closePath();
}

export interface KartuData {
  nama: string;
  tahun: string;
  target: number;
  bulan: BulanStatus[]; // 12 bulan
  totalTahun: number;
  tunggakan: number;
}

export async function renderKartuIuran(data: KartuData): Promise<Blob> {
  const canvas = document.createElement("canvas");
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Kanvas tidak tersedia");

  try {
    await Promise.all([
      document.fonts.load(`800 46px ${SANS}`),
      document.fonts.load(`600 26px ${SANS}`),
      document.fonts.load(`700 40px ${MONO}`),
    ]);
  } catch {
    // font fallback tetap terbaca
  }

  ctx.fillStyle = "#ECFDF5";
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.shadowColor = "rgba(6, 78, 59, 0.20)";
  ctx.shadowBlur = 36;
  ctx.shadowOffsetY = 14;
  ctx.fillStyle = "#FFFFFF";
  roundedRect(ctx, 40, 40, W - 80, H - 80, 48);
  ctx.fill();
  ctx.restore();

  // Header
  ctx.save();
  roundedRect(ctx, 40, 40, W - 80, 250, [48, 48, 0, 0]);
  ctx.clip();
  const grad = ctx.createLinearGradient(40, 40, W - 40, 290);
  grad.addColorStop(0, "#065F46");
  grad.addColorStop(1, "#022C22");
  ctx.fillStyle = grad;
  ctx.fillRect(40, 40, W - 80, 250);
  ctx.restore();

  const crest = await loadCrest();
  ctx.save();
  ctx.beginPath();
  ctx.arc(150, 165, 62, 0, Math.PI * 2);
  ctx.clip();
  if (crest) ctx.drawImage(crest, 88, 103, 124, 124);
  else {
    ctx.fillStyle = "#10B981";
    ctx.fillRect(88, 103, 124, 124);
  }
  ctx.restore();

  ctx.textBaseline = "alphabetic";
  ctx.font = `800 40px ${SANS}`;
  ctx.fillStyle = "#FFFFFF";
  ctx.fillText("Kartu Iuran Kas", 240, 145);
  ctx.font = `600 26px ${SANS}`;
  ctx.fillStyle = "#A7F3D0";
  ctx.fillText(`Gang Elang 79 · Tahun ${data.tahun}`, 240, 188);

  // Identitas warga
  let y = 360;
  ctx.font = `600 24px ${SANS}`;
  ctx.fillStyle = "#94A3B8";
  ctx.fillText("NAMA WARGA", 100, y);
  ctx.font = `800 46px ${SANS}`;
  ctx.fillStyle = "#0F172A";
  const nama = data.nama.length > 24 ? `${data.nama.slice(0, 23)}…` : data.nama;
  ctx.fillText(nama, 100, y + 56);

  ctx.font = `600 26px ${SANS}`;
  ctx.fillStyle = "#475569";
  ctx.fillText(
    data.target > 0 ? `Target iuran ${rupiah(data.target)} / bulan` : "Tanpa target iuran tetap",
    100,
    y + 100,
  );

  // Ceklis 12 bulan — 3 kolom x 4 baris
  y += 150;
  const cols = 3;
  const cellW = (W - 200 - 2 * 20) / cols;
  const cellH = 96;
  data.bulan.forEach((b, i) => {
    const cx = 100 + (i % cols) * (cellW + 20);
    const cy = y + Math.floor(i / cols) * (cellH + 18);
    const lunas = b.lunas;
    const sebagian = !lunas && b.dibayar > 0;

    roundedRect(ctx, cx, cy, cellW, cellH, 20);
    ctx.fillStyle = lunas ? "#ECFDF5" : sebagian ? "#FFFBEB" : "#F8FAFC";
    ctx.fill();
    ctx.strokeStyle = lunas ? "#6EE7B7" : sebagian ? "#FCD34D" : "#E2E8F0";
    ctx.lineWidth = 3;
    ctx.stroke();

    // tanda centang / silang
    ctx.save();
    ctx.translate(cx + 32, cy + cellH / 2);
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    if (lunas) {
      ctx.strokeStyle = "#047857";
      ctx.beginPath();
      ctx.moveTo(-12, 2);
      ctx.lineTo(-3, 12);
      ctx.lineTo(14, -11);
      ctx.stroke();
    } else if (sebagian) {
      ctx.strokeStyle = "#B45309";
      ctx.beginPath();
      ctx.moveTo(-12, 0);
      ctx.lineTo(12, 0);
      ctx.stroke();
    } else {
      ctx.strokeStyle = "#CBD5E1";
      ctx.beginPath();
      ctx.arc(0, 0, 12, 0, Math.PI * 2);
      ctx.stroke();
    }
    ctx.restore();

    ctx.font = `700 26px ${SANS}`;
    ctx.fillStyle = lunas ? "#065F46" : sebagian ? "#92400E" : "#64748B";
    ctx.fillText(b.labelPendek, cx + 62, cy + 42);
    ctx.font = `600 20px ${MONO}`;
    ctx.fillStyle = lunas ? "#047857" : sebagian ? "#B45309" : "#94A3B8";
    ctx.fillText(b.dibayar > 0 ? rupiah(b.dibayar) : "—", cx + 62, cy + 70);
  });

  // Ringkasan bawah
  y += 4 * (cellH + 18) + 24;
  ctx.save();
  roundedRect(ctx, 60, y, W - 120, 150, 32);
  ctx.fillStyle = data.tunggakan > 0 ? "#FFFBEB" : "#ECFDF5";
  ctx.fill();
  ctx.strokeStyle = data.tunggakan > 0 ? "#FCD34D" : "#A7F3D0";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();

  ctx.font = `600 24px ${SANS}`;
  ctx.fillStyle = "#475569";
  ctx.fillText(`TOTAL SETORAN ${data.tahun}`, 100, y + 48);
  ctx.font = `700 40px ${MONO}`;
  ctx.fillStyle = "#047857";
  ctx.fillText(rupiah(data.totalTahun), 100, y + 100);

  ctx.textAlign = "right";
  ctx.font = `600 24px ${SANS}`;
  ctx.fillStyle = "#475569";
  ctx.fillText("TUNGGAKAN", W - 100, y + 48);
  ctx.font = `700 40px ${MONO}`;
  ctx.fillStyle = data.tunggakan > 0 ? "#B45309" : "#047857";
  ctx.fillText(data.tunggakan > 0 ? rupiah(data.tunggakan) : "Lunas", W - 100, y + 100);
  ctx.textAlign = "left";

  // Keterangan simbol
  y += 190;
  ctx.font = `500 22px ${SANS}`;
  ctx.fillStyle = "#94A3B8";
  ctx.fillText("✓ lunas   – sebagian   ○ belum setor", 100, y);
  ctx.fillText("Kartu dibuat otomatis oleh bendahara Gang Elang 79", 100, y + 34);

  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("Gagal membuat kartu iuran"))),
      "image/png",
    );
  });
}
