import { useMemo } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ChevronRight, Users } from "lucide-react";

import { useResidents } from "@/hooks/useResidents";
import { apiGet } from "@/lib/api";
import { rupiah } from "@/lib/format";
import type { MetaInfo, Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

// Ringkasan iuran bulan ini untuk beranda: berapa warga belum lunas.
export default function RingkasanIuran({ transactions }: { transactions: Transaction[] }) {
  const { data: residents } = useResidents();
  const { data: meta } = useQuery({
    queryKey: ["meta"],
    queryFn: () => apiGet<MetaInfo>("/meta"),
    staleTime: 60_000,
  });

  const ringkasan = useMemo(() => {
    const bulan = meta?.month ?? "";
    const list = residents ?? [];
    if (!bulan || list.length === 0) return null;

    const dibayar = new Map<string, number>();
    transactions.forEach((t) => {
      const nama = (t.warga || "").trim().toLowerCase();
      if (t.type === "masuk" && nama && t.date.startsWith(bulan)) {
        dibayar.set(nama, (dibayar.get(nama) ?? 0) + t.amount);
      }
    });

    let belum = 0;
    let kurang = 0;
    list.forEach((w) => {
      const bayar = dibayar.get(w.nama.trim().toLowerCase()) ?? 0;
      const lunas = w.iuran_bulanan > 0 ? bayar >= w.iuran_bulanan : bayar > 0;
      if (!lunas) {
        belum += 1;
        kurang += Math.max(0, w.iuran_bulanan - bayar);
      }
    });
    return { belum, kurang, total: list.length, lunas: list.length - belum };
  }, [residents, transactions, meta]);

  if (!ringkasan) return null;

  const semuaLunas = ringkasan.belum === 0;

  return (
    <Link
      to="/warga"
      data-testid="ringkasan-iuran-beranda"
      className={cn(
        "flex items-center gap-3 rounded-2xl border p-4 transition hover:shadow-sm",
        semuaLunas
          ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900/60 dark:bg-emerald-950/40"
          : "border-amber-200 bg-amber-50 dark:border-amber-900/60 dark:bg-amber-950/40",
      )}
    >
      <span
        className={cn(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-full",
          semuaLunas
            ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300"
            : "bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300",
        )}
      >
        <Users className="h-5 w-5" aria-hidden />
      </span>
      <span className="min-w-0 flex-1">
        <span
          className={cn(
            "block text-sm font-bold",
            semuaLunas
              ? "text-emerald-900 dark:text-emerald-100"
              : "text-amber-900 dark:text-amber-100",
          )}
        >
          {semuaLunas
            ? `Semua warga sudah lunas (${ringkasan.total})`
            : `${ringkasan.belum} warga belum lunas bulan ini`}
        </span>
        <span
          className={cn(
            "block truncate text-xs",
            semuaLunas
              ? "text-emerald-800/90 dark:text-emerald-200/90"
              : "text-amber-800/90 dark:text-amber-200/90",
          )}
        >
          {semuaLunas
            ? "Terima kasih, kas gang aman bulan ini"
            : `Lunas ${ringkasan.lunas}/${ringkasan.total}${
                ringkasan.kurang > 0 ? ` · ${rupiah(ringkasan.kurang)} belum masuk` : ""
              }`}
        </span>
      </span>
      <ChevronRight
        className={cn(
          "h-5 w-5 shrink-0",
          semuaLunas ? "text-emerald-600" : "text-amber-600",
        )}
        aria-hidden
      />
    </Link>
  );
}
