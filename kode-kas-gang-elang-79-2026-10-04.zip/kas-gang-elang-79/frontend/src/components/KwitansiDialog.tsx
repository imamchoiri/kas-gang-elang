import { useEffect, useState } from "react";
import { Download, Loader2, Share2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { renderKwitansi } from "@/lib/kwitansi";
import { rupiah } from "@/lib/format";
import type { Transaction } from "@/lib/types";

export default function KwitansiDialog({
  tx,
  saldo,
  onClose,
}: {
  tx: Transaction | null;
  saldo: number;
  onClose: () => void;
}) {
  const [blob, setBlob] = useState<Blob | null>(null);
  const [url, setUrl] = useState("");

  useEffect(() => {
    if (!tx) return;
    let dead = false;
    let made = "";
    setBlob(null);
    setUrl("");
    renderKwitansi(tx, saldo)
      .then((b) => {
        if (dead) return;
        made = URL.createObjectURL(b);
        setBlob(b);
        setUrl(made);
      })
      .catch(() => {
        if (!dead) toast.error("Gagal membuat kwitansi. Coba lagi.");
      });
    return () => {
      dead = true;
      if (made) URL.revokeObjectURL(made);
    };
  }, [tx, saldo]);

  const unduh = () => {
    if (!blob || !tx) return;
    const a = document.createElement("a");
    a.href = url;
    a.download = `kwitansi-kas-${tx.type}-${tx.date}.png`;
    a.click();
    toast.success("Kwitansi diunduh.");
  };

  const bagikan = async () => {
    if (!blob || !tx) return;
    const file = new File([blob], `kwitansi-kas-${tx.date}.png`, { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (data: ShareData) => boolean };
    if (typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: "Kwitansi Kas Gang Elang 79" });
      } catch {
        // warga membatalkan bagikan — bukan galat
      }
    } else {
      unduh();
      toast.info("Gambar diunduh — kirim manual ke grup WhatsApp.");
    }
  };

  return (
    <Dialog
      open={tx !== null}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent data-testid="dialog-kwitansi" className="max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="text-base font-bold tracking-tight">Kwitansi Digital</DialogTitle>
          <DialogDescription>
            {tx
              ? `${tx.type === "masuk" ? "Pemasukan" : "Pengeluaran"} ${rupiah(tx.amount)} — pratinjau siap dibagikan ke grup.`
              : ""}
          </DialogDescription>
        </DialogHeader>
        <div className="rounded-xl border border-slate-200 bg-white p-2 dark:border-slate-700">
          {url ? (
            <img
              src={url}
              alt="Pratinjau kwitansi"
              data-testid="img-kwitansi"
              className="mx-auto max-h-[50svh] w-auto rounded-lg"
            />
          ) : (
            <div className="flex h-64 items-center justify-center text-slate-400">
              <Loader2 className="h-6 w-6 animate-spin" aria-hidden />
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="h-11 flex-1"
            data-testid="btn-unduh-kwitansi"
            onClick={unduh}
            disabled={!blob}
          >
            <Download className="h-4 w-4" aria-hidden /> Unduh
          </Button>
          <Button
            className="h-11 flex-[2] font-semibold"
            data-testid="btn-bagikan-kwitansi"
            onClick={bagikan}
            disabled={!blob}
          >
            <Share2 className="h-4 w-4" aria-hidden /> Bagikan
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
