import { HeartHandshake, Shovel, ShieldAlert, Users, Wallet, type LucideIcon } from "lucide-react";

import { cn } from "@/lib/utils";

export interface KategoriMeta {
  badgeClass: string;
  Icon: LucideIcon;
}

// Semantic soft-pastel badges for the five fixed income categories (design guidelines).
export const KATEGORI_META: Record<string, KategoriMeta> = {
  "Uang Kas": {
    badgeClass: "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300",
    Icon: Wallet,
  },
  Donatur: {
    badgeClass: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
    Icon: HeartHandshake,
  },
  "Denda Kerja Bhakti": {
    badgeClass: "bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300",
    Icon: Shovel,
  },
  "Denda Ronda": {
    badgeClass: "bg-pink-100 text-pink-800 dark:bg-pink-900/40 dark:text-pink-300",
    Icon: ShieldAlert,
  },
  "Kolektif Warga": {
    badgeClass: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300",
    Icon: Users,
  },
};

export function KategoriBadge({ name }: { name: string }) {
  const meta = KATEGORI_META[name];
  if (!meta) return null;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold",
        meta.badgeClass,
      )}
    >
      <meta.Icon className="h-3 w-3" aria-hidden />
      {name}
    </span>
  );
}
