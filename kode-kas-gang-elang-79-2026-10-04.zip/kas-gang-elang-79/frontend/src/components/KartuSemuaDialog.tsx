import { useEffect, useRef, useState } from "react";
import { Download, Loader2, Share2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { rupiah } from "@/lib/format";
import { hitungWarga } from "@/lib/iuran";
import { renderKartuIuran } from "@/lib/kartu";
import type { Resident, Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

interface KartuSiap {
  nama: string;
  target: number;
  tunggakan: number;
  totalTahun: number;
  url: string;
  blob: Blob;
}

export default function KartuSemuaDialog({
  open,
  residents,
  transactions,
  bulanTerpilih,
  onClose,
}: {
  open: boolean;
  residents: Resident[];
  transactions: Transaction[];
  bulanTerpilih: string; // YYYY-MM
  onClose: () => void;
}) {
  const [kartu, setKartu] = useState<KartuSiap[]>([]);
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const urlsRef = useRef<string[]>([]);
  const tahun = bulanTerpilih.slice(0, 4);

  // Bersihkan object URL saat dialog ditutup / data berganti.
  const bersihkan = () => {
    urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
    urlsRef.current = [];
    setKartu([]);
    setProgress(0);
  };

  useEffect(() => {
    if (!open) bersihkan();
  }, [open]);

  useEffect(() => () => bersihkan(), []);

  const buatSemua = async () => {
    bersihkan();
    setBusy(true);
    const hasil: KartuSiap[] = [];
    try {
      for (let i = 0; i < residents.length; i++) {
        const w = residents[i];
        const r = hitungWarga(w.nama, w.iuran_bulanan, w.created_at, transactions, bulanTerpilih);
        const totalTahun = r.tahunIni.reduce((s, b) => s + b.dibayar, 0);
        const blob = await renderKartuIuran({
          nama: w.nama,
          tahun,
          target: w.iuran_bulanan,
          bulan: r.tahunIni,
          totalTahun,
          tunggakan: r.tunggakan,
        });
        const url = URL.createObjectURL(blob);
        urlsRef.current.push(url);
        hasil.push({
          nama: w.nama,
          target: w.iuran_bulanan,
          tunggakan: r.tunggakan,
          totalTahun,
          url,
          blob,
        });
        setProgress(i + 1);
      }
      setKartu(hasil);
      toast.success(`${hasil.length} kartu iuran siap dibagikan.`);
    } catch {
      toast.error("Gagal membuat sebagian kartu. Coba lagi.");
      setKartu(hasil);
    } finally {
      setBusy(false);
    }
  };

  const namaFile = (nama: string) =>
    `kartu-iuran-${nama.replace(/\s+/g, "-").toLowerCase()}-${tahun}.png`;

  const unduh = (k: KartuSiap) => {
    const a = document.createElement("a");
    a.href = k.url;
    a.download = namaFile(k.nama);
    a.click();
  };

  const unduhSemua = async () => {
    for (const k of kartu) {
      unduh(k);
      await new Promise((r) => setTimeout(r, 350)); // beri jeda agar semua unduhan terpicu
    }
    toast.success(`${kartu.length} kartu diunduh.`);
  };

  const bagikan = async (k: KartuSiap) => {
    const file = new File([k.blob], namaFile(k.nama), { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: `Kartu Iuran ${k.nama}` });
      } catch {
        // dibatalkan — bukan galat
      }
    } else {
      unduh(k);
      toast.info("Kartu diunduh — kirim manual lewat WhatsApp.");
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent
        data-testid="dialog-kartu-semua"
        className="max-h-[88svh] max-w-md overflow-y-auto rounded-2xl"
      >
        <DialogHeader>
          <DialogTitle className="text-base font-bold tracking-tight">
            Kartu Iuran Semua Warga
          </DialogTitle>
          <DialogDescription>
            Buat kartu {tahun} untuk {residents.length} warga terdaftar sekaligus, lalu kirim satu
            per satu ke warga.
          </DialogDescription>
        </DialogHeader>

        {kartu.length === 0 ? (
          <Button
            className="h-12 w-full font-semibold"
            data-testid="btn-buat-semua-kartu"
            onClick={buatSemua}
            disabled={busy || residents.length === 0}
          >
            {busy ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Membuat kartu {progress}/
                {residents.length}...
              </>
            ) : (
              `Buat ${residents.length} Kartu Iuran`
            )}
          </Button>
        ) : (
          <>
            <Button
              className="h-12 w-full font-semibold"
              data-testid="btn-unduh-semua-kartu"
              onClick={unduhSemua}
            >
              <Download className="h-4 w-4" aria-hidden /> Unduh Semua ({kartu.length})
            </Button>
            <div className="space-y-3" data-testid="daftar-kartu-semua">
              {kartu.map((k) => (
                <div
                  key={k.nama}
                  data-testid="kartu-semua-item"
                  className="flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-3 dark:border-slate-800 dark:bg-slate-900"
                >
                  <img
                    src={k.url}
                    alt={`Kartu iuran ${k.nama}`}
                    className="h-20 w-16 shrink-0 rounded-lg border border-slate-200 object-cover object-top dark:border-slate-700"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-800 dark:text-slate-200">
                      {k.nama}
                    </p>
                    <p className="truncate text-xs text-slate-500 dark:text-slate-400">
                      Setoran {tahun}: {rupiah(k.totalTahun)}
                    </p>
                    <p
                      className={cn(
                        "truncate text-xs font-semibold",
                        k.tunggakan > 0
                          ? "text-amber-700 dark:text-amber-300"
                          : "text-emerald-700 dark:text-emerald-300",
                      )}
                    >
                      {k.tunggakan > 0 ? `Tunggakan ${rupiah(k.tunggakan)}` : "Tidak ada tunggakan"}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    data-testid="btn-bagikan-kartu-item"
                    aria-label={`Bagikan kartu ${k.nama}`}
                    onClick={() => bagikan(k)}
                    className="h-9 shrink-0"
                  >
                    <Share2 className="h-4 w-4" aria-hidden /> Kirim
                  </Button>
                </div>
              ))}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
