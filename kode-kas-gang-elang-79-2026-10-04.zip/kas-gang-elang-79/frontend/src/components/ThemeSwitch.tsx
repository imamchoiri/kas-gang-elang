import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import { Moon, Sun } from "lucide-react";

import { cn } from "@/lib/utils";

// Saklar mode gelap/terang — token .dark sudah lengkap di index.css.
export default function ThemeSwitch() {
  const { resolvedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  const dark = resolvedTheme === "dark";

  return (
    <button
      type="button"
      role="switch"
      aria-checked={dark}
      data-testid="btn-mode-gelap"
      aria-label={dark ? "Matikan mode gelap" : "Aktifkan mode gelap"}
      title={dark ? "Matikan mode gelap" : "Aktifkan mode gelap"}
      onClick={() => setTheme(dark ? "light" : "dark")}
      className={cn(
        "relative h-8 w-14 rounded-full transition-colors",
        dark ? "bg-emerald-600" : "bg-slate-300",
      )}
    >
      <span
        className={cn(
          "absolute top-1 flex h-6 w-6 items-center justify-center rounded-full bg-white shadow transition-all",
          dark ? "left-7" : "left-1",
        )}
      >
        {mounted && dark ? (
          <Moon className="h-3.5 w-3.5 text-emerald-700" aria-hidden />
        ) : (
          <Sun className="h-3.5 w-3.5 text-amber-500" aria-hidden />
        )}
      </span>
    </button>
  );
}
