import { useState } from "react";
import { BellRing, Check, ChevronDown, Loader2, Send } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useReminder, useReminderActions } from "@/hooks/useReminder";
import { rupiah } from "@/lib/format";

// Banner beranda: pengingat iuran yang sudah disiapkan penjadwal, siap dikirim sekali ketuk.
export default function ReminderBanner() {
  const { data } = useReminder();
  const { tandaiTerkirim } = useReminderActions();
  const [buka, setBuka] = useState(false);
  const reminder = data?.reminder;

  if (!reminder) return null;

  const kirim = () => {
    // wa.me membuka WhatsApp dengan teks sudah terisi — bendahara memilih grupnya.
    window.open(`https://wa.me/?text=${encodeURIComponent(reminder.text)}`, "_blank", "noopener");
    navigator.clipboard?.writeText(reminder.text).catch(() => undefined);
    toast.success("WhatsApp dibuka — pilih grup warga lalu kirim. Teks juga sudah disalin.");
  };

  return (
    <section
      data-testid="banner-pengingat"
      className="rounded-2xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-900/50 dark:bg-amber-950/40"
    >
      <div className="flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-300">
          <BellRing className="h-5 w-5" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-bold text-amber-900 dark:text-amber-100">
            Pengingat iuran sudah disiapkan
          </p>
          <p className="mt-0.5 text-xs text-amber-800/90 dark:text-amber-200/90">
            {reminder.belum_lunas > 0
              ? `${reminder.belum_lunas} warga belum lunas · ${rupiah(reminder.total_kurang)} belum masuk`
              : "Semua warga sudah lunas bulan ini"}
          </p>
        </div>
      </div>

      {buka ? (
        <pre
          data-testid="pratinjau-pengingat"
          className="mt-3 max-h-48 overflow-y-auto whitespace-pre-wrap rounded-xl border border-amber-200 bg-white p-3 text-xs leading-relaxed text-slate-700 dark:border-amber-900/50 dark:bg-slate-900 dark:text-slate-300"
        >
          {reminder.text}
        </pre>
      ) : null}

      <div className="mt-3 flex flex-wrap gap-2">
        <Button
          data-testid="btn-kirim-pengingat"
          onClick={kirim}
          className="h-10 flex-1 font-semibold sm:flex-none"
        >
          <Send className="h-4 w-4" aria-hidden /> Kirim ke WhatsApp
        </Button>
        <Button
          variant="outline"
          data-testid="btn-pratinjau-pengingat"
          onClick={() => setBuka((b) => !b)}
          className="h-10"
        >
          <ChevronDown className="h-4 w-4" aria-hidden /> {buka ? "Tutup" : "Lihat Pesan"}
        </Button>
        <Button
          variant="ghost"
          data-testid="btn-tandai-pengingat-terkirim"
          disabled={tandaiTerkirim.isPending}
          onClick={() =>
            tandaiTerkirim.mutate(reminder.month, {
              onSuccess: () => toast.success("Pengingat ditandai sudah dikirim."),
              onError: () => toast.error("Gagal menandai. Coba lagi."),
            })
          }
          className="h-10 text-amber-800 hover:bg-amber-100 dark:text-amber-300"
        >
          {tandaiTerkirim.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
          ) : (
            <Check className="h-4 w-4" aria-hidden />
          )}
          Sudah dikirim
        </Button>
      </div>
    </section>
  );
}
