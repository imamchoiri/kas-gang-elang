import { useEffect, useState } from "react";
import { Download, IdCard, Loader2, Share2 } from "lucide-react";
import { toast } from "sonner";

import { KategoriBadge } from "@/components/kategori";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { rupiah, tanggalIndo } from "@/lib/format";
import { hitungWarga, type RingkasanWarga } from "@/lib/iuran";
import { renderKartuIuran } from "@/lib/kartu";
import type { Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

export interface DetailWarga {
  nama: string;
  target: number;
  terdaftarSejak?: string;
}

export default function WargaDetailDialog({
  warga,
  transactions,
  bulanTerpilih,
  onClose,
}: {
  warga: DetailWarga | null;
  transactions: Transaction[];
  bulanTerpilih: string; // YYYY-MM
  onClose: () => void;
}) {
  const [kartuUrl, setKartuUrl] = useState("");
  const [kartuBlob, setKartuBlob] = useState<Blob | null>(null);
  const [kartuLoading, setKartuLoading] = useState(false);

  // Kartu direset tiap kali warga/bulan berganti.
  useEffect(() => {
    setKartuUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return "";
    });
    setKartuBlob(null);
    setKartuLoading(false);
  }, [warga, bulanTerpilih]);

  if (!warga) {
    return (
      <Dialog open={false} onOpenChange={() => onClose()}>
        <DialogContent className="max-w-md rounded-2xl" />
      </Dialog>
    );
  }

  const r: RingkasanWarga = hitungWarga(
    warga.nama,
    warga.target,
    warga.terdaftarSejak,
    transactions,
    bulanTerpilih,
  );
  const tahun = bulanTerpilih.slice(0, 4);
  const totalTahun = r.tahunIni.reduce((s, b) => s + b.dibayar, 0);

  const buatKartu = async () => {
    setKartuLoading(true);
    try {
      const blob = await renderKartuIuran({
        nama: warga.nama,
        tahun,
        target: warga.target,
        bulan: r.tahunIni,
        totalTahun,
        tunggakan: r.tunggakan,
      });
      setKartuBlob(blob);
      setKartuUrl(URL.createObjectURL(blob));
    } catch {
      toast.error("Gagal membuat kartu iuran. Coba lagi.");
    } finally {
      setKartuLoading(false);
    }
  };

  const unduhKartu = () => {
    if (!kartuBlob || !kartuUrl) return;
    const a = document.createElement("a");
    a.href = kartuUrl;
    a.download = `kartu-iuran-${warga.nama.replace(/\s+/g, "-").toLowerCase()}-${tahun}.png`;
    a.click();
    toast.success("Kartu iuran diunduh.");
  };

  const bagikanKartu = async () => {
    if (!kartuBlob) return;
    const file = new File([kartuBlob], `kartu-iuran-${tahun}.png`, { type: "image/png" });
    const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
    if (typeof nav.canShare === "function" && nav.canShare({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: `Kartu Iuran ${warga.nama}` });
      } catch {
        // dibatalkan warga — bukan galat
      }
    } else {
      unduhKartu();
      toast.info("Kartu diunduh — kirim manual ke warga lewat WhatsApp.");
    }
  };

  return (
    <Dialog
      open
      onOpenChange={(o) => {
        if (!o) onClose();
      }}
    >
      <DialogContent
        data-testid="dialog-detail-warga"
        className="max-h-[88svh] max-w-md overflow-y-auto rounded-2xl"
      >
        <DialogHeader>
          <DialogTitle className="text-base font-bold tracking-tight">{warga.nama}</DialogTitle>
          <DialogDescription>
            {warga.target > 0
              ? `Target ${rupiah(warga.target)} per bulan · riwayat setoran dan tunggakan`
              : "Tanpa target tetap · riwayat setoran"}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-3 dark:border-emerald-900/50 dark:bg-emerald-950/40">
            <p
              data-testid="detail-total-setor"
              className="font-mono text-lg font-bold tracking-tight text-emerald-800 dark:text-emerald-200"
            >
              {rupiah(r.totalSetor)}
            </p>
            <p className="mt-0.5 text-xs font-semibold uppercase tracking-[0.1em] text-emerald-700/80 dark:text-emerald-300/80">
              Total Setoran
            </p>
          </div>
          <div
            className={cn(
              "rounded-xl border p-3",
              r.tunggakan > 0
                ? "border-amber-100 bg-amber-50 dark:border-amber-900/50 dark:bg-amber-950/40"
                : "border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900",
            )}
          >
            <p
              data-testid="detail-tunggakan"
              className={cn(
                "font-mono text-lg font-bold tracking-tight",
                r.tunggakan > 0
                  ? "text-amber-800 dark:text-amber-200"
                  : "text-slate-700 dark:text-slate-300",
              )}
            >
              {r.tunggakan > 0 ? rupiah(r.tunggakan) : "Lunas"}
            </p>
            <p className="mt-0.5 text-xs font-semibold uppercase tracking-[0.1em] text-slate-500 dark:text-slate-400">
              Tunggakan Berjalan
            </p>
          </div>
        </div>

        {/* Ceklis bulan tahun terpilih */}
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
            Status Bulanan {tahun}
          </p>
          <div className="mt-2 grid grid-cols-3 gap-2" data-testid="detail-ceklis-bulan">
            {r.tahunIni.map((b) => {
              const sebagian = !b.lunas && b.dibayar > 0;
              return (
                <div
                  key={b.key}
                  className={cn(
                    "rounded-lg border px-2 py-1.5 text-center",
                    b.lunas
                      ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900/60 dark:bg-emerald-950/40"
                      : sebagian
                        ? "border-amber-200 bg-amber-50 dark:border-amber-900/60 dark:bg-amber-950/40"
                        : "border-slate-200 bg-slate-50 dark:border-slate-800 dark:bg-slate-900",
                  )}
                >
                  <p
                    className={cn(
                      "text-xs font-bold",
                      b.lunas
                        ? "text-emerald-800 dark:text-emerald-300"
                        : sebagian
                          ? "text-amber-800 dark:text-amber-300"
                          : "text-slate-500 dark:text-slate-400",
                    )}
                  >
                    {b.lunas ? "✓" : sebagian ? "–" : "○"} {b.labelPendek}
                  </p>
                  <p className="truncate font-mono text-[11px] text-slate-600 dark:text-slate-400">
                    {b.dibayar > 0 ? rupiah(b.dibayar) : "—"}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Riwayat setoran */}
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
            Riwayat Setoran ({r.setoran.length})
          </p>
          <div className="mt-2 space-y-2" data-testid="detail-riwayat-setoran">
            {r.setoran.length === 0 ? (
              <p className="rounded-lg border border-dashed border-slate-300 p-3 text-center text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
                Warga ini belum pernah menyetor iuran.
              </p>
            ) : (
              r.setoran.map((t) => (
                <div
                  key={t.id}
                  data-testid="detail-setoran-item"
                  className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 bg-white p-2.5 dark:border-slate-800 dark:bg-slate-900"
                >
                  <div className="min-w-0">
                    <KategoriBadge name={t.category} />
                    <p className="mt-0.5 truncate text-xs text-slate-500 dark:text-slate-400">
                      {tanggalIndo(t.date)}
                      {t.description ? ` · ${t.description}` : ""}
                    </p>
                  </div>
                  <span className="shrink-0 whitespace-nowrap font-mono text-sm font-bold text-emerald-700 dark:text-emerald-300">
                    +{rupiah(t.amount)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Kartu iuran */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-900/60">
          <p className="text-xs font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
            Kartu Iuran {tahun}
          </p>
          {kartuUrl ? (
            <>
              <img
                src={kartuUrl}
                alt={`Kartu iuran ${warga.nama}`}
                data-testid="img-kartu-iuran"
                className="mx-auto mt-2 max-h-[40svh] w-auto rounded-lg border border-slate-200 dark:border-slate-700"
              />
              <div className="mt-3 flex gap-2">
                <Button
                  variant="outline"
                  className="h-11 flex-1"
                  data-testid="btn-unduh-kartu"
                  onClick={unduhKartu}
                >
                  <Download className="h-4 w-4" aria-hidden /> Unduh
                </Button>
                <Button
                  className="h-11 flex-[2] font-semibold"
                  data-testid="btn-bagikan-kartu"
                  onClick={bagikanKartu}
                >
                  <Share2 className="h-4 w-4" aria-hidden /> Bagikan ke Warga
                </Button>
              </div>
            </>
          ) : (
            <Button
              variant="outline"
              className="mt-2 h-11 w-full"
              data-testid="btn-buat-kartu"
              onClick={buatKartu}
              disabled={kartuLoading}
            >
              {kartuLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Menyiapkan kartu...
                </>
              ) : (
                <>
                  <IdCard className="h-4 w-4" aria-hidden /> Buat Kartu Iuran
                </>
              )}
            </Button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
