import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { BarChart3, FileText, History, House, LogOut, Menu, Minus, Plus, Settings, Users } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { endSession } from "@/lib/session";
import { cn } from "@/lib/utils";

const iconLinkClass =
  "inline-flex h-10 w-10 items-center justify-center rounded-full text-slate-600 transition-colors hover:bg-emerald-50 hover:text-emerald-700 sm:h-11 sm:w-11 dark:text-slate-300 dark:hover:bg-emerald-900/40 dark:hover:text-emerald-300";

// Always-visible record buttons — the plan's "tombol catat selalu terlihat".
function Dock() {
  const navigate = useNavigate();
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 flex justify-center px-4 pb-5">
      <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-emerald-900/10 bg-white/95 p-2 shadow-xl shadow-emerald-950/10 backdrop-blur dark:border-slate-700 dark:bg-slate-900/95">
        <Button
          data-testid="btn-tambah-pemasukan"
          onClick={() => navigate("/catat?type=masuk")}
          className="h-11 rounded-full px-4 text-sm font-semibold sm:px-5"
        >
          <Plus className="h-4 w-4" aria-hidden />
          Catat Pemasukan
        </Button>
        <Button
          data-testid="btn-tambah-pengeluaran"
          variant="destructive"
          onClick={() => navigate("/catat?type=keluar")}
          className="h-11 rounded-full px-4 text-sm font-semibold sm:px-5"
        >
          <Minus className="h-4 w-4" aria-hidden />
          Catat Pengeluaran
        </Button>
      </div>
    </div>
  );
}

export default function AppShell({
  children,
  dock = true,
}: {
  children: ReactNode;
  dock?: boolean;
}) {
  const navigate = useNavigate();
  const [leaving, setLeaving] = useState(false);

  const onLogout = async () => {
    setLeaving(true);
    try {
      await endSession();
      toast.success("Anda telah keluar. Sampai jumpa!");
      navigate("/masuk", { replace: true });
    } finally {
      setLeaving(false);
    }
  };

  return (
    <div className="min-h-svh bg-background">
      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/90">
        <div className="mx-auto flex h-16 w-full max-w-3xl items-center justify-between gap-2 px-4">
          <Link
            to="/"
            className="flex min-w-0 items-center gap-3"
            aria-label="Beranda Kas Gang Elang 79"
          >
            <img
              src="/elang-crest.jpg"
              alt="Lambang Gang Elang 79"
              className="h-10 w-10 rounded-full ring-1 ring-emerald-600/25"
            />
            <span className="min-w-0">
              <span className="block truncate text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100">
                Kas Gang Elang 79
              </span>
              <span className="block text-xs text-slate-500 dark:text-slate-400">
                Buku Kas Bendahara
              </span>
            </span>
          </Link>
          <nav className="flex items-center gap-0.5" aria-label="Menu utama">
            <Link
              to="/"
              data-testid="nav-beranda"
              aria-label="Beranda"
              title="Beranda"
              className={iconLinkClass}
            >
              <House className="h-5 w-5" aria-hidden />
            </Link>
            <Link
              to="/warga"
              data-testid="nav-warga"
              aria-label="Iuran warga"
              title="Iuran warga"
              className={iconLinkClass}
            >
              <Users className="h-5 w-5" aria-hidden />
            </Link>
            <Link
              to="/rekap"
              data-testid="nav-rekap"
              aria-label="Rekap bulanan"
              title="Rekap bulanan"
              className={iconLinkClass}
            >
              <BarChart3 className="h-5 w-5" aria-hidden />
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger
                data-testid="nav-menu-lain"
                aria-label="Menu lainnya"
                title="Menu lainnya"
                className={cn(iconLinkClass, "cursor-pointer")}
              >
                <Menu className="h-5 w-5" aria-hidden />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" sideOffset={6} className="w-52">
                <DropdownMenuItem
                  data-testid="nav-laporan"
                  onClick={() => navigate("/laporan")}
                >
                  <FileText className="h-4 w-4" aria-hidden /> Laporan Tahunan
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-riwayat"
                  onClick={() => navigate("/riwayat")}
                >
                  <History className="h-4 w-4" aria-hidden /> Riwayat Perubahan
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-pengaturan"
                  onClick={() => navigate("/pengaturan")}
                >
                  <Settings className="h-4 w-4" aria-hidden /> Pengaturan
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  data-testid="bendahara-logout-button"
                  variant="destructive"
                  disabled={leaving}
                  onClick={onLogout}
                >
                  <LogOut className="h-4 w-4" aria-hidden /> Keluar
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-3xl px-4 pb-40 pt-6">{children}</main>
      {dock && <Dock />}
    </div>
  );
}
