import { animate } from "motion";
import { useEffect, useRef, useState, type ComponentProps } from "react";

import { rupiah } from "@/lib/format";

// Counts the number up/down whenever the value changes — small, calm motion.
export default function AnimatedRupiah({
  value,
  className,
  ...rest
}: ComponentProps<"span"> & { value: number }) {
  const [display, setDisplay] = useState(value);
  const prev = useRef(value);

  useEffect(() => {
    const from = prev.current;
    prev.current = value;
    if (from === value) return;
    const controls = animate(from, value, {
      duration: 0.5,
      ease: "easeOut",
      onUpdate: (v) => setDisplay(Math.round(v)),
    });
    return () => controls.stop();
  }, [value]);

  return (
    <span className={className} {...rest}>
      {rupiah(display)}
    </span>
  );
}
