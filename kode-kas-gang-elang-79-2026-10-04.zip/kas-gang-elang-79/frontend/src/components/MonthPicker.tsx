import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BULAN_ID } from "@/lib/types";

// Pasangan pilih Bulan + Tahun — dipakai Rekap dan Iuran Warga.
export default function MonthPicker({
  bulan,
  tahun,
  tahunList,
  onBulan,
  onTahun,
  bulanTestid = "select-bulan",
  tahunTestid = "select-tahun",
}: {
  bulan: string;
  tahun: string;
  tahunList: number[];
  onBulan: (v: string) => void;
  onTahun: (v: string) => void;
  bulanTestid?: string;
  tahunTestid?: string;
}) {
  return (
    <>
      <div className="space-y-1.5">
        <Label htmlFor="bulan-picker">Bulan</Label>
        <Select value={bulan} onValueChange={onBulan}>
          <SelectTrigger id="bulan-picker" data-testid={bulanTestid} className="h-11 w-40">
            <SelectValue>{(v: string) => BULAN_ID[Number(v) - 1]}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {BULAN_ID.map((b, i) => (
              <SelectItem key={b} value={String(i + 1)}>
                {b}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="tahun-picker">Tahun</Label>
        <Select value={tahun} onValueChange={onTahun}>
          <SelectTrigger id="tahun-picker" data-testid={tahunTestid} className="h-11 w-28">
            <SelectValue>{tahun}</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {tahunList.map((y) => (
              <SelectItem key={y} value={String(y)}>
                {y}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </>
  );
}
