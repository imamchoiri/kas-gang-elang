import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";import {
  ArrowRightLeft,
  BellRing,
  DatabaseBackup,
  PlusCircle,
  Trash2,
  Users,
  type LucideIcon,
} from "lucide-react";

import AppShell from "@/components/AppShell";
import { useAudit } from "@/hooks/useReminder";
import { cn } from "@/lib/utils";
import type { AuditEntry } from "@/lib/types";

const AKSI_META: Record<string, { Icon: LucideIcon; kelas: string; label: string }> = {
  tambah: {
    Icon: PlusCircle,
    kelas: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    label: "Ditambah",
  },
  ubah: {
    Icon: ArrowRightLeft,
    kelas: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
    label: "Diubah",
  },
  hapus: {
    Icon: Trash2,
    kelas: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    label: "Dihapus",
  },
  pulihkan: {
    Icon: DatabaseBackup,
    kelas: "bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300",
    label: "Dipulihkan",
  },
  kirim: {
    Icon: BellRing,
    kelas: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    label: "Dikirim",
  },
};

const ENTITAS_LABEL: Record<string, string> = {
  transaksi: "Transaksi",
  warga: "Warga",
  backup: "Backup",
  pengingat: "Pengingat",
};

const waktuIndo = (iso: string): string =>
  new Date(iso).toLocaleString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

function Baris({ e }: { e: AuditEntry }) {
  const meta = AKSI_META[e.aksi] ?? {
    Icon: Users,
    kelas: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
    label: e.aksi,
  };
  return (
    <div
      data-testid="riwayat-item"
      className="flex gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
    >
      <span
        className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-full", meta.kelas)}
        aria-hidden
      >
        <meta.Icon className="h-4 w-4" />
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className={cn("rounded-full px-2 py-0.5 text-xs font-semibold", meta.kelas)}>
            {meta.label}
          </span>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
            {ENTITAS_LABEL[e.entitas] ?? e.entitas}
          </span>
        </div>
        <p className="mt-1 text-sm font-medium text-slate-800 dark:text-slate-200">{e.ringkasan}</p>
        {e.detail ? (
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">{e.detail}</p>
        ) : null}
        <p className="mt-1 text-xs text-slate-400 dark:text-slate-500">{waktuIndo(e.at)}</p>
      </div>
    </div>
  );
}

export default function Riwayat() {
  const { data: entries, isPending, isError } = useAudit(200);

  return (
    <AppShell>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="space-y-5"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Riwayat Perubahan
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Catatan setiap penambahan, perubahan, dan penghapusan data kas.
          </p>
        </div>

        <div className="space-y-3" data-testid="riwayat-container">
          {isPending ? (
            <>
              <span className="block h-24 animate-pulse rounded-xl bg-slate-200 dark:bg-slate-700" />
              <span className="block h-24 animate-pulse rounded-xl bg-slate-200 dark:bg-slate-700" />
            </>
          ) : isError ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
              Tidak dapat memuat riwayat. Periksa koneksi lalu muat ulang halaman.
            </div>
          ) : (entries ?? []).length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white/50 p-8 text-center dark:border-slate-700 dark:bg-slate-900/50">
              <p className="font-semibold text-slate-700 dark:text-slate-300">Belum ada riwayat</p>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Setiap perubahan data kas mulai sekarang akan tercatat di sini.
              </p>
            </div>
          ) : (
            (entries ?? []).map((e) => <Baris key={e.id} e={e} />)
          )}
        </div>
      </motion.div>
    </AppShell>
  );
}
