import { useEffect, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { motion } from "motion/react";
import {
  Coins,
  DatabaseBackup,
  FileJson,
  FileSpreadsheet,
  FileArchive,
  KeyRound,
  Loader2,
  Moon,
  Upload,
} from "lucide-react";
import { toast } from "sonner";

import AppShell from "@/components/AppShell";
import ThemeSwitch from "@/components/ThemeSwitch";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useKasSettings, useSaveKasSettings } from "@/hooks/useResidents";
import { ApiError, apiDownload, apiPostForm, apiPut } from "@/lib/api";
import { angka, rupiah } from "@/lib/format";
import type { OkResult, RestoreResult } from "@/lib/types";

export default function Pengaturan() {
  const [sandiLama, setSandiLama] = useState("");
  const [sandiBaru, setSandiBaru] = useState("");
  const [konfirmasi, setKonfirmasi] = useState("");
  const [formError, setFormError] = useState("");

  // Target iuran default untuk warga yang baru didaftarkan.
  const { data: kasSettings } = useKasSettings();
  const simpanIuran = useSaveKasSettings();
  const [iuranStr, setIuranStr] = useState("");
  const [iuranTersentuh, setIuranTersentuh] = useState(false);

  useEffect(() => {
    if (kasSettings && !iuranTersentuh) setIuranStr(String(kasSettings.iuran_default || ""));
  }, [kasSettings, iuranTersentuh]);

  // Backup seluruh buku kas jadi satu file.
  const backup = useMutation<void, ApiError, "excel" | "json">({
    mutationFn: async (jenis) => {
      const hariIni = new Date().toISOString().slice(0, 10);
      await apiDownload(
        `/backup/${jenis}`,
        `backup-kas-gang-elang-79-${hariIni}.${jenis === "excel" ? "xlsx" : "json"}`,
      );
    },
    onSuccess: () => toast.success("Backup buku kas berhasil diunduh. Simpan di tempat aman."),
    onError: () => toast.error("Gagal membuat backup. Coba lagi."),
  });

  // Unduh seluruh kode sumber proyek sebagai satu file ZIP.
  const unduhKode = useMutation<void, ApiError, void>({
    mutationFn: async () => {
      const hariIni = new Date().toISOString().slice(0, 10);
      await apiDownload("/kode-sumber/zip", `kode-kas-gang-elang-79-${hariIni}.zip`);
    },
    onSuccess: () => toast.success("Kode sumber berhasil diunduh dalam file ZIP."),
    onError: () => toast.error("Gagal menyiapkan file ZIP kode. Coba lagi."),
  });

  // Pulihkan backup JSON — mengganti seluruh transaksi & daftar warga.
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [fileRestore, setFileRestore] = useState<File | null>(null);

  const pulihkan = useMutation<RestoreResult, ApiError, File>({
    mutationFn: (f) => {
      const fd = new FormData();
      fd.append("file", f, f.name);
      return apiPostForm<RestoreResult>("/backup/restore", fd);
    },
    onSuccess: (r) => {
      queryClient.invalidateQueries();
      setFileRestore(null);
      toast.success(
        `Backup dipulihkan: ${r.transaksi} transaksi, ${r.warga} warga.` +
          (r.dilewati > 0 ? ` ${r.dilewati} baris dilewati.` : "") +
          (r.foto_hilang > 0 ? ` ${r.foto_hilang} foto bukti tidak tersedia.` : ""),
        { duration: 6000 },
      );
    },
    onError: (err) => {
      setFileRestore(null);
      toast.error(
        err.status === 422
          ? "File bukan backup JSON aplikasi ini."
          : "Gagal memulihkan backup. Coba lagi.",
      );
    },
  });

  const pilihFile = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.name.toLowerCase().endsWith(".json")) {
      toast.error("Pilih file backup berformat .json");
      return;
    }
    setFileRestore(f); // tampilkan konfirmasi dulu — memulihkan mengganti semua data
  };

  const ganti = useMutation<OkResult, ApiError, { password_lama: string; password_baru: string }>({
    mutationFn: (body) => apiPut<OkResult>("/auth/password", body),
    onSuccess: () => {
      setSandiLama("");
      setSandiBaru("");
      setKonfirmasi("");
      setFormError("");
      toast.success("Sandi bendahara berhasil diganti.");
    },
    onError: (err) => {
      setFormError(
        err.status === 401 ? "Sandi lama salah." : "Gagal mengganti sandi. Coba lagi.",
      );
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!sandiLama || !sandiBaru) {
      setFormError("Isi sandi lama dan sandi baru terlebih dahulu.");
      return;
    }
    if (sandiBaru.length < 5) {
      setFormError("Sandi baru minimal 5 karakter.");
      return;
    }
    if (sandiBaru !== konfirmasi) {
      setFormError("Konfirmasi sandi baru tidak sama.");
      return;
    }
    setFormError("");
    ganti.mutate({ password_lama: sandiLama, password_baru: sandiBaru });
  };

  return (
    <AppShell dock={false}>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="mx-auto max-w-xl space-y-5"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Pengaturan
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Kelola akses buku kas gang.
          </p>
        </div>

        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold tracking-tight">
              <KeyRound className="h-5 w-5 text-emerald-700 dark:text-emerald-300" aria-hidden />
              Ganti Sandi Bendahara
            </CardTitle>
            <CardDescription>
              Setelah diganti, gunakan sandi baru untuk masuk berikutnya. Sesi di perangkat ini
              tetap aktif.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} data-testid="form-ganti-sandi" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="sandi-lama">Sandi Lama</Label>
                <Input
                  id="sandi-lama"
                  type="password"
                  data-testid="input-sandi-lama"
                  value={sandiLama}
                  onChange={(e) => {
                    setSandiLama(e.target.value);
                    setFormError("");
                  }}
                  autoComplete="current-password"
                  className="h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="sandi-baru">Sandi Baru</Label>
                <Input
                  id="sandi-baru"
                  type="password"
                  data-testid="input-sandi-baru"
                  value={sandiBaru}
                  onChange={(e) => {
                    setSandiBaru(e.target.value);
                    setFormError("");
                  }}
                  autoComplete="new-password"
                  className="h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="konfirmasi-sandi">Ulangi Sandi Baru</Label>
                <Input
                  id="konfirmasi-sandi"
                  type="password"
                  data-testid="input-konfirmasi-sandi"
                  value={konfirmasi}
                  onChange={(e) => {
                    setKonfirmasi(e.target.value);
                    setFormError("");
                  }}
                  autoComplete="new-password"
                  className="h-12"
                />
              </div>
              {formError ? (
                <p data-testid="ganti-sandi-error-message" className="text-sm font-medium text-destructive">
                  {formError}
                </p>
              ) : null}
              <Button
                type="submit"
                data-testid="btn-simpan-sandi"
                className="h-12 w-full font-semibold"
                disabled={ganti.isPending}
              >
                {ganti.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Menyimpan...
                  </>
                ) : (
                  "Simpan Sandi Baru"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold tracking-tight">
              <Coins className="h-5 w-5 text-emerald-700 dark:text-emerald-300" aria-hidden />
              Target Iuran Bulanan
            </CardTitle>
            <CardDescription>
              Nilai default saat mendaftarkan warga baru. Target tiap warga tetap bisa diubah
              sendiri di halaman Iuran Warga.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form
              data-testid="form-iuran-default"
              onSubmit={(e) => {
                e.preventDefault();
                simpanIuran.mutate(
                  { iuran_default: Number(iuranStr || "0") },
                  {
                    onSuccess: () => {
                      setIuranTersentuh(false);
                      toast.success("Target iuran default disimpan.");
                    },
                    onError: () => toast.error("Gagal menyimpan target iuran."),
                  },
                );
              }}
              className="space-y-4"
            >
              <div className="space-y-2">
                <Label htmlFor="iuran-default">Iuran per Warga per Bulan (Rupiah)</Label>
                <Input
                  id="iuran-default"
                  inputMode="numeric"
                  data-testid="input-iuran-default"
                  value={iuranStr ? angka(Number(iuranStr)) : ""}
                  onChange={(e) => {
                    setIuranTersentuh(true);
                    setIuranStr(e.target.value.replace(/\D/g, "").slice(0, 12));
                  }}
                  placeholder="0"
                  className="h-12 font-mono text-lg font-bold"
                />
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {Number(iuranStr || "0") > 0
                    ? `= ${rupiah(Number(iuranStr))} per warga setiap bulan`
                    : "Isi 0 bila gang ini tidak menetapkan iuran tetap."}
                </p>
              </div>
              <Button
                type="submit"
                data-testid="btn-simpan-iuran-default"
                className="h-12 w-full font-semibold"
                disabled={simpanIuran.isPending}
              >
                {simpanIuran.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Menyimpan...
                  </>
                ) : (
                  "Simpan Target Iuran"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold tracking-tight">
              <DatabaseBackup className="h-5 w-5 text-emerald-700 dark:text-emerald-300" aria-hidden />
              Backup Data
            </CardTitle>
            <CardDescription>
              Unduh seluruh buku kas — semua transaksi, daftar warga, dan pengaturan — dalam satu
              file untuk disimpan sebagai arsip.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button
                variant="outline"
                data-testid="btn-backup-excel"
                onClick={() => backup.mutate("excel")}
                disabled={backup.isPending}
                className="h-12 flex-1 font-semibold"
              >
                {backup.isPending && backup.variables === "excel" ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <FileSpreadsheet className="h-4 w-4" aria-hidden />
                )}
                Backup Excel
              </Button>
              <Button
                variant="outline"
                data-testid="btn-backup-json"
                onClick={() => backup.mutate("json")}
                disabled={backup.isPending}
                className="h-12 flex-1 font-semibold"
              >
                {backup.isPending && backup.variables === "json" ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <FileJson className="h-4 w-4" aria-hidden />
                )}
                Backup JSON
              </Button>
            </div>
            <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              Excel mudah dibuka pengurus; JSON berisi data mentah lengkap. Sandi bendahara tidak
              pernah disertakan di dalam backup.
            </p>

            <div className="mt-4 border-t border-slate-200 pt-4 dark:border-slate-800">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                Pulihkan dari Backup
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Pilih file Backup JSON untuk memulihkan data — seluruh transaksi dan daftar warga
                saat ini akan diganti.
              </p>
              <input
                ref={fileRef}
                type="file"
                accept=".json,application/json"
                data-testid="input-file-restore"
                className="hidden"
                onChange={pilihFile}
              />
              <Button
                variant="outline"
                data-testid="btn-pilih-restore"
                onClick={() => fileRef.current?.click()}
                disabled={pulihkan.isPending}
                className="mt-3 h-12 w-full font-semibold"
              >
                {pulihkan.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Memulihkan...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" aria-hidden /> Pilih File Backup JSON
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold tracking-tight">
              <FileArchive className="h-5 w-5 text-emerald-700 dark:text-emerald-300" aria-hidden />
              Unduh Kode Aplikasi
            </CardTitle>
            <CardDescription>
              Unduh seluruh file kode proyek ini (backend + frontend) dalam satu file ZIP untuk
              disimpan sendiri atau diunggah ke GitHub.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="outline"
              data-testid="btn-unduh-kode-zip"
              onClick={() => unduhKode.mutate()}
              disabled={unduhKode.isPending}
              className="h-12 w-full font-semibold"
            >
              {unduhKode.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Menyiapkan ZIP...
                </>
              ) : (
                <>
                  <FileArchive className="h-4 w-4" aria-hidden /> Unduh Kode (.zip)
                </>
              )}
            </Button>
            <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
              File sandi/kredensial (.env), node_modules, dan hasil build tidak disertakan. Cara
              menjalankan ada di README.md di dalam arsip.
            </p>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base font-bold tracking-tight">
              <Moon className="h-5 w-5 text-emerald-700 dark:text-emerald-300" aria-hidden />
              Tampilan
            </CardTitle>
            <CardDescription>Sesuaikan kenyamanan mata saat mencatat kas malam hari.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Mode Gelap</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Aktifkan untuk latar gelap — pilihan tersimpan di perangkat ini.
                </p>
              </div>
              <ThemeSwitch />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Konfirmasi pulihkan backup — menimpa seluruh data */}
      <Dialog
        open={fileRestore !== null}
        onOpenChange={(o) => {
          if (!o) setFileRestore(null);
        }}
      >
        <DialogContent data-testid="dialog-konfirmasi-restore" className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">
              Pulihkan backup ini?
            </DialogTitle>
            <DialogDescription>
              Seluruh transaksi dan daftar warga yang ada sekarang akan <strong>diganti</strong>{" "}
              dengan isi file{fileRestore ? ` "${fileRestore.name}"` : ""}. Sebaiknya unduh backup
              terbaru lebih dulu. Tindakan ini tidak bisa dibatalkan.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setFileRestore(null)}>
              Batal
            </Button>
            <Button
              variant="destructive"
              data-testid="btn-konfirmasi-restore"
              disabled={pulihkan.isPending}
              onClick={() => fileRestore && pulihkan.mutate(fileRestore)}
            >
              {pulihkan.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                "Ya, Pulihkan"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
