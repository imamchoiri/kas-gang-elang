import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Copy, IdCard, ListChecks, Loader2, Pencil, Trash2, UserPlus, Users2, Wallet } from "lucide-react";
import { toast } from "sonner";

import AppShell from "@/components/AppShell";
import KartuSemuaDialog from "@/components/KartuSemuaDialog";
import MonthPicker from "@/components/MonthPicker";
import WargaDetailDialog, { type DetailWarga } from "@/components/WargaDetailDialog";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useKasSettings, useResidentMutations, useResidents } from "@/hooks/useResidents";
import { apiDelete, apiGet, apiPost } from "@/lib/api";
import { angka, rupiah } from "@/lib/format";
import { hitungWarga } from "@/lib/iuran";
import { BULAN_ID, type BulkResult, type MetaInfo, type OkResult, type Resident, type Transaction, type TransactionCreate } from "@/lib/types";
import { cn } from "@/lib/utils";

const STATUS_FILTERS = [
  { id: "semua", label: "Semua" },
  { id: "lunas", label: "Lunas" },
  { id: "belum", label: "Belum Lunas" },
] as const;

type FilterId = (typeof STATUS_FILTERS)[number]["id"];

interface BarisWarga {
  id: string;
  nama: string;
  target: number;
  dibayar: number;
  kurang: number;
  lunas: boolean;
  terakhir: string;
  terdaftar: boolean;
  terdaftarSejak?: string;
  tunggakan: number;
  totalSetor: number;
}

export default function Warga() {
  const queryClient = useQueryClient();
  const { data: transactions, isPending: txPending, isError } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => apiGet<Transaction[]>("/transactions"),
  });
  const { data: meta } = useQuery({
    queryKey: ["meta"],
    queryFn: () => apiGet<MetaInfo>("/meta"),
    staleTime: 60_000,
  });
  const { data: residents, isPending: resPending } = useResidents();
  const { data: kasSettings } = useKasSettings();
  const { tambah, ubah, hapus, impor } = useResidentMutations();

  const [bulan, setBulan] = useState("");
  const [tahun, setTahun] = useState(String(new Date().getFullYear()));
  const [filter, setFilter] = useState<FilterId>("semua");

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Resident | null>(null);
  const [nama, setNama] = useState("");
  const [iuranStr, setIuranStr] = useState("");
  const [formError, setFormError] = useState("");
  const [toDelete, setToDelete] = useState<Resident | null>(null);
  const [detail, setDetail] = useState<DetailWarga | null>(null);
  const [kartuSemua, setKartuSemua] = useState(false);
  const [pilihMode, setPilihMode] = useState(false);
  const [terpilih, setTerpilih] = useState<Set<string>>(new Set());
  const [konfirmasiMassal, setKonfirmasiMassal] = useState(false);

  const togglePilih = (nama: string) =>
    setTerpilih((s) => {
      const next = new Set(s);
      if (next.has(nama)) next.delete(nama);
      else next.add(nama);
      return next;
    });

  // Lunas massal: satu permintaan untuk semua warga terpilih.
  const lunasMassal = useMutation<BulkResult, Error, { nama: string; jumlah: number }[]>({
    mutationFn: (daftar) => {
      const tanggal = meta?.month === key && meta?.today ? meta.today : `${key}-01`;
      const [ky, km] = key.split("-");
      const labelBulan = `${BULAN_ID[Number(km) - 1]} ${ky}`;
      const items: TransactionCreate[] = daftar.map((d) => ({
        type: "masuk",
        category: "Uang Kas",
        amount: d.jumlah,
        description: `Iuran ${labelBulan} — ${d.nama}`,
        date: tanggal,
        photo_id: "",
        warga: d.nama,
      }));
      return apiPost<BulkResult>("/transactions/bulk", items as unknown as Record<string, unknown>[]);
    },
    onSuccess: (r) => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      setTerpilih(new Set());
      setPilihMode(false);
      setKonfirmasiMassal(false);
      toast.success(`${r.dibuat} warga ditandai lunas.`);
    },
    onError: () => toast.error("Gagal menandai lunas massal. Coba lagi."),
  });

  // Tandai lunas cepat: satu ketuk mencatat kekurangan iuran warga, dengan opsi batal.
  const tandaiLunas = useMutation<Transaction, Error, { nama: string; jumlah: number }>({
    mutationFn: ({ nama, jumlah }) => {
      const tanggal = meta?.month === key && meta?.today ? meta.today : `${key}-01`;
      const [ky, km] = key.split("-");
      const labelBulan = `${BULAN_ID[Number(km) - 1]} ${ky}`;
      const body: TransactionCreate = {
        type: "masuk",
        category: "Uang Kas",
        amount: jumlah,
        description: `Iuran ${labelBulan} — ${nama}`,
        date: tanggal,
        photo_id: "",
        warga: nama,
      };
      return apiPost<Transaction>("/transactions", body);
    },
    onSuccess: (tx) => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success(`${tx.warga} ditandai lunas — ${rupiah(tx.amount)} tercatat.`, {
        action: {
          label: "Batalkan",
          onClick: async () => {
            try {
              await apiDelete<OkResult>(`/transactions/${tx.id}`);
              queryClient.invalidateQueries({ queryKey: ["transactions"] });
              toast.success("Pencatatan dibatalkan.");
            } catch {
              toast.error("Gagal membatalkan. Hapus manual di beranda.");
            }
          },
        },
      });
    },
    onError: () => toast.error("Gagal menandai lunas. Coba lagi."),
  });

  // Bulan/tahun default dari server (WIB) — bukan hitungan tanggal di browser.
  useEffect(() => {
    if (meta?.month && !bulan) {
      const [y, m] = meta.month.split("-");
      setBulan(String(Number(m)));
      setTahun(y);
    }
  }, [meta, bulan]);

  const tahunList = useMemo(() => {
    const years = new Set<number>([new Date().getFullYear()]);
    (transactions ?? []).forEach((t) => years.add(Number(t.date.slice(0, 4))));
    return [...years].sort((a, b) => b - a);
  }, [transactions]);

  const key = bulan ? `${tahun}-${bulan.padStart(2, "0")}` : "";

  // Gabungkan warga tetap (daftar) dengan nama yang hanya muncul di transaksi.
  const baris = useMemo<BarisWarga[]>(() => {
    if (!key) return [];
    const setor = new Map<string, { dibayar: number; terakhir: string }>();
    for (const t of transactions ?? []) {
      const n = (t.warga || "").trim();
      if (!n || t.type !== "masuk") continue;
      const k = n.toLowerCase();
      const cur = setor.get(k) ?? { dibayar: 0, terakhir: "" };
      if (t.date.startsWith(key)) cur.dibayar += t.amount;
      if (t.date > cur.terakhir) cur.terakhir = t.date;
      setor.set(k, cur);
    }

    const rows: BarisWarga[] = [];
    const sudahDipakai = new Set<string>();

    for (const w of residents ?? []) {
      const k = w.nama.trim().toLowerCase();
      sudahDipakai.add(k);
      const s = setor.get(k) ?? { dibayar: 0, terakhir: "" };
      const kurang = Math.max(0, w.iuran_bulanan - s.dibayar);
      const r = hitungWarga(w.nama, w.iuran_bulanan, w.created_at, transactions ?? [], key);
      rows.push({
        id: w.id,
        nama: w.nama,
        target: w.iuran_bulanan,
        dibayar: s.dibayar,
        kurang,
        lunas: w.iuran_bulanan > 0 ? s.dibayar >= w.iuran_bulanan : s.dibayar > 0,
        terakhir: s.terakhir,
        terdaftar: true,
        terdaftarSejak: w.created_at,
        tunggakan: r.tunggakan,
        totalSetor: r.totalSetor,
      });
    }

    // Nama dari transaksi yang belum terdaftar — tetap terlihat agar tidak hilang.
    for (const t of transactions ?? []) {
      const n = (t.warga || "").trim();
      if (!n || t.type !== "masuk") continue;
      const k = n.toLowerCase();
      if (sudahDipakai.has(k)) continue;
      sudahDipakai.add(k);
      const s = setor.get(k) ?? { dibayar: 0, terakhir: "" };
      const r = hitungWarga(n, 0, undefined, transactions ?? [], key);
      rows.push({
        id: `tx-${k}`,
        nama: n,
        target: 0,
        dibayar: s.dibayar,
        kurang: 0,
        lunas: s.dibayar > 0,
        terakhir: s.terakhir,
        terdaftar: false,
        tunggakan: 0,
        totalSetor: r.totalSetor,
      });
    }

    return rows.sort(
      (a, b) => Number(a.lunas) - Number(b.lunas) || b.dibayar - a.dibayar || a.nama.localeCompare(b.nama, "id"),
    );
  }, [transactions, residents, key]);

  const lunasCount = baris.filter((b) => b.lunas).length;
  const terkumpul = baris.reduce((s, b) => s + b.dibayar, 0);
  const totalKurang = baris.reduce((s, b) => s + b.kurang, 0);
  const totalTunggakan = baris.reduce((s, b) => s + b.tunggakan, 0);
  const shown = baris.filter((b) =>
    filter === "semua" ? true : filter === "lunas" ? b.lunas : !b.lunas,
  );

  const namaBulan = bulan ? BULAN_ID[Number(bulan) - 1] : "";

  // Kandidat lunas massal: warga terdaftar, punya target, dan belum lunas.
  const kandidatMassal = useMemo(
    () =>
      baris
        .filter((b) => b.terdaftar && b.target > 0 && !b.lunas)
        .map((b) => ({ nama: b.nama, jumlah: b.kurang > 0 ? b.kurang : b.target })),
    [baris],
  );
  const totalPilihan = kandidatMassal
    .filter((k) => terpilih.has(k.nama))
    .reduce((s, k) => s + k.jumlah, 0);

  const openTambah = () => {
    setEditing(null);
    setNama("");
    setIuranStr(kasSettings?.iuran_default ? String(kasSettings.iuran_default) : "");
    setFormError("");
    setFormOpen(true);
  };

  const openEdit = (w: BarisWarga) => {
    const found = (residents ?? []).find((r) => r.id === w.id);
    setEditing(found ?? null);
    setNama(w.nama);
    setIuranStr(w.target ? String(w.target) : kasSettings?.iuran_default ? String(kasSettings.iuran_default) : "");
    setFormError("");
    setFormOpen(true);
  };

  const simpanWarga = () => {
    const bersih = nama.trim();
    if (!bersih) {
      setFormError("Nama warga wajib diisi.");
      return;
    }
    const body = { nama: bersih, iuran_bulanan: Number(iuranStr || "0") };
    const onErr = (err: { status: number }) =>
      setFormError(err.status === 409 ? "Nama warga sudah terdaftar." : "Gagal menyimpan. Coba lagi.");
    if (editing) {
      ubah.mutate(
        { id: editing.id, body },
        {
          onSuccess: () => {
            toast.success("Data warga diperbarui.");
            setFormOpen(false);
          },
          onError: onErr,
        },
      );
    } else {
      tambah.mutate(body, {
        onSuccess: () => {
          toast.success(`${bersih} ditambahkan ke daftar warga.`);
          setFormOpen(false);
        },
        onError: onErr,
      });
    }
  };

  const imporWarga = () =>
    impor.mutate(undefined, {
      onSuccess: (r) =>
        toast.success(
          r.ditambahkan > 0
            ? `${r.ditambahkan} nama warga berhasil didaftarkan.`
            : "Semua nama dari transaksi sudah terdaftar.",
        ),
      onError: () => toast.error("Gagal mengimpor nama warga."),
    });

  // Pesan pengingat sopan untuk grup WhatsApp warga.
  const pengingat = () => {
    const belum = baris.filter((b) => !b.lunas);
    const lines: string[] = [];
    lines.push("🙏 *Pengingat Iuran Kas Gang Elang 79*");
    lines.push(`Periode: ${namaBulan} ${tahun}`);
    lines.push("");
    lines.push("Assalamualaikum / salam sejahtera Bapak/Ibu warga Gang Elang 79.");
    lines.push("Mohon maaf mengganggu, berikut pengingat iuran kas bulan ini:");
    lines.push("");
    if (belum.length === 0) {
      lines.push("✅ Alhamdulillah seluruh warga sudah menyetor iuran bulan ini.");
      lines.push("Terima kasih banyak atas kerja samanya 🙏");
    } else {
      belum.forEach((b, i) => {
        const nominal = b.kurang > 0 ? ` — kurang ${rupiah(b.kurang)}` : b.target > 0 ? ` — ${rupiah(b.target)}` : "";
        const tunggakan = b.tunggakan > b.kurang ? ` (tunggakan ${rupiah(b.tunggakan)})` : "";
        lines.push(`${i + 1}. ${b.nama}${nominal}${tunggakan}`);
      });
      lines.push("");
      if (totalKurang > 0) lines.push(`Total yang belum masuk: *${rupiah(totalKurang)}*`);
      if (totalTunggakan > totalKurang)
        lines.push(`Total tunggakan berjalan: *${rupiah(totalTunggakan)}*`);
      lines.push("Jika sudah menyetor namun masih tercatat di sini, mohon kabari bendahara ya 🙏");
      lines.push("Terima kasih atas perhatian dan kerja samanya.");
    }
    lines.push("");
    lines.push(`Sudah setor bulan ini: ${lunasCount}/${baris.length} warga`);
    lines.push(`Terkumpul: ${rupiah(terkumpul)}`);
    return lines.join("\n");
  };

  const salinPengingat = async () => {
    try {
      await navigator.clipboard.writeText(pengingat());
      toast.success("Pesan pengingat disalin — tempel ke grup WhatsApp warga!");
    } catch {
      toast.error("Gagal menyalin pesan. Coba lagi.");
    }
  };

  const isPending = txPending || resPending || !bulan;
  const kosong = baris.length === 0;

  return (
    <AppShell>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="space-y-5"
      >
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Iuran Warga
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Daftar warga tetap dan status iuran tiap bulan.
            </p>
          </div>
          <Button data-testid="btn-tambah-warga" onClick={openTambah} className="h-11 font-semibold">
            <UserPlus className="h-4 w-4" aria-hidden /> Tambah Warga
          </Button>
        </div>

        <div data-testid="iuran-warga-container" className="space-y-4">
          <div className="flex flex-wrap items-end gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <MonthPicker
              bulan={bulan || "1"}
              tahun={tahun}
              tahunList={tahunList}
              onBulan={setBulan}
              onTahun={setTahun}
              bulanTestid="select-bulan-warga"
              tahunTestid="select-tahun-warga"
            />
            <div className="ml-auto flex flex-wrap gap-2">
              <Button
                variant="outline"
                data-testid="btn-impor-warga"
                onClick={imporWarga}
                disabled={impor.isPending}
                className="h-11"
              >
                {impor.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <Users2 className="h-4 w-4" aria-hidden />
                )}
                Impor dari Transaksi
              </Button>
              <Button
                variant="outline"
                data-testid="btn-kartu-semua"
                onClick={() => setKartuSemua(true)}
                disabled={(residents ?? []).length === 0}
                className="h-11"
              >
                <IdCard className="h-4 w-4" aria-hidden /> Kartu Semua
              </Button>
              <Button
                variant="outline"
                data-testid="btn-pengingat-wa"
                onClick={salinPengingat}
                disabled={kosong}
                className="h-11"
              >
                <Copy className="h-4 w-4" aria-hidden /> Pengingat WA
              </Button>
            </div>
          </div>

          {isPending ? (
            <div className="grid grid-cols-2 gap-4">
              {["a", "b"].map((k) => (
                <span key={k} className="block h-24 animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-700" />
              ))}
            </div>
          ) : isError ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
              Tidak dapat memuat data warga. Periksa koneksi lalu muat ulang halaman.
            </div>
          ) : kosong ? (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white/50 p-8 text-center dark:border-slate-700 dark:bg-slate-900/50">
              <p className="font-semibold text-slate-700 dark:text-slate-300">Belum ada warga terdaftar</p>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Tambah warga satu per satu, atau impor nama dari transaksi yang sudah dicatat.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/40">
                  <p
                    data-testid="warga-sudah-bayar"
                    className="font-mono text-xl font-bold tracking-tight text-emerald-800 dark:text-emerald-200"
                  >
                    {lunasCount}
                    <span className="text-sm font-semibold text-emerald-700/80 dark:text-emerald-300/80">
                      {" "}
                      / {baris.length}
                    </span>
                  </p>
                  <p className="mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700/80 dark:text-emerald-300/80">
                    Lunas — {namaBulan} {tahun}
                  </p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <p
                    data-testid="warga-terkumpul"
                    className="font-mono text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100"
                  >
                    {rupiah(terkumpul)}
                  </p>
                  <p className="mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                    Terkumpul Bulan Ini
                  </p>
                </div>
                <div className="col-span-2 rounded-2xl border border-amber-100 bg-amber-50 p-4 sm:col-span-1 dark:border-amber-900/50 dark:bg-amber-950/40">
                  <p
                    data-testid="warga-total-kurang"
                    className="font-mono text-xl font-bold tracking-tight text-amber-800 dark:text-amber-200"
                  >
                    {rupiah(totalKurang)}
                  </p>
                  <p className="mt-1 text-xs font-semibold uppercase tracking-[0.12em] text-amber-700/80 dark:text-amber-300/80">
                    Belum Masuk Bulan Ini
                  </p>
                  {totalTunggakan > 0 ? (
                    <p
                      data-testid="warga-total-tunggakan"
                      className="mt-2 border-t border-amber-200/70 pt-2 text-xs font-semibold text-amber-800 dark:border-amber-900/60 dark:text-amber-300"
                    >
                      Tunggakan berjalan: <span className="font-mono">{rupiah(totalTunggakan)}</span>
                    </p>
                  ) : null}
                </div>
              </div>

              <div className="flex flex-wrap gap-2" role="group" aria-label="Filter status bayar">
                {STATUS_FILTERS.map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    data-testid="filter-status-warga"
                    data-selected={filter === f.id || undefined}
                    onClick={() => setFilter(f.id)}
                    className={cn(
                      "h-9 rounded-full border px-3.5 text-xs font-semibold transition",
                      filter === f.id
                        ? "border-emerald-700 bg-emerald-700 text-white shadow-sm"
                        : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300 hover:text-emerald-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300",
                    )}
                  >
                    {f.label}
                  </button>
                ))}
                <Button
                  variant={pilihMode ? "default" : "outline"}
                  size="sm"
                  data-testid="btn-mode-pilih"
                  onClick={() => {
                    setPilihMode((p) => !p);
                    setTerpilih(new Set());
                  }}
                  className="ml-auto h-9 text-xs font-semibold"
                >
                  <ListChecks className="h-4 w-4" aria-hidden />
                  {pilihMode ? "Selesai" : "Lunas Massal"}
                </Button>
              </div>

              {pilihMode ? (
                <div
                  data-testid="toolbar-lunas-massal"
                  className="flex flex-wrap items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 dark:border-emerald-900/60 dark:bg-emerald-950/40"
                >
                  <p className="text-xs font-semibold text-emerald-900 dark:text-emerald-100">
                    {terpilih.size > 0
                      ? `${terpilih.size} warga dipilih · ${rupiah(totalPilihan)}`
                      : "Pilih warga yang sudah menyetor malam ini"}
                  </p>
                  <div className="ml-auto flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      data-testid="btn-pilih-semua-belum"
                      onClick={() => setTerpilih(new Set(kandidatMassal.map((w) => w.nama)))}
                      className="h-9 text-xs"
                    >
                      Pilih Semua ({kandidatMassal.length})
                    </Button>
                    <Button
                      size="sm"
                      data-testid="btn-lunas-massal"
                      disabled={terpilih.size === 0 || lunasMassal.isPending}
                      onClick={() => setKonfirmasiMassal(true)}
                      className="h-9 text-xs font-semibold"
                    >
                      {lunasMassal.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <Wallet className="h-4 w-4" aria-hidden />
                      )}
                      Tandai Lunas
                    </Button>
                  </div>
                </div>
              ) : null}

              <div className="space-y-3" data-testid="daftar-warga-container">
                {shown.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-slate-300 bg-white/50 p-6 text-center text-sm text-slate-500 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-400">
                    Tidak ada warga pada filter ini.
                  </div>
                ) : (
                  shown.map((w) => (
                    <div
                      key={w.id}
                      data-testid="warga-item"
                      className={cn(
                        "rounded-xl border bg-white p-4 shadow-xs dark:bg-slate-900",
                        w.lunas
                          ? "border-emerald-200 dark:border-emerald-900/60"
                          : "border-amber-200 dark:border-amber-900/50",
                      )}
                    >
                      <div className="flex items-start gap-3">
                        {pilihMode && w.terdaftar && w.target > 0 && !w.lunas ? (
                          <Checkbox
                            data-testid="checkbox-warga"
                            aria-label={`Pilih ${w.nama}`}
                            checked={terpilih.has(w.nama)}
                            onCheckedChange={() => togglePilih(w.nama)}
                            className="mt-1.5 shrink-0"
                          />
                        ) : null}
                        <button
                          type="button"
                          data-testid="btn-detail-warga"
                          onClick={() =>
                            setDetail({
                              nama: w.nama,
                              target: w.target,
                              terdaftarSejak: w.terdaftarSejak,
                            })
                          }
                          className="flex min-w-0 flex-1 items-center gap-3 rounded-lg text-left transition-opacity hover:opacity-80"
                          aria-label={`Lihat riwayat setoran ${w.nama}`}
                        >
                          <span
                            className={cn(
                              "flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-bold",
                              w.lunas
                                ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300"
                                : "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
                            )}
                            aria-hidden
                          >
                            {w.nama.trim().charAt(0).toUpperCase()}
                          </span>
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-sm font-semibold text-slate-800 dark:text-slate-200">
                              {w.nama}
                            </span>
                            <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
                              {w.target > 0 ? `Target ${rupiah(w.target)}/bln` : "Tanpa target tetap"}
                            </span>
                          </span>
                        </button>
                        <div className="flex shrink-0 items-center gap-0.5">
                          {w.terdaftar && !w.lunas && w.target > 0 && !pilihMode ? (
                            <Button
                              size="sm"
                              variant="outline"
                              data-testid="btn-tandai-lunas"
                              aria-label={`Tandai ${w.nama} lunas`}
                              title={`Catat ${rupiah(w.kurang > 0 ? w.kurang : w.target)} sebagai iuran lunas`}
                              disabled={tandaiLunas.isPending}
                              onClick={() =>
                                tandaiLunas.mutate({
                                  nama: w.nama,
                                  jumlah: w.kurang > 0 ? w.kurang : w.target,
                                })
                              }
                              className="h-9 border-emerald-200 px-2 text-xs font-semibold text-emerald-700 hover:bg-emerald-50 dark:border-emerald-900/60 dark:text-emerald-300"
                            >
                              {tandaiLunas.isPending && tandaiLunas.variables?.nama === w.nama ? (
                                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                              ) : (
                                <Wallet className="h-4 w-4" aria-hidden />
                              )}
                              Lunas
                            </Button>
                          ) : null}
                          <Button
                            variant="ghost"
                            size="icon-xs"
                            data-testid="btn-edit-warga"
                            aria-label={`Ubah target iuran ${w.nama}`}
                            title={w.terdaftar ? "Ubah target iuran" : "Daftarkan warga ini"}
                            onClick={() => openEdit(w)}
                            className="h-9 w-9 text-slate-400 hover:text-emerald-700"
                          >
                            <Pencil className="h-4 w-4" aria-hidden />
                          </Button>
                          {w.terdaftar ? (
                            <Button
                              variant="ghost"
                              size="icon-xs"
                              data-testid="btn-hapus-warga"
                              aria-label={`Hapus ${w.nama} dari daftar`}
                              title="Hapus dari daftar warga"
                              onClick={() => {
                                const found = (residents ?? []).find((r) => r.id === w.id);
                                if (found) setToDelete(found);
                              }}
                              className="h-9 w-9 text-slate-400 hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" aria-hidden />
                            </Button>
                          ) : null}
                        </div>
                      </div>
                      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-x-2 gap-y-1.5 border-t border-slate-100 pt-2.5 pl-13 dark:border-slate-800">
                        <span className="flex flex-wrap items-center gap-1.5">
                          {w.lunas ? (
                            <span className="inline-flex whitespace-nowrap rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                              Lunas
                            </span>
                          ) : (
                            <span
                              data-testid="badge-kurang-bayar"
                              className="inline-flex whitespace-nowrap rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800 dark:bg-amber-900/40 dark:text-amber-300"
                            >
                              {w.kurang > 0 ? `Kurang ${rupiah(w.kurang)}` : "Belum Bayar"}
                            </span>
                          )}
                          {w.tunggakan > 0 ? (
                            <span
                              data-testid="badge-tunggakan"
                              className="inline-flex whitespace-nowrap rounded-full bg-rose-100 px-2.5 py-0.5 text-xs font-semibold text-rose-800 dark:bg-rose-900/40 dark:text-rose-300"
                            >
                              Tunggakan {rupiah(w.tunggakan)}
                            </span>
                          ) : null}
                        </span>
                        <span className="whitespace-nowrap font-mono text-sm font-bold tracking-tight text-slate-700 dark:text-slate-300">
                          {w.terakhir ? `Setor ${rupiah(w.dibayar)}` : "Belum pernah setor"}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </div>
      </motion.div>

      {/* Tambah / ubah warga */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent data-testid="dialog-form-warga" className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">
              {editing ? "Ubah Data Warga" : "Tambah Warga"}
            </DialogTitle>
            <DialogDescription>
              Target iuran dipakai untuk menghitung sisa yang belum dibayar tiap bulan.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="nama-warga">Nama Warga</Label>
              <Input
                id="nama-warga"
                data-testid="input-nama-warga"
                value={nama}
                onChange={(e) => {
                  setNama(e.target.value);
                  setFormError("");
                }}
                placeholder="mis. Pak Budi"
                className="h-12"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="iuran-warga">Target Iuran per Bulan (Rupiah)</Label>
              <Input
                id="iuran-warga"
                inputMode="numeric"
                data-testid="input-iuran-warga"
                value={iuranStr ? angka(Number(iuranStr)) : ""}
                onChange={(e) => setIuranStr(e.target.value.replace(/\D/g, "").slice(0, 12))}
                placeholder="0"
                className="h-12 font-mono text-lg font-bold"
              />
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kosongkan atau isi 0 bila warga ini tanpa target tetap.
              </p>
            </div>
            {formError ? (
              <p data-testid="form-warga-error" className="text-sm font-medium text-destructive">
                {formError}
              </p>
            ) : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setFormOpen(false)}>
              Batal
            </Button>
            <Button
              data-testid="btn-simpan-warga"
              onClick={simpanWarga}
              disabled={tambah.isPending || ubah.isPending}
            >
              {tambah.isPending || ubah.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Konfirmasi hapus warga */}
      <Dialog
        open={toDelete !== null}
        onOpenChange={(o) => {
          if (!o) setToDelete(null);
        }}
      >
        <DialogContent data-testid="dialog-hapus-warga" className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">
              Hapus warga dari daftar?
            </DialogTitle>
            <DialogDescription>
              {toDelete
                ? `${toDelete.nama} akan dihapus dari daftar warga. Transaksi yang sudah dicatat tidak terhapus.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setToDelete(null)}>
              Batal
            </Button>
            <Button
              variant="destructive"
              data-testid="btn-konfirmasi-hapus-warga"
              disabled={hapus.isPending}
              onClick={() =>
                toDelete &&
                hapus.mutate(toDelete.id, {
                  onSuccess: () => {
                    toast.success("Warga dihapus dari daftar.");
                    setToDelete(null);
                  },
                  onError: () => toast.error("Gagal menghapus warga."),
                })
              }
            >
              {hapus.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : "Ya, Hapus"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Riwayat & kartu iuran per warga */}
      <WargaDetailDialog
        warga={detail}
        transactions={transactions ?? []}
        bulanTerpilih={key || `${tahun}-01`}
        onClose={() => setDetail(null)}
      />
      {/* Konfirmasi lunas massal */}
      <Dialog open={konfirmasiMassal} onOpenChange={setKonfirmasiMassal}>
        <DialogContent data-testid="dialog-konfirmasi-massal" className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">
              Tandai {terpilih.size} warga lunas?
            </DialogTitle>
            <DialogDescription>
              Total {rupiah(totalPilihan)} akan dicatat sebagai pemasukan iuran {namaBulan} {tahun}{" "}
              untuk: {kandidatMassal.filter((k) => terpilih.has(k.nama)).map((k) => k.nama).join(", ")}.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setKonfirmasiMassal(false)}>
              Batal
            </Button>
            <Button
              data-testid="btn-konfirmasi-massal"
              disabled={lunasMassal.isPending}
              onClick={() =>
                lunasMassal.mutate(kandidatMassal.filter((k) => terpilih.has(k.nama)))
              }
            >
              {lunasMassal.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                "Ya, Catat Semua"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Kartu iuran semua warga */}
      <KartuSemuaDialog
        open={kartuSemua}
        residents={residents ?? []}
        transactions={transactions ?? []}
        bulanTerpilih={key || `${tahun}-01`}
        onClose={() => setKartuSemua(false)}
      />
    </AppShell>
  );
}
