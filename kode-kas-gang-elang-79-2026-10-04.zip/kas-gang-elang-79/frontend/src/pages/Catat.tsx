import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "motion/react";
import { ArrowDownRight, ArrowUpRight, Camera, Loader2, X } from "lucide-react";
import { toast } from "sonner";

import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ApiError, apiGet, apiPost, apiPostForm, apiPut } from "@/lib/api";
import { angka, rupiah } from "@/lib/format";
import { compressImage } from "@/lib/photo";
import {
  KATEGORI_MASUK,
  type MetaInfo,
  type PhotoRef,
  type Transaction,
  type TransactionCreate,
  type TxType,
} from "@/lib/types";
import { cn } from "@/lib/utils";

export default function Catat() {
  const [sp] = useSearchParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const editId = sp.get("id");
  const [type, setType] = useState<TxType>(sp.get("type") === "keluar" ? "keluar" : "masuk");
  const [date, setDate] = useState("");
  const [kategoriMasuk, setKategoriMasuk] = useState("");
  const [kategoriKeluar, setKategoriKeluar] = useState("");
  const [amountStr, setAmountStr] = useState("");
  const [keterangan, setKeterangan] = useState("");
  const [warga, setWarga] = useState("");
  const [prefilled, setPrefilled] = useState(false);

  // Foto bukti: blob baru (dari kamera/galeri, sudah dikompres) atau id foto lama (mode edit).
  const [photoBlob, setPhotoBlob] = useState<Blob | null>(null);
  const [photoPreview, setPhotoPreview] = useState("");
  const [photoId, setPhotoId] = useState("");

  // "Hari ini" di-anchor di server (WIB) — browser tidak berhitung tanggal sendiri.
  const { data: meta } = useQuery({
    queryKey: ["meta"],
    queryFn: () => apiGet<MetaInfo>("/meta"),
    staleTime: 60_000,
  });
  // Daftar transaksi dipakai untuk mengisi ulang form saat mode edit.
  const { data: transactions } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => apiGet<Transaction[]>("/transactions"),
  });

  const editing = useMemo(
    () => (editId ? (transactions ?? []).find((t) => t.id === editId) : undefined),
    [editId, transactions],
  );
  const notFound = Boolean(editId) && Boolean(transactions) && !editing;

  // Saran nama warga dari setoran sebelumnya — biar isi cepat dan ejaan konsisten.
  const namaWarga = useMemo(() => {
    const set = new Set<string>();
    (transactions ?? []).forEach((t) => {
      if (t.type === "masuk" && t.warga.trim()) set.add(t.warga.trim());
    });
    return [...set].sort((a, b) => a.localeCompare(b, "id"));
  }, [transactions]);

  // Prefill sekali saat data transaksi yang diedit tersedia.
  useEffect(() => {
    if (editing && !prefilled) {
      setType(editing.type);
      setDate(editing.date);
      setKategoriMasuk(editing.type === "masuk" ? editing.category : "");
      setKategoriKeluar(editing.type === "keluar" ? editing.category : "");
      setAmountStr(String(editing.amount));
      setKeterangan(editing.description);
      setWarga(editing.warga);
      setPhotoId(editing.photo_id);
      setPhotoPreview(editing.photo_id ? `/api/photos/${editing.photo_id}` : "");
      setPrefilled(true);
    }
  }, [editing, prefilled]);

  useEffect(() => {
    if (meta?.today && !date && !editId) setDate(meta.today);
  }, [meta, date, editId]);

  const amount = Number(amountStr || "0");

  const onPickPhoto = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = ""; // biar bisa pilih file yang sama lagi
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Pilih file foto (JPG/PNG).");
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      toast.error("Ukuran foto terlalu besar (maks 12 MB).");
      return;
    }
    try {
      const blob = await compressImage(file);
      if (photoPreview.startsWith("blob:")) URL.revokeObjectURL(photoPreview);
      setPhotoBlob(blob);
      setPhotoPreview(URL.createObjectURL(blob));
    } catch {
      toast.error("Gagal memproses foto. Coba file lain.");
    }
  };

  const removePhoto = () => {
    if (photoPreview.startsWith("blob:")) URL.revokeObjectURL(photoPreview);
    setPhotoBlob(null);
    setPhotoPreview("");
    setPhotoId("");
  };

  const simpan = useMutation<Transaction, ApiError>({
    mutationFn: async () => {
      let pid = photoId;
      if (photoBlob) {
        const fd = new FormData();
        fd.append("file", photoBlob, "bukti.jpg");
        pid = (await apiPostForm<PhotoRef>("/photos", fd)).id;
      }
      const body: TransactionCreate = {
        type,
        category: type === "masuk" ? kategoriMasuk : kategoriKeluar.trim(),
        amount,
        description: keterangan.trim(),
        date,
        photo_id: pid,
        warga: warga.trim(),
      };
      return editId
        ? apiPut<Transaction>(`/transactions/${editId}`, body)
        : apiPost<Transaction>("/transactions", body);
    },
    onSuccess: (tx) => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success(
        editId
          ? "Transaksi berhasil diperbarui."
          : `${tx.type === "masuk" ? "Pemasukan" : "Pengeluaran"} ${rupiah(tx.amount)} berhasil dicatat`,
      );
      navigate("/", { replace: true });
    },
    onError: (err) => {
      toast.error(
        err.status === 422
          ? "Data tidak valid — periksa kembali isian."
          : "Gagal menyimpan transaksi. Coba lagi.",
      );
    },
  });

  const valid = amount > 0 && date !== "" && (type === "keluar" || kategoriMasuk !== "");
  const isEdit = Boolean(editId);

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!valid) {
      toast.error("Lengkapi tanggal, kategori, dan jumlah terlebih dahulu.");
      return;
    }
    simpan.mutate();
  };

  if (notFound) {
    return (
      <AppShell dock={false}>
        <div className="mx-auto max-w-xl rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
          Transaksi tidak ditemukan. Mungkin sudah dihapus — kembali ke beranda dan coba lagi.
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell dock={false}>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="mx-auto max-w-xl space-y-5"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            {isEdit ? "Edit Transaksi" : type === "masuk" ? "Catat Pemasukan" : "Catat Pengeluaran"}
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            {isEdit
              ? "Ubah detail transaksi lalu simpan kembali ke buku kas."
              : "Isi detail transaksi lalu simpan ke buku kas."}
          </p>
        </div>

        <form data-testid="form-transaksi" onSubmit={onSubmit} className="space-y-5">
          <div
            className="grid grid-cols-2 gap-2 rounded-2xl bg-muted p-1.5"
            role="group"
            aria-label="Jenis transaksi"
          >
            <button
              type="button"
              data-testid="pilih-jenis-masuk"
              onClick={() => setType("masuk")}
              data-selected={type === "masuk" || undefined}
              className={cn(
                "flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-semibold transition",
                type === "masuk"
                  ? "bg-emerald-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200",
              )}
            >
              <ArrowUpRight className="h-4 w-4" aria-hidden /> Pemasukan
            </button>
            <button
              type="button"
              data-testid="pilih-jenis-keluar"
              onClick={() => setType("keluar")}
              data-selected={type === "keluar" || undefined}
              className={cn(
                "flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-semibold transition",
                type === "keluar"
                  ? "bg-rose-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200",
              )}
            >
              <ArrowDownRight className="h-4 w-4" aria-hidden /> Pengeluaran
            </button>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tanggal">Tanggal</Label>
            <Input
              id="tanggal"
              type="date"
              data-testid="input-transaksi-tanggal"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-12"
              required
            />
          </div>

          {type === "masuk" ? (
            <div className="space-y-2">
              <Label htmlFor="kategori">Kategori Pemasukan</Label>
              <Select value={kategoriMasuk} onValueChange={(v: string) => setKategoriMasuk(v)}>
                <SelectTrigger id="kategori" data-testid="input-transaksi-kategori" className="h-12 w-full">
                  <SelectValue placeholder="Pilih kategori" />
                </SelectTrigger>
                <SelectContent>
                  {KATEGORI_MASUK.map((k) => (
                    <SelectItem key={k} value={k}>
                      {k}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Kategori pemasukan kas sudah ditetapkan pengurus.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="kategori-bebas">
                Kategori Pengeluaran <span className="font-normal text-slate-400">(bebas, opsional)</span>
              </Label>
              <Input
                id="kategori-bebas"
                data-testid="input-transaksi-kategori"
                value={kategoriKeluar}
                onChange={(e) => setKategoriKeluar(e.target.value)}
                placeholder="mis. Sembako, Listrik, Konsumsi Ronda"
                className="h-12"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="jumlah">Jumlah (Rupiah)</Label>
            <Input
              id="jumlah"
              inputMode="numeric"
              data-testid="input-transaksi-jumlah"
              value={amountStr ? angka(amount) : ""}
              onChange={(e) => setAmountStr(e.target.value.replace(/\D/g, "").slice(0, 12))}
              placeholder="0"
              className="h-12 font-mono text-lg font-bold"
            />
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {amount > 0
                ? `= ${rupiah(amount)}`
                : "Tulis tanpa titik — biar tidak salah hitung nol."}
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="keterangan">
              Keterangan <span className="font-normal text-slate-400">(bebas)</span>
            </Label>
            <Textarea
              id="keterangan"
              data-testid="input-transaksi-keterangan"
              value={keterangan}
              onChange={(e) => setKeterangan(e.target.value)}
              placeholder="mis. Denda ronda — Pak Budi"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="warga">
              Nama Warga <span className="font-normal text-slate-400">(opsional)</span>
            </Label>
            <Input
              id="warga"
              data-testid="input-transaksi-warga"
              value={warga}
              onChange={(e) => setWarga(e.target.value)}
              list="daftar-warga"
              placeholder="mis. Pak Budi"
              autoComplete="off"
              className="h-12"
            />
            <datalist id="daftar-warga">
              {namaWarga.map((n) => (
                <option key={n} value={n} />
              ))}
            </datalist>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Isi agar iuran warga terpantau di halaman Iuran Warga.
            </p>
          </div>

          <div className="space-y-2">
            <Label>
              Foto Bukti <span className="font-normal text-slate-400">(opsional)</span>
            </Label>
            {photoPreview ? (
              <div className="relative w-fit">
                <img
                  src={photoPreview}
                  alt="Pratinjau foto bukti"
                  data-testid="preview-foto-bukti"
                  className="h-28 w-28 rounded-xl border border-slate-200 object-cover dark:border-slate-700"
                />
                <button
                  type="button"
                  data-testid="btn-hapus-foto-bukti"
                  aria-label="Hapus foto bukti"
                  title="Hapus foto bukti"
                  onClick={removePhoto}
                  className="absolute -right-2 -top-2 flex h-8 w-8 items-center justify-center rounded-full bg-slate-900 text-white shadow-md dark:bg-slate-100 dark:text-slate-900"
                >
                  <X className="h-4 w-4" aria-hidden />
                </button>
              </div>
            ) : (
              <label className="flex h-24 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-slate-300 bg-white text-sm font-medium text-slate-500 transition hover:border-emerald-400 hover:text-emerald-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
                <Camera className="h-5 w-5" aria-hidden />
                Ambil / pilih foto
                <input
                  type="file"
                  accept="image/*"
                  data-testid="input-foto-bukti"
                  className="hidden"
                  onChange={onPickPhoto}
                />
              </label>
            )}
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Foto otomatis dikecilkan sebelum dikirim — hemat kuota.
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              data-testid="btn-batal-transaksi"
              onClick={() => navigate(-1)}
              className="h-12 flex-1"
            >
              Batal
            </Button>
            <Button
              type="submit"
              data-testid="btn-simpan-transaksi"
              disabled={!valid || simpan.isPending}
              className="h-12 flex-[2] font-semibold"
            >
              {simpan.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Menyimpan...
                </>
              ) : isEdit ? (
                "Simpan Perubahan"
              ) : (
                "Simpan ke Buku Kas"
              )}
            </Button>
          </div>
        </form>
      </motion.div>
    </AppShell>
  );
}
