import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Copy, Download, Loader2, NotebookPen } from "lucide-react";
import { toast } from "sonner";

import AppShell from "@/components/AppShell";
import { KategoriBadge } from "@/components/kategori";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { apiDownload, apiGet } from "@/lib/api";
import { useMeetingNote, useSaveMeetingNote } from "@/hooks/useNotes";
import { rupiah, rupiahPendek } from "@/lib/format";
import { BULAN_ID, BULAN_SINGKAT, KATEGORI_MASUK, type MetaInfo, type Transaction } from "@/lib/types";

export default function Laporan() {
  const { data: transactions, isPending, isError } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => apiGet<Transaction[]>("/transactions"),
  });
  const { data: meta } = useQuery({
    queryKey: ["meta"],
    queryFn: () => apiGet<MetaInfo>("/meta"),
    staleTime: 60_000,
  });

  const [tahun, setTahun] = useState(String(new Date().getFullYear()));

  // Catatan rapat per tahun — tersimpan di server.
  const { data: note } = useMeetingNote(tahun);
  const simpanNote = useSaveMeetingNote(tahun);
  const [catatan, setCatatan] = useState("");
  const [catatanTersentuh, setCatatanTersentuh] = useState(false);

  useEffect(() => {
    setCatatan(note?.text ?? "");
    setCatatanTersentuh(false);
  }, [note]);

  useEffect(() => {
    if (meta?.month) setTahun(meta.month.slice(0, 4));
  }, [meta]);

  const tahunList = useMemo(() => {
    const years = new Set<number>([new Date().getFullYear()]);
    (transactions ?? []).forEach((t) => years.add(Number(t.date.slice(0, 4))));
    return [...years].sort((a, b) => b - a);
  }, [transactions]);

  const laporan = useMemo(() => {
    const list = (transactions ?? []).filter((t) => t.date.startsWith(tahun));
    const masuk = list.filter((t) => t.type === "masuk").reduce((s, t) => s + t.amount, 0);
    const keluar = list.filter((t) => t.type === "keluar").reduce((s, t) => s + t.amount, 0);

    const perBulan = BULAN_SINGKAT.map((b, i) => {
      const mk = `${tahun}-${String(i + 1).padStart(2, "0")}`;
      const bulanList = list.filter((t) => t.date.startsWith(mk));
      const m = bulanList.filter((t) => t.type === "masuk").reduce((s, t) => s + t.amount, 0);
      const k = bulanList.filter((t) => t.type === "keluar").reduce((s, t) => s + t.amount, 0);
      return { bulan: b, bulanPanjang: BULAN_ID[i], pemasukan: m, pengeluaran: k, selisih: m - k };
    });

    const perKategori = KATEGORI_MASUK.map((k) => ({
      kategori: k,
      total: list.filter((t) => t.type === "masuk" && t.category === k).reduce((s, t) => s + t.amount, 0),
    }));

    const wargaMap = new Map<string, number>();
    list.forEach((t) => {
      const n = (t.warga || "").trim();
      if (t.type === "masuk" && n) wargaMap.set(n, (wargaMap.get(n) ?? 0) + t.amount);
    });
    const perWarga = [...wargaMap.entries()]
      .map(([nama, total]) => ({ nama, total }))
      .sort((a, b) => b.total - a.total);

    const keluarMap = new Map<string, number>();
    list.forEach((t) => {
      if (t.type === "keluar") {
        const k = t.category || "Lain-lain";
        keluarMap.set(k, (keluarMap.get(k) ?? 0) + t.amount);
      }
    });
    const perPengeluaran = [...keluarMap.entries()]
      .map(([kategori, total]) => ({ kategori, total }))
      .sort((a, b) => b.total - a.total);

    const saldoSemua = (transactions ?? []).reduce(
      (s, t) => s + (t.type === "masuk" ? t.amount : -t.amount),
      0,
    );
    const bulanAktif = perBulan.filter((b) => b.pemasukan > 0 || b.pengeluaran > 0).length;

    return {
      list,
      masuk,
      keluar,
      selisih: masuk - keluar,
      perBulan,
      perKategori,
      perWarga,
      perPengeluaran,
      saldoSemua,
      bulanAktif,
    };
  }, [transactions, tahun]);

  const unduhExcel = useMutation({
    mutationFn: () =>
      apiDownload(
        `/transactions/export?year=${tahun}`,
        `laporan-tahunan-kas-gang-elang-79-${tahun}.xlsx`,
      ),
    onSuccess: () => toast.success("Laporan tahunan berhasil diunduh."),
    onError: () => toast.error("Gagal mengunduh laporan. Coba lagi."),
  });

  const salinWa = async () => {
    const lines: string[] = [];
    lines.push("📊 *Laporan Tahunan Kas Gang Elang 79*");
    lines.push(`Tahun ${tahun}`);
    lines.push("");
    lines.push(`Total Pemasukan: *${rupiah(laporan.masuk)}*`);
    lines.push(`Total Pengeluaran: *${rupiah(laporan.keluar)}*`);
    lines.push(`Selisih Tahun Ini: *${rupiah(laporan.selisih)}*`);
    lines.push(`Saldo Kas Saat Ini: *${rupiah(laporan.saldoSemua)}*`);
    lines.push("");
    lines.push("*Pemasukan per Kategori:*");
    const adaKategori = laporan.perKategori.filter((k) => k.total > 0);
    if (adaKategori.length === 0) lines.push("• Tidak ada");
    adaKategori.forEach((k) => lines.push(`• ${k.kategori}: ${rupiah(k.total)}`));
    lines.push("");
    lines.push("*Pengeluaran Terbesar:*");
    if (laporan.perPengeluaran.length === 0) lines.push("• Tidak ada");
    laporan.perPengeluaran.slice(0, 5).forEach((k) => lines.push(`• ${k.kategori}: ${rupiah(k.total)}`));
    if (laporan.perWarga.length > 0) {
      lines.push("");
      lines.push("*Setoran Warga Teratas:*");
      laporan.perWarga.slice(0, 5).forEach((w, i) => lines.push(`${i + 1}. ${w.nama}: ${rupiah(w.total)}`));
    }
    lines.push("");
    lines.push("Terima kasih atas kepercayaan dan kerja sama warga sepanjang tahun ini 🙏");
    if (catatan.trim()) {
      lines.push("");
      lines.push("*Catatan Rapat:*");
      lines.push(catatan.trim());
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      toast.success("Laporan tahunan disalin — siap dibagikan ke grup warga!");
    } catch {
      toast.error("Gagal menyalin laporan. Coba lagi.");
    }
  };

  return (
    <AppShell>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="space-y-5"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Laporan Tahunan
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Ringkasan satu halaman untuk dibacakan di rapat warga.
          </p>
        </div>

        <div data-testid="laporan-tahunan-container" className="space-y-4">
          <div className="flex flex-wrap items-end gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <div className="space-y-1.5">
              <Label htmlFor="tahun-laporan">Tahun</Label>
              <Select value={tahun} onValueChange={(v: string) => setTahun(v)}>
                <SelectTrigger id="tahun-laporan" data-testid="select-tahun-laporan" className="h-11 w-32">
                  <SelectValue>{tahun}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {tahunList.map((y) => (
                    <SelectItem key={y} value={String(y)}>
                      {y}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="ml-auto flex flex-wrap gap-2">
              <Button
                variant="outline"
                data-testid="btn-unduh-laporan"
                onClick={() => unduhExcel.mutate()}
                disabled={unduhExcel.isPending}
                className="h-11"
              >
                {unduhExcel.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <Download className="h-4 w-4" aria-hidden />
                )}
                Unduh Excel
              </Button>
              <Button variant="outline" data-testid="btn-salin-laporan" onClick={salinWa} className="h-11">
                <Copy className="h-4 w-4" aria-hidden /> Salin ke WA
              </Button>
            </div>
          </div>

          {isPending ? (
            <div className="grid gap-4 sm:grid-cols-3">
              {["a", "b", "c"].map((k) => (
                <span key={k} className="block h-24 animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-700" />
              ))}
            </div>
          ) : isError ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
              Tidak dapat memuat laporan. Periksa koneksi lalu muat ulang halaman.
            </div>
          ) : (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/40">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700/80 dark:text-emerald-300/80">
                    Pemasukan {tahun}
                  </p>
                  <p
                    data-testid="laporan-total-pemasukan"
                    className="mt-1 font-mono text-xl font-bold tracking-tight text-emerald-800 dark:text-emerald-200"
                  >
                    {rupiah(laporan.masuk)}
                  </p>
                </div>
                <div className="rounded-2xl border border-rose-100 bg-rose-50 p-4 dark:border-rose-900/50 dark:bg-rose-950/40">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-rose-700/80 dark:text-rose-300/80">
                    Pengeluaran {tahun}
                  </p>
                  <p
                    data-testid="laporan-total-pengeluaran"
                    className="mt-1 font-mono text-xl font-bold tracking-tight text-rose-700 dark:text-rose-300"
                  >
                    {rupiah(laporan.keluar)}
                  </p>
                </div>
                <div className="rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 p-4 text-white shadow-lg shadow-emerald-950/15">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-emerald-200">
                    Saldo Kas Saat Ini
                  </p>
                  <p
                    data-testid="laporan-saldo"
                    className="mt-1 font-mono text-xl font-bold tracking-tight text-white"
                  >
                    {rupiah(laporan.saldoSemua)}
                  </p>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  Grafik Pemasukan vs Pengeluaran {tahun}
                </h2>
                <div className="mt-3 h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={laporan.perBulan} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#CBD5E1" />
                      <XAxis dataKey="bulan" tickLine={false} axisLine={false} fontSize={12} />
                      <YAxis
                        tickFormatter={(v: number) => rupiahPendek(v)}
                        tickLine={false}
                        axisLine={false}
                        fontSize={12}
                        width={64}
                      />
                      <Tooltip
                        formatter={(value: number, name: string) => [rupiah(value), name]}
                        labelFormatter={(label: string) => `Bulan ${label}`}
                      />
                      <Legend />
                      <Bar dataKey="pemasukan" name="Pemasukan" fill="#047857" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="pengeluaran" name="Pengeluaran" fill="#DC2626" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  Rekap per Bulan
                </h2>
                <div className="mt-2" data-testid="laporan-tabel-bulan">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Bulan</TableHead>
                        <TableHead className="text-right">Masuk</TableHead>
                        <TableHead className="text-right">Keluar</TableHead>
                        <TableHead className="text-right">Selisih</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {laporan.perBulan.map((b) => (
                        <TableRow key={b.bulan}>
                          <TableCell className="font-medium">{b.bulanPanjang}</TableCell>
                          <TableCell className="text-right font-mono text-emerald-700 dark:text-emerald-300">
                            {b.pemasukan ? rupiah(b.pemasukan) : "—"}
                          </TableCell>
                          <TableCell className="text-right font-mono text-rose-600 dark:text-rose-400">
                            {b.pengeluaran ? rupiah(b.pengeluaran) : "—"}
                          </TableCell>
                          <TableCell className="text-right font-mono font-bold">
                            {b.pemasukan || b.pengeluaran ? rupiah(b.selisih) : "—"}
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow>
                        <TableCell className="font-bold">Total {tahun}</TableCell>
                        <TableCell className="text-right font-mono font-bold text-emerald-700 dark:text-emerald-300">
                          {rupiah(laporan.masuk)}
                        </TableCell>
                        <TableCell className="text-right font-mono font-bold text-rose-600 dark:text-rose-400">
                          {rupiah(laporan.keluar)}
                        </TableCell>
                        <TableCell className="text-right font-mono font-bold">
                          {rupiah(laporan.selisih)}
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                    Pemasukan per Kategori
                  </h2>
                  <div className="mt-3 space-y-2.5">
                    {laporan.perKategori.map((k) => (
                      <div key={k.kategori} className="flex items-center justify-between gap-3">
                        <KategoriBadge name={k.kategori} />
                        <span className="font-mono text-sm font-bold tracking-tight text-slate-800 dark:text-slate-200">
                          {rupiah(k.total)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                    Setoran Warga Teratas
                  </h2>
                  <div className="mt-3 space-y-2.5" data-testid="laporan-warga-teratas">
                    {laporan.perWarga.length === 0 ? (
                      <p className="text-sm text-slate-500 dark:text-slate-400">
                        Belum ada setoran yang mencantumkan nama warga.
                      </p>
                    ) : (
                      laporan.perWarga.slice(0, 8).map((w, i) => (
                        <div key={w.nama} className="flex items-center justify-between gap-3">
                          <span className="flex min-w-0 items-center gap-2">
                            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-100 text-xs font-bold text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                              {i + 1}
                            </span>
                            <span className="truncate text-sm font-medium text-slate-700 dark:text-slate-300">
                              {w.nama}
                            </span>
                          </span>
                          <span className="font-mono text-sm font-bold tracking-tight text-emerald-700 dark:text-emerald-300">
                            {rupiah(w.total)}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  <NotebookPen className="h-4 w-4" aria-hidden /> Catatan Rapat {tahun}
                </h2>
                <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                  Tulis hasil kesepakatan atau pengumuman rapat warga — ikut tersalin saat laporan
                  dibagikan ke WhatsApp.
                </p>
                <Textarea
                  data-testid="input-catatan-rapat"
                  value={catatan}
                  onChange={(e) => {
                    setCatatan(e.target.value);
                    setCatatanTersentuh(true);
                  }}
                  placeholder={"mis. Disepakati iuran naik jadi Rp 30.000/bulan mulai Januari.\nRencana perbaikan lampu jalan gang."}
                  rows={4}
                  className="mt-3"
                />
                <div className="mt-3 flex items-center justify-between gap-3">
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {note?.updated_at
                      ? `Tersimpan ${new Date(note.updated_at).toLocaleDateString("id-ID", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}`
                      : "Belum ada catatan tersimpan"}
                  </p>
                  <Button
                    data-testid="btn-simpan-catatan"
                    onClick={() =>
                      simpanNote.mutate(catatan, {
                        onSuccess: () => {
                          setCatatanTersentuh(false);
                          toast.success("Catatan rapat tersimpan.");
                        },
                        onError: () => toast.error("Gagal menyimpan catatan. Coba lagi."),
                      })
                    }
                    disabled={simpanNote.isPending || !catatanTersentuh}
                    className="h-10 font-semibold"
                  >
                    {simpanNote.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      "Simpan Catatan"
                    )}
                  </Button>
                </div>
              </div>

              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm leading-relaxed text-emerald-900 dark:border-emerald-900/50 dark:bg-emerald-950/40 dark:text-emerald-100">
                <p className="font-bold">Catatan untuk Rapat Warga</p>
                <p className="mt-1" data-testid="laporan-narasi">
                  Sepanjang {tahun} kas gang menerima <strong>{rupiah(laporan.masuk)}</strong> dan
                  membelanjakan <strong>{rupiah(laporan.keluar)}</strong> dalam {laporan.bulanAktif} bulan
                  aktif pencatatan, sehingga tahun ini{" "}
                  {laporan.selisih >= 0 ? "menyisakan" : "tercatat kekurangan"}{" "}
                  <strong>{rupiah(Math.abs(laporan.selisih))}</strong>. Saldo kas yang dipegang bendahara
                  saat ini <strong>{rupiah(laporan.saldoSemua)}</strong>.
                </p>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </AppShell>
  );
}
