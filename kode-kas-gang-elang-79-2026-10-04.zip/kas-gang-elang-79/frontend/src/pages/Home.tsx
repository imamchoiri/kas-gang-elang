import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "motion/react";
import { ArrowDownRight, ArrowUpRight, ChevronRight, Loader2, Pencil, ReceiptText, Search, Trash2, Landmark } from "lucide-react";
import { toast } from "sonner";

import AnimatedRupiah from "@/components/AnimatedRupiah";
import AppShell from "@/components/AppShell";
import KwitansiDialog from "@/components/KwitansiDialog";
import ReminderBanner from "@/components/ReminderBanner";
import RingkasanIuran from "@/components/RingkasanIuran";
import { KategoriBadge } from "@/components/kategori";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { apiDelete, apiGet } from "@/lib/api";
import { rupiah, tanggalIndo } from "@/lib/format";
import { KATEGORI_MASUK, type OkResult, type Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

const pulse = "block animate-pulse rounded-md bg-slate-200 dark:bg-slate-700";

export default function Home() {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<string>("Semua");
  const [toDelete, setToDelete] = useState<Transaction | null>(null);
  const [viewPhoto, setViewPhoto] = useState<Transaction | null>(null);
  const [kwitansiTx, setKwitansiTx] = useState<Transaction | null>(null);

  const { data: transactions, isPending, isError } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => apiGet<Transaction[]>("/transactions"),
  });

  const hapus = useMutation({
    mutationFn: (id: string) => apiDelete<OkResult>(`/transactions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      toast.success("Transaksi dihapus.");
      setToDelete(null);
    },
    onError: () => toast.error("Gagal menghapus transaksi. Coba lagi."),
  });

  const totals = useMemo(() => {
    const list = transactions ?? [];
    const masuk = list.filter((t) => t.type === "masuk").reduce((s, t) => s + t.amount, 0);
    const keluar = list.filter((t) => t.type === "keluar").reduce((s, t) => s + t.amount, 0);
    return { masuk, keluar, saldo: masuk - keluar };
  }, [transactions]);

  const filtered = useMemo(() => {
    let list = transactions ?? [];
    if (filter !== "Semua") list = list.filter((t) => t.type === "masuk" && t.category === filter);
    const needle = q.trim().toLowerCase();
    if (needle) {
      list = list.filter((t) => `${t.description} ${t.category}`.toLowerCase().includes(needle));
    }
    return list;
  }, [transactions, filter, q]);

  const searching = q.trim() !== "" || filter !== "Semua";
  const shown = searching ? filtered : (transactions ?? []).slice(0, 10);

  return (
    <AppShell>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="space-y-6"
      >
        {/* Saldo otomatis — kartu di atas */}
        <section aria-label="Ringkasan kas" className="grid gap-4">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 p-5 text-white shadow-lg shadow-emerald-950/15">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-emerald-200">
                  Sisa Saldo Kas
                </p>
                {isPending ? (
                  <span className={cn(pulse, "mt-2 h-9 w-44 bg-emerald-700/40")} />
                ) : isError ? (
                  <p className="mt-2 font-mono text-2xl font-bold text-emerald-100">—</p>
                ) : (
                  <AnimatedRupiah
                    value={totals.saldo}
                    data-testid="total-sisa-saldo-amount"
                    className="mt-1 block font-mono text-4xl font-bold tracking-tight text-white"
                  />
                )}
              </div>
              <span className="rounded-full bg-emerald-400/15 p-3">
                <Landmark className="h-6 w-6 text-emerald-300" aria-hidden />
              </span>
            </div>
            <Link
              to="/rekap"
              data-testid="btn-buka-rekap"
              className={cn(
                buttonVariants({ variant: "outline" }),
                "mt-4 border-emerald-300/40 bg-white/10 text-emerald-50 hover:bg-white/20 hover:text-white dark:border-emerald-400/30",
              )}
            >
              Lihat Rekap Bulanan
              <ChevronRight className="h-4 w-4" aria-hidden />
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/40">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-emerald-600/10 text-emerald-700 dark:bg-emerald-400/15 dark:text-emerald-300">
                <ArrowUpRight className="h-5 w-5" aria-hidden />
              </span>
              <p className="mt-2 text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700/80 dark:text-emerald-300/80">
                Total Pemasukan
              </p>
              {isPending ? (
                <span className={cn(pulse, "mt-1 h-7 w-28 bg-emerald-600/20")} />
              ) : (
                <AnimatedRupiah
                  value={totals.masuk}
                  data-testid="total-pemasukan-amount"
                  className="block font-mono text-xl font-bold tracking-tight text-emerald-800 dark:text-emerald-200"
                />
              )}
            </div>
            <div className="rounded-2xl border border-rose-100 bg-rose-50 p-4 dark:border-rose-900/50 dark:bg-rose-950/40">
              <span className="inline-flex h-9 w-9 items-center justify-center rounded-full bg-rose-600/10 text-rose-700 dark:bg-rose-400/15 dark:text-rose-300">
                <ArrowDownRight className="h-5 w-5" aria-hidden />
              </span>
              <p className="mt-2 text-xs font-semibold uppercase tracking-[0.12em] text-rose-700/80 dark:text-rose-300/80">
                Total Pengeluaran
              </p>
              {isPending ? (
                <span className={cn(pulse, "mt-1 h-7 w-28 bg-rose-600/20")} />
              ) : (
                <AnimatedRupiah
                  value={totals.keluar}
                  data-testid="total-pengeluaran-amount"
                  className="block font-mono text-xl font-bold tracking-tight text-rose-700 dark:text-rose-300"
                />
              )}
            </div>
          </div>
        </section>

        {/* Pengingat otomatis + ringkasan iuran warga */}
        <ReminderBanner />
        <RingkasanIuran transactions={transactions ?? []} />

        {/* Transaksi terbaru */}
        <section aria-label="Transaksi terbaru" className="space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Transaksi Terbaru
            </h2>
            <Badge variant="secondary">{transactions?.length ?? 0} transaksi</Badge>
          </div>

          <div className="relative">
            <Search
              className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
              aria-hidden
            />
            <Input
              data-testid="input-cari-transaksi"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Cari keterangan atau kategori..."
              aria-label="Cari transaksi"
              className="h-11 pl-9"
            />
          </div>

          <div className="flex flex-wrap gap-2" role="group" aria-label="Filter kategori pemasukan">
            {["Semua", ...KATEGORI_MASUK].map((name) => (
              <button
                key={name}
                type="button"
                data-testid="filter-kategori-transaksi"
                data-selected={filter === name || undefined}
                onClick={() => setFilter(name)}
                className={cn(
                  "h-9 rounded-full border px-3.5 text-xs font-semibold transition",
                  filter === name
                    ? "border-emerald-700 bg-emerald-700 text-white shadow-sm"
                    : "border-slate-200 bg-white text-slate-600 hover:border-emerald-300 hover:text-emerald-700 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300",
                )}
              >
                {name}
              </button>
            ))}
          </div>

          <div className="space-y-3" data-testid="daftar-transaksi-container">
            {isPending ? (
              <>
                <span className={cn(pulse, "h-20 w-full")} />
                <span className={cn(pulse, "h-20 w-full")} />
                <span className={cn(pulse, "h-20 w-full")} />
              </>
            ) : isError ? (
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
                Tidak dapat memuat data kas. Periksa koneksi lalu muat ulang halaman.
              </div>
            ) : shown.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 bg-white/50 p-8 text-center dark:border-slate-700 dark:bg-slate-900/50">
                <p className="font-semibold text-slate-700 dark:text-slate-300">
                  {searching ? "Tidak ada transaksi yang cocok" : "Belum ada transaksi"}
                </p>
                <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                  {searching
                    ? "Coba kata kunci lain atau pilih kategori Semua."
                    : "Catat pemasukan atau pengeluaran pertama lewat tombol di bawah."}
                </p>
              </div>
            ) : (
              shown.map((tx) => (
                <motion.div
                  key={tx.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  data-testid="transaksi-item"
                  className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-xs transition hover:border-slate-300 dark:border-slate-800 dark:bg-slate-900"
                >
                  {tx.photo_id ? (
                    <button
                      type="button"
                      data-testid="btn-lihat-foto"
                      aria-label="Lihat foto bukti"
                      title="Lihat foto bukti"
                      onClick={() => setViewPhoto(tx)}
                      className="shrink-0"
                    >
                      <img
                        src={`/api/photos/${tx.photo_id}`}
                        alt="Foto bukti"
                        className="h-12 w-12 rounded-lg border border-slate-200 object-cover dark:border-slate-700"
                      />
                    </button>
                  ) : null}
                  <div className="min-w-0 flex-1">
                    {tx.type === "masuk" ? (
                      <KategoriBadge name={tx.category} />
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-rose-100 px-2.5 py-0.5 text-xs font-semibold text-rose-800 dark:bg-rose-900/40 dark:text-rose-300">
                        {tx.category || "Pengeluaran"}
                      </span>
                    )}
                    <p className="mt-1 truncate text-sm font-medium text-slate-800 dark:text-slate-200">
                      {tx.description || "Tanpa keterangan"}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {tanggalIndo(tx.date)}
                      {tx.warga ? ` — ${tx.warga}` : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <span
                      className={cn(
                        "font-mono text-sm font-bold tracking-tight",
                        tx.type === "masuk"
                          ? "text-emerald-700 dark:text-emerald-300"
                          : "text-rose-600 dark:text-rose-400",
                      )}
                    >
                      {tx.type === "masuk" ? "+" : "−"}
                      {rupiah(tx.amount)}
                    </span>
                    <div className="flex items-center gap-0.5">
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        data-testid="btn-kwitansi-transaksi"
                        aria-label={`Kwitansi ${rupiah(tx.amount)}`}
                        title="Buat kwitansi digital"
                        onClick={() => setKwitansiTx(tx)}
                        className="h-9 w-9 text-slate-400 hover:text-emerald-700"
                      >
                        <ReceiptText className="h-4 w-4" aria-hidden />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        data-testid="btn-edit-transaksi"
                      aria-label={`Edit transaksi ${rupiah(tx.amount)}`}
                      title="Edit transaksi"
                      onClick={() => navigate(`/catat?id=${tx.id}&type=${tx.type}`)}
                      className="text-slate-400 hover:text-emerald-700"
                    >
                      <Pencil className="h-4 w-4" aria-hidden />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      data-testid="btn-hapus-transaksi"
                      aria-label={`Hapus transaksi ${rupiah(tx.amount)}`}
                      title="Hapus transaksi"
                      onClick={() => setToDelete(tx)}
                      className="h-9 w-9 text-slate-400 hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </section>
      </motion.div>

      {/* Konfirmasi hapus */}
      <Dialog
        open={toDelete !== null}
        onOpenChange={(o) => {
          if (!o) setToDelete(null);
        }}
      >
        <DialogContent data-testid="dialog-konfirmasi-hapus" className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">
              Hapus transaksi ini?
            </DialogTitle>
            <DialogDescription>
              {toDelete
                ? `${toDelete.type === "masuk" ? "Pemasukan" : "Pengeluaran"} ${rupiah(toDelete.amount)}${
                    toDelete.description ? ` — ${toDelete.description}` : ""
                  } akan dihapus permanen dari buku kas.`
                : ""}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setToDelete(null)}>
              Batal
            </Button>
            <Button
              variant="destructive"
              data-testid="btn-konfirmasi-hapus"
              disabled={hapus.isPending}
              onClick={() => toDelete && hapus.mutate(toDelete.id)}
            >
              {hapus.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
              ) : (
                "Ya, Hapus"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Lihat foto bukti */}
      <Dialog
        open={viewPhoto !== null}
        onOpenChange={(o) => {
          if (!o) setViewPhoto(null);
        }}
      >
        <DialogContent data-testid="dialog-foto-bukti" className="max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-base font-bold tracking-tight">Foto Bukti</DialogTitle>
            <DialogDescription>
              {viewPhoto
                ? `${viewPhoto.type === "masuk" ? "Pemasukan" : "Pengeluaran"} ${rupiah(viewPhoto.amount)}${
                    viewPhoto.description ? ` — ${viewPhoto.description}` : ""
                  }`
                : ""}
            </DialogDescription>
          </DialogHeader>
          {viewPhoto?.photo_id ? (
            <img
              src={`/api/photos/${viewPhoto.photo_id}`}
              alt="Foto bukti transaksi"
              data-testid="img-foto-bukti"
              className="max-h-[65svh] w-full rounded-xl border border-slate-200 object-contain dark:border-slate-700"
            />
          ) : null}
        </DialogContent>
      </Dialog>
      {/* Kwitansi digital */}
      <KwitansiDialog
        tx={kwitansiTx}
        saldo={totals.saldo}
        onClose={() => setKwitansiTx(null)}
      />
    </AppShell>
  );
}
