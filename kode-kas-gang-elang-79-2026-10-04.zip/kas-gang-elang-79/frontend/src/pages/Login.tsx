import { useState, type FormEvent } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useMe } from "@/hooks/useAuth";
import { ApiError, apiPost } from "@/lib/api";
import { beginSession } from "@/lib/session";
import type { OkResult } from "@/lib/types";

export default function Login() {
  const navigate = useNavigate();
  const { data: me } = useMe();
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");

  const login = useMutation<OkResult, ApiError, string>({
    mutationFn: (p: string) => apiPost<OkResult>("/auth/login", { password: p }),
    onSuccess: async () => {
      setError("");
      await beginSession();
      toast.success("Selamat datang, Bendahara!");
      navigate("/", { replace: true });
    },
    onError: (err) => {
      setError(
        err.status === 401
          ? "Sandi salah. Silakan coba lagi."
          : "Tidak dapat menghubungi server. Coba lagi.",
      );
    },
  });

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError("Masukkan sandi bendahara terlebih dahulu.");
      return;
    }
    login.mutate(password);
  };

  if (me?.authenticated) return <Navigate to="/" replace />;

  return (
    <div className="flex min-h-svh items-center justify-center bg-gradient-to-b from-emerald-50 via-background to-background p-4 dark:from-emerald-950/40 dark:via-background dark:to-background">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="w-full max-w-sm"
      >
        <Card className="rounded-2xl border-slate-200 shadow-sm dark:border-slate-800">
          <CardHeader className="items-center text-center">
            <img
              src="/elang-crest.jpg"
              alt="Lambang Gang Elang 79"
              className="mx-auto h-20 w-20 rounded-full shadow-sm ring-1 ring-emerald-600/25"
            />
            <CardTitle className="text-xl font-bold tracking-tight">Kas Gang Elang 79</CardTitle>
            <CardDescription>
              Buku kas bersama warga gang — masuk sebagai bendahara untuk mencatat.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="sandi">Sandi Bendahara</Label>
                <div className="relative">
                  <Input
                    id="sandi"
                    type={show ? "text" : "password"}
                    data-testid="bendahara-password-input"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError("");
                    }}
                    placeholder="Masukkan sandi"
                    autoComplete="current-password"
                    className="h-12 pr-12 text-base"
                  />
                  <button
                    type="button"
                    onClick={() => setShow((s) => !s)}
                    aria-label={show ? "Sembunyikan sandi" : "Tampilkan sandi"}
                    className="absolute inset-y-0 right-0 flex h-12 w-12 items-center justify-center text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                  >
                    {show ? <EyeOff className="h-5 w-5" aria-hidden /> : <Eye className="h-5 w-5" aria-hidden />}
                  </button>
                </div>
                {error ? (
                  <p data-testid="login-error-message" className="text-sm font-medium text-destructive">
                    {error}
                  </p>
                ) : null}
              </div>
              <Button
                type="submit"
                data-testid="bendahara-login-button"
                className="h-12 w-full text-base font-semibold"
                disabled={login.isPending}
              >
                {login.isPending ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> Memeriksa...
                  </>
                ) : (
                  "Masuk"
                )}
              </Button>
            </form>
            <p className="mt-5 text-center text-xs text-slate-500 dark:text-slate-400">
              Hanya bendahara yang boleh mencatat dan menghapus transaksi.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
