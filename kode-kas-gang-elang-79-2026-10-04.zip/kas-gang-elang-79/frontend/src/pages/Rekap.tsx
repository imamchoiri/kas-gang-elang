import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Copy, Download, Loader2 } from "lucide-react";
import { toast } from "sonner";

import AnimatedRupiah from "@/components/AnimatedRupiah";
import AppShell from "@/components/AppShell";
import { KategoriBadge } from "@/components/kategori";
import MonthPicker from "@/components/MonthPicker";
import { Button } from "@/components/ui/button";
import { apiDownload, apiGet } from "@/lib/api";
import { rupiah, rupiahPendek } from "@/lib/format";
import { BULAN_ID, BULAN_SINGKAT, KATEGORI_MASUK, type MetaInfo, type Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

export default function Rekap() {
  const { data: transactions, isPending, isError } = useQuery({
    queryKey: ["transactions"],
    queryFn: () => apiGet<Transaction[]>("/transactions"),
  });
  const { data: meta } = useQuery({
    queryKey: ["meta"],
    queryFn: () => apiGet<MetaInfo>("/meta"),
    staleTime: 60_000,
  });

  const [bulan, setBulan] = useState("1");
  const [tahun, setTahun] = useState(String(new Date().getFullYear()));

  // Default bulan/tahun dari server (WIB), bukan hitungan tanggal di browser.
  useEffect(() => {
    if (meta?.month) {
      const [y, m] = meta.month.split("-");
      setBulan(String(Number(m)));
      setTahun(y);
    }
  }, [meta]);

  const tahunList = useMemo(() => {
    const years = new Set<number>([new Date().getFullYear()]);
    (transactions ?? []).forEach((t) => years.add(Number(t.date.slice(0, 4))));
    return [...years].sort((a, b) => b - a);
  }, [transactions]);

  const rekap = useMemo(() => {
    const key = `${tahun}-${bulan.padStart(2, "0")}`;
    const list = (transactions ?? []).filter((t) => t.date.startsWith(key));
    const masuk = list.filter((t) => t.type === "masuk").reduce((s, t) => s + t.amount, 0);
    const keluar = list.filter((t) => t.type === "keluar").reduce((s, t) => s + t.amount, 0);
    const perKategori = KATEGORI_MASUK.map((k) => ({
      kategori: k,
      total: list
        .filter((t) => t.type === "masuk" && t.category === k)
        .reduce((s, t) => s + t.amount, 0),
    }));
    const saldoSemua = (transactions ?? []).reduce(
      (s, t) => s + (t.type === "masuk" ? t.amount : -t.amount),
      0,
    );
    return { list, masuk, keluar, perKategori, saldoBulan: masuk - keluar, saldoSemua };
  }, [transactions, bulan, tahun]);

  // Agregat 12 bulan untuk grafik tren tahunan.
  const bulanan = useMemo(
    () =>
      BULAN_SINGKAT.map((b, i) => {
        const mk = `${tahun}-${String(i + 1).padStart(2, "0")}`;
        const list = (transactions ?? []).filter((t) => t.date.startsWith(mk));
        return {
          bulan: b,
          pemasukan: list.filter((t) => t.type === "masuk").reduce((s, t) => s + t.amount, 0),
          pengeluaran: list.filter((t) => t.type === "keluar").reduce((s, t) => s + t.amount, 0),
        };
      }),
    [transactions, tahun],
  );

  // Format laporan kas siap tempel ke grup WhatsApp warga.
  const waText = useMemo(() => {
    const lines: string[] = [];
    lines.push("📋 *Laporan Kas Gang Elang 79*");
    lines.push(`${BULAN_ID[Number(bulan) - 1]} ${tahun}`);
    lines.push("");
    lines.push("*Pemasukan:*");
    let adaMasuk = false;
    rekap.perKategori.forEach((k) => {
      if (k.total > 0) {
        adaMasuk = true;
        lines.push(`• ${k.kategori}: ${rupiah(k.total)}`);
      }
    });
    if (!adaMasuk) lines.push("• Tidak ada");
    lines.push(`Total Pemasukan: *${rupiah(rekap.masuk)}*`);
    lines.push("");
    lines.push("*Pengeluaran:*");
    const keluarGroup = new Map<string, number>();
    rekap.list
      .filter((t) => t.type === "keluar")
      .forEach((t) => {
        const k = t.category || "Lain-lain";
        keluarGroup.set(k, (keluarGroup.get(k) ?? 0) + t.amount);
      });
    if (keluarGroup.size === 0) lines.push("• Tidak ada");
    keluarGroup.forEach((v, k) => lines.push(`• ${k}: ${rupiah(v)}`));
    lines.push(`Total Pengeluaran: *${rupiah(rekap.keluar)}*`);
    lines.push("");
    lines.push(`Selisih Bulan Ini: *${rupiah(rekap.saldoBulan)}*`);
    lines.push(`Saldo Kas Saat Ini: *${rupiah(rekap.saldoSemua)}*`);
    lines.push("");
    lines.push("Terima kasih atas amanah dan kepercayaan warga 🙏");
    return lines.join("\n");
  }, [rekap, bulan, tahun]);

  const salinWa = async () => {
    try {
      await navigator.clipboard.writeText(waText);
      toast.success("Laporan kas disalin — tempel ke grup WhatsApp warga!");
    } catch {
      toast.error("Gagal menyalin laporan. Coba lagi.");
    }
  };

  // Unduh rekap bulan terpilih sebagai .xlsx untuk rapat warga.
  const unduhExcel = useMutation({
    mutationFn: async () => {
      const key = `${tahun}-${bulan.padStart(2, "0")}`;
      await apiDownload(
        `/transactions/export?month=${key}`,
        `rekap-kas-gang-elang-79-${key}.xlsx`,
      );
    },
    onSuccess: () => toast.success("Rekap Excel berhasil diunduh."),
    onError: () => toast.error("Gagal mengunduh rekap. Coba lagi."),
  });

  return (
    <AppShell>
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25, ease: "easeOut" }}
        className="space-y-5"
      >
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Rekap Bulanan
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Pilih bulan untuk melihat rincian kas.
          </p>
        </div>

        <div data-testid="rekap-bulanan-container" className="space-y-4">
          <div className="flex flex-wrap items-end gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
            <MonthPicker
              bulan={bulan}
              tahun={tahun}
              tahunList={tahunList}
              onBulan={setBulan}
              onTahun={setTahun}
              bulanTestid="select-bulan-rekap"
              tahunTestid="select-tahun-rekap"
            />
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <Button
                variant="outline"
                data-testid="btn-unduh-excel"
                onClick={() => unduhExcel.mutate()}
                disabled={unduhExcel.isPending}
                className="h-11"
              >
                {unduhExcel.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <Download className="h-4 w-4" aria-hidden />
                )}
                Unduh Excel
              </Button>
              <Button variant="outline" data-testid="btn-ekspor-rekap" onClick={salinWa} className="h-11">
                <Copy className="h-4 w-4" aria-hidden /> Salin Laporan WA
              </Button>
            </div>
          </div>

          {isPending ? (
            <div className="grid gap-4 sm:grid-cols-3">
              {["a", "b", "c"].map((k) => (
                <span key={k} className="block h-24 animate-pulse rounded-2xl bg-slate-200 dark:bg-slate-700" />
              ))}
            </div>
          ) : isError ? (
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300">
              Tidak dapat memuat rekap kas. Periksa koneksi lalu muat ulang halaman.
            </div>
          ) : (
            <>
              <div className="grid gap-4 sm:grid-cols-3">
                <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4 dark:border-emerald-900/50 dark:bg-emerald-950/40">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-emerald-700/80 dark:text-emerald-300/80">
                    Pemasukan Bulan Ini
                  </p>
                  <AnimatedRupiah
                    value={rekap.masuk}
                    data-testid="rekap-pemasukan-bulan-ini"
                    className="mt-1 block font-mono text-xl font-bold tracking-tight text-emerald-800 dark:text-emerald-200"
                  />
                </div>
                <div className="rounded-2xl border border-rose-100 bg-rose-50 p-4 dark:border-rose-900/50 dark:bg-rose-950/40">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-rose-700/80 dark:text-rose-300/80">
                    Pengeluaran Bulan Ini
                  </p>
                  <AnimatedRupiah
                    value={rekap.keluar}
                    data-testid="rekap-pengeluaran-bulan-ini"
                    className="mt-1 block font-mono text-xl font-bold tracking-tight text-rose-700 dark:text-rose-300"
                  />
                </div>
                <div className="rounded-2xl bg-gradient-to-br from-emerald-800 to-emerald-950 p-4 text-white shadow-lg shadow-emerald-950/15">
                  <p className="text-xs font-semibold uppercase tracking-[0.12em] text-emerald-200">
                    Selisih Bulan Ini
                  </p>
                  <AnimatedRupiah
                    value={rekap.saldoBulan}
                    data-testid="rekap-selisih-bulan-ini"
                    className="mt-1 block font-mono text-xl font-bold tracking-tight text-white"
                  />
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  Tren Bulanan {tahun}
                </h2>
                <div data-testid="chart-tahunan" className="mt-3 h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={bulanan} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#CBD5E1" />
                      <XAxis dataKey="bulan" tickLine={false} axisLine={false} fontSize={12} />
                      <YAxis
                        tickFormatter={(v: number) => rupiahPendek(v)}
                        tickLine={false}
                        axisLine={false}
                        fontSize={12}
                        width={64}
                      />
                      <Tooltip
                        formatter={(value: number, name: string) => [rupiah(value), name]}
                        labelFormatter={(label: string) => `Bulan ${label}`}
                      />
                      <Legend />
                      <Bar dataKey="pemasukan" name="Pemasukan" fill="#047857" radius={[6, 6, 0, 0]} />
                      <Bar dataKey="pengeluaran" name="Pengeluaran" fill="#DC2626" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="text-sm font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">
                  Rincian per Kategori Pemasukan
                </h2>
                <div data-testid="rekap-kategori-pemasukan" className="mt-3 space-y-3">
                  {rekap.perKategori.map((k) => {
                    const pct = rekap.masuk > 0 ? Math.round((k.total / rekap.masuk) * 100) : 0;
                    return (
                      <div key={k.kategori}>
                        <div className="flex items-center justify-between gap-3">
                          <KategoriBadge name={k.kategori} />
                          <span className="font-mono text-sm font-bold tracking-tight text-slate-800 dark:text-slate-200">
                            {rupiah(k.total)}
                          </span>
                        </div>
                        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                          <div
                            className={cn("h-full rounded-full", k.total > 0 ? "bg-emerald-600" : "bg-transparent")}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4 flex items-center justify-between border-t border-slate-200 pt-3 dark:border-slate-800">
                  <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">
                    Saldo Kas Saat Ini
                  </span>
                  <span className="font-mono text-base font-bold text-emerald-700 dark:text-emerald-300">
                    {rupiah(rekap.saldoSemua)}
                  </span>
                </div>
              </div>
            </>
          )}
        </div>
      </motion.div>
    </AppShell>
  );
}
