# Kas Gang Elang 79 — Aplikasi Keuangan Bendahara

## Apa ini

Aplikasi web pencatat keuangan kas Gang Elang 79: pemasukan, pengeluaran, dan saldo yang terhitung otomatis. Seluruh tampilan berbahasa Indonesia, nominal dalam Rupiah, dan masuk lewat satu sandi bendahara.

## Untuk siapa

Bendahara Gang Elang 79 (dan pengurus gang) yang mengelola kas lingkungan sehari-hari — dari HP maupun komputer, dicatat per transaksi dengan keterangan bebas (mis. "Denda ronda — Pak Budi Rp 10.000").

## Fitur inti dan pengalaman

- **Halaman sandi bendahara** — satu sandi bersama sebelum masuk; setelah benar, sesi tetap terbuka di perangkat sampai keluar. Sandi awal: `elang79` (bisa diganti nanti).
- **Catat pemasukan** dengan kategori tetap: Uang Kas, Donatur, Denda Kerja Bhakti, Denda Ronda, dan Kolektif Warga (kas yang dipungut dari seluruh penduduk gang). Tiap transaksi: tanggal, kategori, jumlah, keterangan bebas.
- **Catat pengeluaran** — tanggal, jumlah, keterangan bebas (kategori pengeluaran tidak dibatasi).
- **Saldo otomatis** — kartu di atas: Total Pemasukan, Total Pengeluaran, Sisa Saldo, selalu ter-update.
- **Rekap per bulan + per kategori** — pilih bulan, lihat total masuk/keluar/saldo bulan itu dan rincian total per kategori pemasukan.
- **Koreksi** — transaksi salah tinggal dihapus, dengan konfirmasi.
- **Pengalaman**: daftar transaksi terbaru di beranda, tombol catat selalu terlihat, notifikasi kecil saat berhasil menyimpan, tampilan nyaman di layar HP.

## Fase 1: yang dibangun sekarang

1. Halaman sandi bendahara + proteksi seluruh halaman aplikasi.
2. Beranda: kartu saldo otomatis, daftar transaksi terbaru, tombol catat pemasukan/pengeluaran.
3. Form catat transaksi (masuk dengan 5 kategori tetap, keluar bebas).
4. Rekap bulanan: filter bulan, total per kategori.
5. Hapus transaksi dengan konfirmasi.
