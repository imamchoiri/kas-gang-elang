# Kas Gang Elang 79 — Buku Kas Bendahara

Aplikasi pencatat keuangan kas lingkungan Gang Elang 79. Seluruh UI berbahasa
Indonesia, nominal Rupiah, mobile-first.

## Cara kerja singkat

- **Auth**: satu sandi bendahara bersama (`elang79`). `POST /api/auth/login`
  memverifikasi sandi (hash pbkdf2 di koleksi `settings`, dibuat lazily saat
  request pertama) lalu menyetel cookie httpOnly `kas_session` (JWT HS256,
  usia 30 hari). `GET /api/auth/me` → 200 `{authenticated: bool}` (tanpa 401
  agar console browser bersih). `POST /api/auth/logout` menghapus cookie.
  Keluar di frontend lewat `endSession()` (lib/session.ts) yang selalu
  `queryClient.clear()`.
- **Ganti sandi**: `PUT /api/auth/password` `{password_lama, password_baru}`
  (min 5 karakter, butuh sesi aktif) — verifikasi sandi lama lalu simpan hash
  baru. Sesi aktif tetap berlaku. Halaman `/pengaturan`.
- **Proteksi halaman**: semua route kecuali `/masuk` dibungkus `Protected`
  di `App.tsx` — cek `useMe()`, pending = splash, belum masuk = redirect ke
  `/masuk`.
- **Transaksi**: koleksi Mongo `transactions`, id string uuid4. Field:
  `type` ("masuk"|"keluar"), `category` (masuk: wajib salah satu dari
  KATEGORI_MASUK = Uang Kas, Donatur, Denda Kerja Bhakti, Denda Ronda,
  Kolektif Warga; keluar: teks bebas), `amount` (int > 0), `description`
  (bebas), `date` (YYYY-MM-DD), `photo_id` (id foto bukti, "" = tanpa foto),
  `warga` (nama warga opsional, untuk rekap iuran), `created_at` (UTC aware).
- **Edit transaksi**: `PUT /api/transactions/{id}` — body sama dengan create;
  mempertahankan `created_at` asli; jika `photo_id` berubah, foto lama
  dihapus otomatis. Frontend memakai ulang form /catat dengan `?id=<tx>`
  (prefill dari cache query `["transactions"]`), tombol pensil di tiap baris.
- **Foto bukti**: `POST /api/photos` (multipart `file`, maks 12 MB,
  JPG/PNG/WebP/HEIC) → `{id}`; `GET /api/photos/{id}` melayani bytes (butuh
  sesi, cache 1 hari); `DELETE /api/photos/{id}`. Koleksi `photos` menyimpan
  bytes + content_type. Klien mengompres via canvas (maks 1600px JPEG 0.82,
  lib/photo.ts). Thumbnail di baris transaksi → klik membuka dialog foto
  besar. Menghapus transaksi menghapus fotonya.
- **Ekspor rekap**: `GET /api/transactions/export?month=YYYY-MM` → .xlsx dua
  sheet ("Rekap" ringkasan + rincian kategori, "Transaksi" tabel urut
  kronologis) via openpyxl + StreamingResponse. Tombol "Unduh Excel" di Rekap
  memakai `apiDownload` (blob + object URL).
- **Endpoint**: `GET/POST /api/transactions`,
  `PUT/DELETE /api/transactions/{id}`,
  `GET /api/transactions/export?month=`, `POST/GET/DELETE /api/photos/*`
  (semua di belakang dependency `require_auth`), `GET /api/meta`
  (`today`/`month` ter-anchor server, tz Asia/Jakarta).
- **Perhitungan**: total pemasukan/pengeluaran/saldo, rekap per bulan + per
  kategori, agregat 12 bulan (grafik tren tahunan, recharts), dan status iuran
  per warga dihitung di frontend dari daftar transaksi (satu query react-query
  `["transactions"]`); "hari ini" untuk form & default rekap dari
  `/api/meta`.
- **Iuran Warga** (`/warga`): daftar **warga tetap** (koleksi `residents`:
  `id`, `nama` unik tanpa peduli huruf besar/kecil, `iuran_bulanan`,
  `created_at`) + nama yang baru muncul di transaksi. Endpoint
  `GET/POST /api/residents`, `PUT/DELETE /api/residents/{id}`,
  `POST /api/residents/import` (daftarkan semua nama warga dari transaksi
  pemasukan, pakai `iuran_default`). Warga baru langsung tampil "Belum Bayar"
  walau belum pernah setor.
- **Target iuran**: `iuran_bulanan` per warga menghasilkan status Lunas /
  "Kurang Rp X" / "Belum Bayar" untuk bulan terpilih, plus ringkasan
  Lunas X/Y, Terkumpul, dan Belum Masuk. Default global `iuran_default`
  disimpan di dokumen `settings` dan diatur lewat `/pengaturan`
  (`GET/PUT /api/auth/settings`), dipakai sebagai nilai awal saat menambah
  warga.
- **Pengingat WhatsApp**: tombol "Pengingat WA" di `/warga` menyusun pesan
  sopan berbahasa Indonesia berisi daftar warga yang belum lunas beserta
  kekurangannya, total belum masuk, dan ringkasan lunas — disalin ke clipboard.
- **Laporan Tahunan** (`/laporan`): pilih tahun → total masuk/keluar/saldo,
  grafik 12 bulan, tabel rekap per bulan (+baris total), pemasukan per
  kategori, setoran warga teratas, dan paragraf narasi siap dibacakan di
  rapat. Tombol "Salin ke WA" dan "Unduh Excel"
  (`GET /api/transactions/export?year=YYYY` → sheet "Laporan <tahun>":
  ringkasan, 12 bulan, kategori, setoran per warga). Endpoint export menerima
  **salah satu** `month=YYYY-MM` atau `year=YYYY` (mengirim keduanya/tidak
  sama sekali → 422).
- **Kwitansi digital**: dirender klien di canvas 1080x1350
  (`lib/kwitansi.ts` — header zamrud + lambang, rincian transaksi, foto
  bukti, panel jumlah, saldo saat ini); tombol struk di tiap baris membuka
  pratinjau (KwitansiDialog) dengan Bagikan (Web Share API dengan file;
  fallback unduh + toast) dan Unduh.
- **Mode gelap**: ThemeProvider next-themes (`attribute="class"`,
  defaultTheme="light") di main.tsx; saklar di `/pengaturan`
  (components/ThemeSwitch.tsx, testid btn-mode-gelap); token `.dark` sudah
  lengkap di index.css.
- **Riwayat & tunggakan per warga**: klik baris warga → `WargaDetailDialog`
  (total setoran sepanjang masa, tunggakan berjalan, ceklis 12 bulan, daftar
  seluruh setoran terbaru-dulu, dan tombol kartu iuran). Perhitungan ada di
  `lib/iuran.ts` (`hitungWarga`, `rentangBulan`) — satu sumber kebenaran untuk
  halaman Warga, dialog detail, dan kartu.
- **Tunggakan berjalan**: akumulasi `max(0, target - dibayar)` tiap bulan dari
  bulan paling awal antara pendaftaran warga dan setoran pertamanya sampai
  bulan terpilih. Tampil sebagai badge merah di baris warga, kartu ringkasan
  "Tunggakan berjalan", dan ikut disebut di pesan Pengingat WA.
- **Kartu Iuran**: `lib/kartu.ts` merender PNG 1080x1350 berisi identitas
  warga, target, ceklis 12 bulan (✓ lunas / – sebagian / ○ belum), total
  setoran tahun itu, dan tunggakan; bisa Unduh atau Bagikan (Web Share API,
  fallback unduh). Tombol **"Kartu Semua"** di `/warga`
  (`components/KartuSemuaDialog.tsx`) membuat kartu untuk seluruh warga
  terdaftar sekaligus — daftar pratinjau + "Unduh Semua" + tombol Kirim per
  warga.
- **Tandai Lunas Cepat**: tombol "Lunas" di baris warga (muncul hanya bila
  warga terdaftar, punya target, dan belum lunas) langsung mencatat transaksi
  pemasukan sebesar kekurangannya (kategori Uang Kas, `warga` terisi,
  keterangan "Iuran <Bulan> <Tahun> — <Nama>"). Tanggal = `meta.today` bila
  bulan terpilih = bulan berjalan, selain itu tanggal 1 bulan tersebut. Toast
  menyediakan aksi **Batalkan** yang menghapus transaksi itu kembali.
- **Catatan Rapat**: koleksi `notes` (unik per `year`),
  `GET/PUT /api/notes/{year}` (tahun harus 4 digit, selain itu 422). Kartu
  catatan di `/laporan`; isinya ikut tersalin di akhir "Salin ke WA".
- **Backup Data**: `GET /api/backup/excel` (satu .xlsx: sheet Ringkasan,
  Semua Transaksi, Daftar Warga) dan `GET /api/backup/json` (data mentah
  lengkap, versi_backup 1). Keduanya butuh sesi dan **tidak pernah**
  menyertakan `password_hash`/`session_secret`. Tombol di `/pengaturan`.
- **Pulihkan Backup**: `POST /api/backup/restore` (multipart `file`, JSON
  hasil Backup JSON). Divalidasi lewat Pydantic lebih dulu — kalau strukturnya
  tidak dikenali → 422 dan data lama tidak disentuh. Bila sah: seluruh
  `transactions` + `residents` diganti, `iuran_default` disetel, `photo_id`
  yang fotonya sudah tidak ada dikosongkan (agar tidak ada gambar rusak).
  Mengembalikan jumlah `transaksi`, `warga`, `dilewati`, `foto_hilang`.
  UI di `/pengaturan` memakai dialog konfirmasi karena menimpa semua data.
- **Unduh Kode Aplikasi (ZIP)**: `GET /api/kode-sumber/zip` (butuh sesi,
  `backend/routers/source.py`) — zip seluruh isi `/app` dengan prefix
  `kas-gang-elang-79/`, melewati `node_modules`, `.git`, `dist`, cache,
  `__pycache__`, `test_reports`, semua file `.env*`, dan file > 5 MB; menambah
  `CATATAN-UNDUHAN.txt`. Tombol "Unduh Kode (.zip)" di `/pengaturan`.
- **Pengingat otomatis (cron)**: `.emergent/crons.yml` menjadwalkan
  `POST /api/cron/pengingat-iuran` setiap tanggal 10 pukul 00:00 UTC
  (= 07:00 WIB). Endpoint memverifikasi `Authorization: Bearer
  $WEBHOOK_CRON_SECRET` (constant-time), menolak 401 bila salah, idempoten
  lewat `X-Webhook-Id` di koleksi `cron_runs`, lalu **ack 202 langsung** dan
  mengerjakan penyusunan pesan di BackgroundTasks. Hasilnya disimpan di
  koleksi `reminders` (unik per `month`). Pengingat **tidak** terkirim sendiri
  ke WhatsApp (butuh layanan pihak ketiga) — banner beranda
  (`components/ReminderBanner.tsx`) menampilkannya dengan tombol "Kirim ke
  WhatsApp" (membuka `wa.me/?text=` + menyalin teks), "Lihat Pesan", dan
  "Sudah dikirim". Endpoint baca: `GET /api/reminders/current`,
  `GET /api/reminders`, `POST /api/reminders/{month}/sent`,
  `POST /api/reminders/siapkan` (susun ulang manual).
- **Lunas massal**: mode "Lunas Massal" di `/warga` menampilkan checkbox pada
  warga terdaftar yang bertarget dan belum lunas (tombol lunas cepat
  disembunyikan saat mode ini aktif), "Pilih Semua", lalu dialog konfirmasi →
  `POST /api/transactions/bulk` (list TransactionCreate, maks 200) yang
  mencatat semuanya sekaligus dan menulis satu baris riwayat.
- **Riwayat perubahan (audit)**: `lib/audit.py#catat_audit` (best-effort,
  tidak pernah menggagalkan aksi) menulis ke koleksi `audit` pada setiap
  tambah/ubah/hapus transaksi & warga, impor warga, lunas massal, pulihkan
  backup, dan pengingat. Dibaca lewat `GET /api/audit?limit=` (1-500) dan
  ditampilkan di `/riwayat`.
- **Ringkasan beranda**: `components/RingkasanIuran.tsx` menghitung jumlah
  warga belum lunas bulan ini (dari `/api/residents` + transaksi + `meta.month`)
  dan menautkannya ke `/warga`.
- **Fitur lain**: pencarian + filter kategori di beranda, dialog konfirmasi
  hapus, toast sonner, "Salin Laporan WA" di Rekap (format laporan WhatsApp
  ke clipboard), tombol catat mengambang selalu terlihat.

## Variabel lingkungan tambahan

- `WEBHOOK_CRON_SECRET` di `backend/.env` — dipakai endpoint cron untuk
  memverifikasi pemanggil. Jangan pernah ditaruh di `crons.yml`, kode, atau
  frontend.

## Rute frontend

- `/masuk` — halaman sandi bendahara (publik)
- `/` — beranda: 3 kartu saldo, banner pengingat iuran otomatis, ringkasan
  warga belum lunas, transaksi terbaru (10 terakhir) dengan foto bukti +
  tombol kwitansi/edit/hapus, cari/filter, konfirmasi hapus
- `/catat` — catat transaksi (toggle pemasukan/pengeluaran, nama warga
  opsional dengan datalist saran, foto bukti opsional) atau edit via `?id=`
- `/rekap` — rekap bulanan: pilih bulan/tahun, total masuk/keluar/selisih,
  grafik tren bulanan setahun (recharts), rincian per kategori pemasukan,
  salin laporan WA, unduh Excel
- `/warga` — iuran per warga: daftar warga tetap + target iuran, status
  Lunas/Kurang/Belum Bayar per bulan, tunggakan berjalan, tombol Lunas cepat,
  mode Lunas Massal, Pengingat WA, Kartu Semua, klik baris → riwayat setoran
  + kartu iuran
- `/riwayat` — riwayat perubahan data kas (audit log)
- `/laporan` — laporan tahunan (grafik, tabel 12 bulan, kategori, warga
  teratas, catatan rapat)
- `/pengaturan` — ganti sandi, target iuran default, backup & pulihkan data,
  mode gelap

## Konvensi teknis

- Backend: FastAPI + motor (Mongo lokal), semua route di `api_router`
  (`/api`), model di `backend/models/kas.py`, router di
  `backend/routers/{auth,transactions,photos}.py`, index di
  `backend/lib/db.py`.
- Frontend: React 19 + TS strict + TanStack Query + shadcn/ui (base-nova),
  fetch relatif via `lib/api.ts` (termasuk `apiPostForm` multipart dan
  `apiDownload` blob). Mirror TS dari model Pydantic ada di `lib/types.ts`
  (jaga sinkron).
- Tema: Plus Jakarta Sans Variable + IBM Plex Mono (angka), palet zamrud
  (emerald) sesuai `design_guidelines.json`, light default.

## Data seed

Tidak ada data awal — buku kas mulai kosong. Koleksi `settings` dibuat otomatis
saat login pertama.

## Kredensial

Lihat `memory/test_credentials.md` — sandi bendahara: `elang79`.
