# Test credentials — Kas Gang Elang 79

- Halaman masuk: `/masuk`
- Sandi bendahara awal: `elang79` — **CATATAN: sandi ini sudah DIGANTI oleh
  pengguna lewat halaman `/pengaturan` (per 1 Okt 2026), jadi `elang79` tidak
  lagi berlaku.** Sandi aktif hanya diketahui pengguna.
- Tidak ada akun/username — cukup sandi. Sesi berupa cookie httpOnly
  `kas_session` (JWT HS256, 30 hari).
- Untuk pengujian tanpa mengubah sandi pengguna: mint token sesi dari
  `session_secret` di koleksi `settings`, lalu pasang sebagai cookie
  `kas_session`:

  ```bash
  cd /app/backend && python -c "
  import asyncio, jwt
  from datetime import datetime, timedelta, timezone
  from lib.db import db
  async def main():
      doc = await db.settings.find_one({'_id': 'app'})
      print(jwt.encode({'sub':'bendahara','exp': datetime.now(timezone.utc)+timedelta(minutes=30)}, doc['session_secret'], algorithm='HS256'))
  asyncio.run(main())"
  ```

- Jangan mereset sandi pengguna untuk keperluan tes — pakai cara di atas.
