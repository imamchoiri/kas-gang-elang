import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4ODg2NjB9.02pI1ULSmHAvq7MXztaw77WklN3_yRxzrDH7XQvqG18',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 30000 });

// 1. IURAN WARGA (route yang tadi gagal)
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 20000 });
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
const sudahBayar = await page.textContent('[data-testid="warga-sudah-bayar"]');
const terkumpul = await page.textContent('[data-testid="warga-terkumpul"]');
const wargaRows = await page.locator('[data-testid="warga-item"]').count();
await page.screenshot({ path: 'warga-lunas.jpeg', quality: 20, type: 'jpeg' });
await page.getByTestId('filter-status-warga').nth(2).click();
await page.waitForTimeout(700);
const belumRows = await page.locator('[data-testid="warga-item"]').count();
await page.screenshot({ path: 'warga-belum.jpeg', quality: 20, type: 'jpeg' });

// 2. GRAFIK TAHUNAN
await page.click('[data-testid="nav-rekap"]');
await page.waitForSelector('[data-testid="chart-tahunan"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const bars = await page.locator('[data-testid="chart-tahunan"] .recharts-bar-rectangle').count();
await page.screenshot({ path: 'rekap-grafik.jpeg', quality: 20, type: 'jpeg' });

// 3. MODE GELAP
await page.click('[data-testid="nav-pengaturan"]');
await page.waitForSelector('[data-testid="btn-mode-gelap"]', { timeout: 15000 });
await page.click('[data-testid="btn-mode-gelap"]');
await page.waitForTimeout(900);
const isDark = await page.evaluate(() => document.documentElement.classList.contains('dark'));
await page.screenshot({ path: 'gelap-pengaturan.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="nav-beranda"]');
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(900);
await page.screenshot({ path: 'gelap-beranda.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 20000 });
await page.waitForTimeout(800);
await page.screenshot({ path: 'gelap-warga.jpeg', quality: 20, type: 'jpeg' });
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForTimeout(1800);
const darkAfterReload = await page.evaluate(() => document.documentElement.classList.contains('dark'));

// 4. Bersihkan transaksi uji "Bu Sari" + balik ke mode terang
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-cari-transaksi"]', { timeout: 20000 });
await page.fill('[data-testid="input-cari-transaksi"]', 'Iuran bulanan');
await page.waitForTimeout(900);
const found = await page.locator('[data-testid="transaksi-item"]').count();
await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
await page.click('[data-testid="btn-konfirmasi-hapus"]');
await page.waitForTimeout(2500);
await page.click('[data-testid="nav-pengaturan"]');
await page.waitForSelector('[data-testid="btn-mode-gelap"]', { timeout: 15000 });
await page.click('[data-testid="btn-mode-gelap"]');
await page.waitForTimeout(800);
const backToLight = await page.evaluate(() => !document.documentElement.classList.contains('dark'));
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const saldoEnd = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.screenshot({ path: 'akhir-terang.jpeg', quality: 20, type: 'jpeg' });

console.log('WARGA sudah bayar:', sudahBayar?.replace(/\s+/g, ' ').trim(), '| terkumpul:', terkumpul, '| rows semua:', wargaRows, '| rows belum-bayar:', belumRows);
console.log('CHART bars:', bars);
console.log('DARK toggle:', isDark, '| persists reload:', darkAfterReload, '| back to light:', backToLight);
console.log('cleanup: matched test rows =', found, '| SALDO akhir:', saldoEnd);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
