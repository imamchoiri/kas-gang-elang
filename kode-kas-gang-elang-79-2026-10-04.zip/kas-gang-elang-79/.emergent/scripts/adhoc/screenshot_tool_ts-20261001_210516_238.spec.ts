import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTEzNzJ9.jjRBseQ71WAKuVVyBKvqMIqGk5tc-rjXO8ReUxrZCi4',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });

// ============ 1. TANDAI LUNAS CEPAT (lalu dibatalkan agar data pengguna utuh) ============
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 30000 });
await page.waitForTimeout(1500);
const saldoAwal = await page.evaluate(async () => {
  const r = await fetch('/api/transactions');
  const l = await r.json();
  return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
});
const lunasAwal = await page.textContent('[data-testid="warga-sudah-bayar"]');
await page.screenshot({ path: 'warga-sebelum-lunas.jpeg', quality: 20, type: 'jpeg' });

const tombolLunas = page.locator('[data-testid="btn-tandai-lunas"]').first();
const adaTombolLunas = await tombolLunas.count();
let lunasSesudah = '(tidak diuji)';
let saldoSesudah = saldoAwal;
let undoOk = false;
if (adaTombolLunas > 0) {
  await tombolLunas.click();
  await page.waitForTimeout(2500);
  lunasSesudah = (await page.textContent('[data-testid="warga-sudah-bayar"]')) || '';
  saldoSesudah = await page.evaluate(async () => {
    const r = await fetch('/api/transactions');
    const l = await r.json();
    return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
  });
  await page.screenshot({ path: 'warga-sesudah-lunas.jpeg', quality: 20, type: 'jpeg' });
  // Batalkan via aksi di toast
  const batal = page.getByRole('button', { name: 'Batalkan' });
  if (await batal.count() > 0) {
    await batal.first().click();
    await page.waitForTimeout(2500);
    undoOk = true;
  }
}
const saldoSetelahUndo = await page.evaluate(async () => {
  const r = await fetch('/api/transactions');
  const l = await r.json();
  return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
});

// ============ 2. KARTU SEMUA WARGA ============
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="btn-kartu-semua"]', { timeout: 25000 });
await page.waitForTimeout(1200);
await page.click('[data-testid="btn-kartu-semua"]');
await page.waitForSelector('[data-testid="dialog-kartu-semua"]', { timeout: 15000 });
await page.click('[data-testid="btn-buat-semua-kartu"]');
await page.waitForSelector('[data-testid="kartu-semua-item"]', { timeout: 40000 });
await page.waitForTimeout(1500);
const jumlahKartu = await page.locator('[data-testid="kartu-semua-item"]').count();
await page.screenshot({ path: 'kartu-semua.jpeg', quality: 20, type: 'jpeg' });
const dl = page.waitForEvent('download', { timeout: 20000 }).catch(() => null);
await page.click('[data-testid="btn-unduh-semua-kartu"]');
const file1 = await dl;
await page.waitForTimeout(1500);
await page.keyboard.press('Escape');
await page.waitForTimeout(700);

// ============ 3. CATATAN RAPAT ============
await page.goto('https://language-learner-78.preview.emergentagent.com/laporan', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-catatan-rapat"]', { timeout: 25000 });
await page.waitForTimeout(1200);
const catatanAwal = await page.inputValue('[data-testid="input-catatan-rapat"]');
await page.fill('[data-testid="input-catatan-rapat"]', 'Uji coba catatan rapat warga.');
await page.click('[data-testid="btn-simpan-catatan"]');
await page.waitForTimeout(2000);
await page.screenshot({ path: 'catatan-rapat.jpeg', quality: 20, type: 'jpeg' });
// bertahan setelah reload?
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-catatan-rapat"]', { timeout: 25000 });
await page.waitForTimeout(1800);
const catatanSetelahReload = await page.inputValue('[data-testid="input-catatan-rapat"]');

// ============ 4. PULIHKAN BACKUP (file backup pengguna sendiri) ============
await page.goto('https://language-learner-78.preview.emergentagent.com/pengaturan', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="btn-pilih-restore"]', { timeout: 25000 });
await page.setInputFiles('[data-testid="input-file-restore"]', '/tmp/safe.json');
await page.waitForSelector('[data-testid="dialog-konfirmasi-restore"]', { timeout: 15000 });
await page.screenshot({ path: 'restore-konfirmasi.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-konfirmasi-restore"]');
await page.waitForTimeout(3000);
await page.screenshot({ path: 'restore-hasil.jpeg', quality: 20, type: 'jpeg' });
const saldoAkhir = await page.evaluate(async () => {
  const r = await fetch('/api/transactions');
  const l = await r.json();
  return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
});
const wargaAkhir = await page.evaluate(async () => {
  const r = await fetch('/api/residents');
  return (await r.json()).map((x: { nama: string }) => x.nama);
});

console.log('TANDAI LUNAS — tombol ada:', adaTombolLunas, '| lunas awal:', lunasAwal?.replace(/\s+/g,' ').trim(), '→ sesudah:', String(lunasSesudah).replace(/\s+/g,' ').trim());
console.log('SALDO awal:', saldoAwal, '→ setelah tandai lunas:', saldoSesudah, '→ setelah Batalkan:', saldoSetelahUndo, '| undo diklik:', undoOk);
console.log('KARTU SEMUA — jumlah kartu:', jumlahKartu, '| unduh pertama:', file1 ? file1.suggestedFilename() : '(no event)');
console.log('CATATAN — awal:', JSON.stringify(catatanAwal), '| setelah reload:', JSON.stringify(catatanSetelahReload));
console.log('RESTORE — saldo akhir:', saldoAkhir, '| warga:', JSON.stringify(wargaAkhir));
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
