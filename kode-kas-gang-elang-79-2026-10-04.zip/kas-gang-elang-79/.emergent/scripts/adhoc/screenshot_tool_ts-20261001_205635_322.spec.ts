import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

const ctx = page.context();
await ctx.addCookies([{
  name: 'kas_session',
  value: (await (async () => 'TOKEN_PLACEHOLDER')()),
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });

// 1. Tambah warga uji dengan target 20.000
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 30000 });
await page.click('[data-testid="btn-tambah-warga"]');
await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
await page.fill('[data-testid="input-nama-warga"]', 'Zz Tes Riwayat');
await page.fill('[data-testid="input-iuran-warga"]', '20000');
await page.click('[data-testid="btn-simpan-warga"]');
await page.waitForTimeout(1800);

// 2. Dua setoran di bulan berbeda (Agustus & Oktober) → riwayat lintas bulan + tunggakan
for (const [tanggal, jumlah, ket] of [
  ['2026-08-10', '20000', 'Tes setoran Agustus'],
  ['2026-10-02', '12000', 'Tes setoran Oktober sebagian'],
] as const) {
  await page.click('[data-testid="btn-tambah-pemasukan"]');
  await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
  await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
  await page.fill('[data-testid="input-transaksi-tanggal"]', tanggal);
  await page.click('[data-testid="input-transaksi-kategori"]');
  await page.getByRole('option', { name: 'Uang Kas' }).click({ force: true });
  await page.fill('[data-testid="input-transaksi-jumlah"]', jumlah);
  await page.fill('[data-testid="input-transaksi-keterangan"]', ket);
  await page.fill('[data-testid="input-transaksi-warga"]', 'Zz Tes Riwayat');
  await page.click('[data-testid="btn-simpan-transaksi"]');
  await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
  await page.waitForTimeout(1200);
}

// 3. TUNGGAKAN BERJALAN di baris warga
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 25000 });
await page.waitForTimeout(1500);
const totalTunggakan = await page.textContent('[data-testid="warga-total-tunggakan"]').catch(() => null);
const rowTes = page.locator('[data-testid="warga-item"]').filter({ hasText: 'Zz Tes Riwayat' });
const badgeKurang = await rowTes.locator('[data-testid="badge-kurang-bayar"]').textContent();
const badgeTunggakan = await rowTes.locator('[data-testid="badge-tunggakan"]').textContent();
await page.screenshot({ path: 'tunggakan-baris.jpeg', quality: 20, type: 'jpeg' });

// 4. RIWAYAT PER WARGA — buka detail
await rowTes.locator('[data-testid="btn-detail-warga"]').click();
await page.waitForSelector('[data-testid="dialog-detail-warga"]', { timeout: 15000 });
await page.waitForTimeout(800);
const totalSetor = await page.textContent('[data-testid="detail-total-setor"]');
const detailTunggakan = await page.textContent('[data-testid="detail-tunggakan"]');
const jumlahSetoran = await page.locator('[data-testid="detail-setoran-item"]').count();
const ceklis = await page.evaluate(() => {
  const cells = [...document.querySelectorAll('[data-testid="detail-ceklis-bulan"] > div')];
  return cells.map((c) => (c.textContent || '').replace(/\s+/g, ' ').trim()).filter((t) => !t.includes('—'));
});
await page.screenshot({ path: 'detail-riwayat.jpeg', quality: 20, type: 'jpeg' });

// 5. KARTU IURAN
await page.click('[data-testid="btn-buat-kartu"]');
await page.waitForSelector('[data-testid="img-kartu-iuran"]', { timeout: 25000 });
await page.waitForTimeout(1200);
const kartuDim = await page.evaluate(() => {
  const img = document.querySelector('[data-testid="img-kartu-iuran"]') as HTMLImageElement | null;
  return img ? `${img.naturalWidth}x${img.naturalHeight}` : 'none';
});
await page.evaluate(() => {
  document.querySelector('[data-testid="img-kartu-iuran"]')?.scrollIntoView({ block: 'center' });
});
await page.waitForTimeout(600);
await page.screenshot({ path: 'kartu-iuran.jpeg', quality: 20, type: 'jpeg' });
const dlKartu = page.waitForEvent('download', { timeout: 15000 }).catch(() => null);
await page.click('[data-testid="btn-unduh-kartu"]');
const kartuFile = await dlKartu;
await page.keyboard.press('Escape');
await page.waitForTimeout(600);

// 6. BACKUP DATA
await page.goto('https://language-learner-78.preview.emergentagent.com/pengaturan', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="btn-backup-excel"]', { timeout: 20000 });
const dlX = page.waitForEvent('download', { timeout: 25000 }).catch(() => null);
await page.click('[data-testid="btn-backup-excel"]');
const fileX = await dlX;
await page.waitForTimeout(1500);
const dlJ = page.waitForEvent('download', { timeout: 25000 }).catch(() => null);
await page.click('[data-testid="btn-backup-json"]');
const fileJ = await dlJ;
await page.waitForTimeout(1200);
await page.screenshot({ path: 'pengaturan-backup.jpeg', quality: 20, type: 'jpeg' });

console.log('BARIS tunggakan — kurang:', badgeKurang, '| tunggakan:', badgeTunggakan, '| ringkasan:', totalTunggakan?.replace(/\s+/g,' ').trim());
console.log('DETAIL total setor:', totalSetor, '| tunggakan:', detailTunggakan, '| jumlah setoran:', jumlahSetoran);
console.log('CEKLIS bulan terisi:', JSON.stringify(ceklis));
console.log('KARTU dimensi:', kartuDim, '| unduh:', kartuFile ? kartuFile.suggestedFilename() : '(no event)');
console.log('BACKUP excel:', fileX ? fileX.suggestedFilename() : '(no event)', '| json:', fileJ ? fileJ.suggestedFilename() : '(no event)');
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
