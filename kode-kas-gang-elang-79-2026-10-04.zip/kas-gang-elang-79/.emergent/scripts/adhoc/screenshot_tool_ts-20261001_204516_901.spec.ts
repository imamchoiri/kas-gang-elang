import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

const ctx = page.context();
await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://language-learner-78.preview.emergentagent.com' });
await ctx.addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTAxNjF9.4pa-d3Cm9ihXW8YjeVA3emyvC-HLwhti2_yMtZY_IaE',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });

// 1. PENGATURAN: simpan target iuran default
await page.goto('https://language-learner-78.preview.emergentagent.com/pengaturan', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-iuran-default"]', { timeout: 30000 });
await page.fill('[data-testid="input-iuran-default"]', '25000');
await page.click('[data-testid="btn-simpan-iuran-default"]');
await page.waitForTimeout(1800);
await page.screenshot({ path: 'pengaturan-iuran.jpeg', quality: 20, type: 'jpeg' });

// 2. DAFTAR WARGA TETAP: tambah warga yang belum pernah setor
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 20000 });
await page.click('[data-testid="btn-tambah-warga"]');
await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
const iuranPrefill = await page.inputValue('[data-testid="input-iuran-warga"]');
await page.fill('[data-testid="input-nama-warga"]', 'Pak Darto');
await page.click('[data-testid="btn-simpan-warga"]');
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
await page.waitForTimeout(1200);
// warga kedua dengan target lebih besar, lalu cek "Kurang"
await page.click('[data-testid="btn-tambah-warga"]');
await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
await page.fill('[data-testid="input-nama-warga"]', 'Bu Rina');
await page.fill('[data-testid="input-iuran-warga"]', '50000');
await page.click('[data-testid="btn-simpan-warga"]');
await page.waitForTimeout(1800);
// nama ganda -> error 409 ditangani di form
await page.click('[data-testid="btn-tambah-warga"]');
await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
await page.fill('[data-testid="input-nama-warga"]', 'Pak Darto');
await page.click('[data-testid="btn-simpan-warga"]');
await page.waitForSelector('[data-testid="form-warga-error"]', { timeout: 15000 });
const dupError = await page.textContent('[data-testid="form-warga-error"]');
await page.keyboard.press('Escape');
await page.waitForTimeout(700);
const kurangBadges = await page.locator('[data-testid="badge-kurang-bayar"]').allTextContents();
const belumMasuk = await page.textContent('[data-testid="warga-total-kurang"]');
const sudahBayar = await page.textContent('[data-testid="warga-sudah-bayar"]');
await page.screenshot({ path: 'warga-target.jpeg', quality: 20, type: 'jpeg' });

// 3. TARGET IURAN: catat setoran sebagian untuk Bu Rina -> "Kurang Rp 20.000"
await page.click('[data-testid="btn-tambah-pemasukan"]');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
await page.click('[data-testid="input-transaksi-kategori"]');
await page.getByRole('option', { name: 'Uang Kas' }).click({ force: true });
await page.fill('[data-testid="input-transaksi-jumlah"]', '30000');
await page.fill('[data-testid="input-transaksi-keterangan"]', 'Iuran sebagian');
await page.fill('[data-testid="input-transaksi-warga"]', 'Bu Rina');
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
await page.waitForTimeout(1500);
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const badgesAfter = await page.locator('[data-testid="badge-kurang-bayar"]').allTextContents();
const belumMasukAfter = await page.textContent('[data-testid="warga-total-kurang"]');
await page.screenshot({ path: 'warga-kurang.jpeg', quality: 20, type: 'jpeg' });

// 4. PENGINGAT WHATSAPP
await page.click('[data-testid="btn-pengingat-wa"]');
await page.waitForTimeout(1500);
const reminder = await page.evaluate(() => navigator.clipboard.readText());
await page.screenshot({ path: 'warga-pengingat.jpeg', quality: 20, type: 'jpeg' });

// 5. LAPORAN TAHUNAN (lewat menu dropdown)
await page.click('[data-testid="nav-menu-lain"]');
await page.waitForTimeout(600);
await page.click('[data-testid="nav-laporan"]');
await page.waitForSelector('[data-testid="laporan-tahunan-container"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const lapMasuk = await page.textContent('[data-testid="laporan-total-pemasukan"]');
const lapKeluar = await page.textContent('[data-testid="laporan-total-pengeluaran"]');
const lapSaldo = await page.textContent('[data-testid="laporan-saldo"]');
const narasi = await page.textContent('[data-testid="laporan-narasi"]');
const tabelRows = await page.locator('[data-testid="laporan-tabel-bulan"] tbody tr').count();
await page.screenshot({ path: 'laporan-atas.jpeg', quality: 20, type: 'jpeg' });
const dl = page.waitForEvent('download', { timeout: 20000 }).catch(() => null);
await page.click('[data-testid="btn-unduh-laporan"]');
const download = await dl;
await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
await page.waitForTimeout(1000);
await page.screenshot({ path: 'laporan-bawah.jpeg', quality: 20, type: 'jpeg' });

// 6. Bersihkan: hapus transaksi uji + 2 warga + reset iuran default
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-cari-transaksi"]', { timeout: 20000 });
await page.fill('[data-testid="input-cari-transaksi"]', 'Iuran sebagian');
await page.waitForTimeout(900);
await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
await page.click('[data-testid="btn-konfirmasi-hapus"]');
await page.waitForTimeout(2200);
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
for (let i = 0; i < 2; i++) {
  await page.click('[data-testid="btn-hapus-warga"] >> nth=0');
  await page.waitForSelector('[data-testid="dialog-hapus-warga"]', { timeout: 10000 });
  await page.click('[data-testid="btn-konfirmasi-hapus-warga"]');
  await page.waitForTimeout(1800);
}
const wargaLeft = await page.locator('[data-testid="warga-item"]').count();
await page.goto('https://language-learner-78.preview.emergentagent.com/pengaturan', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-iuran-default"]', { timeout: 20000 });
await page.fill('[data-testid="input-iuran-default"]', '0');
await page.click('[data-testid="btn-simpan-iuran-default"]');
await page.waitForTimeout(1500);
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const saldoEnd = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

console.log('IURAN prefill dari default:', iuranPrefill);
console.log('DUP error:', dupError?.trim());
console.log('BADGES sebelum setor:', JSON.stringify(kurangBadges), '| belum masuk:', belumMasuk, '| lunas:', sudahBayar?.replace(/\s+/g,' ').trim());
console.log('BADGES setelah setor 30rb (target 50rb):', JSON.stringify(badgesAfter), '| belum masuk:', belumMasukAfter);
console.log('PENGINGAT WA (180 char):', JSON.stringify(reminder?.slice(0, 180)));
console.log('LAPORAN masuk:', lapMasuk, '| keluar:', lapKeluar, '| saldo:', lapSaldo, '| baris tabel:', tabelRows);
console.log('NARASI:', narasi?.replace(/\s+/g, ' ').trim().slice(0, 200));
console.log('UNDUH laporan:', download ? download.suggestedFilename() : '(no event)');
console.log('CLEANUP warga tersisa:', wargaLeft, '| saldo akhir:', saldoEnd);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
