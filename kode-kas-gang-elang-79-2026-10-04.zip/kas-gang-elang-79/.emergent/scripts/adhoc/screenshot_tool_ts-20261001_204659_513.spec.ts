import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTAxNjF9.4pa-d3Cm9ihXW8YjeVA3emyvC-HLwhti2_yMtZY_IaE',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 30000 });

// Warga dengan nama panjang + target, untuk menguji perapian baris
await page.click('[data-testid="btn-tambah-warga"]');
await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
await page.fill('[data-testid="input-nama-warga"]', 'Pak Darmawan Kusumo');
await page.fill('[data-testid="input-iuran-warga"]', '50000');
await page.click('[data-testid="btn-simpan-warga"]');
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
await page.waitForTimeout(1500);
await page.screenshot({ path: 'warga-rapi.jpeg', quality: 20, type: 'jpeg' });

// nama tampil penuh tanpa terpotong?
const namaTampil = await page.locator('[data-testid="warga-item"] p').first().textContent();
const overflow = await page.evaluate(() => {
  const el = document.querySelector('[data-testid="warga-item"]') as HTMLElement | null;
  return el ? el.scrollWidth - el.clientWidth : -1;
});

// bersihkan
await page.click('[data-testid="btn-hapus-warga"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-hapus-warga"]', { timeout: 10000 });
await page.click('[data-testid="btn-konfirmasi-hapus-warga"]');
await page.waitForTimeout(2000);
const sisa = await page.locator('[data-testid="warga-item"]').count();

console.log('NAMA tampil:', JSON.stringify(namaTampil), '| overflow px (0 = pas):', overflow);
console.log('CLEANUP warga tersisa:', sisa);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
