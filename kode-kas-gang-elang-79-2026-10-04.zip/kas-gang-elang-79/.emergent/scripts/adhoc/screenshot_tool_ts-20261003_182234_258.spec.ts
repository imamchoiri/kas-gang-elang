import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const tok = require('fs').readFileSync('/tmp/tok.txt','utf8').trim();
await page.context().addCookies([{name:'kas_session', value:tok, domain:'language-learner-78.preview.emergentagent.com', path:'/', httpOnly:true, secure:true}]);
await page.setViewportSize({width:390, height:844});
await page.goto('/', {waitUntil:'domcontentloaded'});
const dl = page.waitForEvent('download', {timeout:60000});
// klik langsung seperti pengguna membuka link URL
await page.evaluate(() => { const a = document.createElement('a'); a.href='/api/kode-sumber/zip'; document.body.appendChild(a); a.click(); });
const f = await dl;
console.log('FILENAME:', f.suggestedFilename(), 'SIZE:', require('fs').statSync(await f.path()).size);
});
