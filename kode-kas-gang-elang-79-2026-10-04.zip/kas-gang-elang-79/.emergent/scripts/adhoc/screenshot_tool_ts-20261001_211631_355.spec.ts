import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTIwNjF9.gD1XhxtJuK81fe0we_E8oLXaT293zXgmqKUQXeJKbZM',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);
await page.context().grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://language-learner-78.preview.emergentagent.com' });

await page.setViewportSize({ width: 390, height: 844 });

// ===== 1. BERANDA: banner pengingat otomatis + ringkasan iuran =====
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="banner-pengingat"]', { timeout: 30000 });
await page.waitForSelector('[data-testid="ringkasan-iuran-beranda"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const ringkasanTeks = (await page.textContent('[data-testid="ringkasan-iuran-beranda"]'))?.replace(/\s+/g, ' ').trim();
const bannerTeks = (await page.textContent('[data-testid="banner-pengingat"]'))?.replace(/\s+/g, ' ').trim().slice(0, 120);
await page.screenshot({ path: 'beranda-pengingat.jpeg', quality: 20, type: 'jpeg' });

// pratinjau pesan pengingat
await page.click('[data-testid="btn-pratinjau-pengingat"]');
await page.waitForSelector('[data-testid="pratinjau-pengingat"]', { timeout: 10000 });
await page.waitForTimeout(700);
const pesanPengingat = await page.textContent('[data-testid="pratinjau-pengingat"]');
await page.screenshot({ path: 'beranda-pesan.jpeg', quality: 20, type: 'jpeg' });

// ===== 2. RINGKASAN BERANDA mengarah ke Iuran Warga =====
await page.click('[data-testid="ringkasan-iuran-beranda"]');
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 20000 });
await page.waitForTimeout(1500);

// ===== 3. LUNAS MASSAL =====
await page.click('[data-testid="btn-mode-pilih"]');
await page.waitForSelector('[data-testid="toolbar-lunas-massal"]', { timeout: 10000 });
await page.waitForTimeout(600);
const kandidat = await page.locator('[data-testid="checkbox-warga"]').count();
await page.click('[data-testid="btn-pilih-semua-belum"]');
await page.waitForTimeout(900);
const toolbarTeks = (await page.textContent('[data-testid="toolbar-lunas-massal"]'))?.replace(/\s+/g, ' ').trim();
await page.screenshot({ path: 'lunas-massal-pilih.jpeg', quality: 20, type: 'jpeg' });
const saldoSebelum = await page.evaluate(async () => {
  const l = await (await fetch('/api/transactions')).json();
  return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
});
await page.click('[data-testid="btn-lunas-massal"]');
await page.waitForSelector('[data-testid="dialog-konfirmasi-massal"]', { timeout: 10000 });
const dialogTeks = (await page.textContent('[data-testid="dialog-konfirmasi-massal"]'))?.replace(/\s+/g, ' ').trim();
await page.screenshot({ path: 'lunas-massal-konfirmasi.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-konfirmasi-massal"]');
await page.waitForTimeout(3000);
const saldoSesudah = await page.evaluate(async () => {
  const l = await (await fetch('/api/transactions')).json();
  return l.reduce((s: number, t: { type: string; amount: number }) => s + (t.type === 'masuk' ? t.amount : -t.amount), 0);
});
const lunasSesudah = (await page.textContent('[data-testid="warga-sudah-bayar"]'))?.replace(/\s+/g, ' ').trim();
await page.screenshot({ path: 'lunas-massal-hasil.jpeg', quality: 20, type: 'jpeg' });

// ===== 4. RIWAYAT PERUBAHAN =====
await page.click('[data-testid="nav-menu-lain"]');
await page.waitForTimeout(600);
await page.click('[data-testid="nav-riwayat"]');
await page.waitForSelector('[data-testid="riwayat-container"]', { timeout: 20000 });
await page.waitForSelector('[data-testid="riwayat-item"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const jumlahRiwayat = await page.locator('[data-testid="riwayat-item"]').count();
const riwayatTeratas = (await page.locator('[data-testid="riwayat-item"]').first().textContent())?.replace(/\s+/g, ' ').trim();
await page.screenshot({ path: 'riwayat-perubahan.jpeg', quality: 20, type: 'jpeg' });

// ===== 5. BERSIHKAN: hapus transaksi lunas massal yang baru dibuat =====
const dihapus = await page.evaluate(async () => {
  const l = await (await fetch('/api/transactions')).json();
  const target = l.filter((t: { description: string }) => t.description.startsWith('Iuran Oktober 2026 —'));
  for (const t of target) await fetch(`/api/transactions/${t.id}`, { method: 'DELETE' });
  return target.length;
});
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const saldoAkhir = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

console.log('RINGKASAN BERANDA:', ringkasanTeks);
console.log('BANNER:', bannerTeks);
console.log('PESAN PENGINGAT (120):', JSON.stringify(pesanPengingat?.slice(0, 120)));
console.log('LUNAS MASSAL — kandidat checkbox:', kandidat, '| toolbar:', toolbarTeks);
console.log('DIALOG:', dialogTeks?.slice(0, 160));
console.log('SALDO sebelum:', saldoSebelum, '→ sesudah massal:', saldoSesudah, '| lunas:', lunasSesudah);
console.log('RIWAYAT — jumlah:', jumlahRiwayat, '| teratas:', riwayatTeratas?.slice(0, 110));
console.log('CLEANUP dihapus:', dihapus, '| saldo akhir di UI:', saldoAkhir);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
