import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTAxNjF9.4pa-d3Cm9ihXW8YjeVA3emyvC-HLwhti2_yMtZY_IaE',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 30000 });

// dua warga: nama panjang dengan target, dan satu lunas
for (const [nama, target] of [['Pak Darmawan Kusumo', '50000'], ['Bu Sri', '25000']] as const) {
  await page.click('[data-testid="btn-tambah-warga"]');
  await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
  await page.fill('[data-testid="input-nama-warga"]', nama);
  await page.fill('[data-testid="input-iuran-warga"]', target);
  await page.click('[data-testid="btn-simpan-warga"]');
  await page.waitForTimeout(1600);
}
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
await page.waitForTimeout(1000);
await page.screenshot({ path: 'warga-rapi2.jpeg', quality: 20, type: 'jpeg' });

// apakah nama & target tampil utuh (tidak terpotong elipsis)?
const info = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('[data-testid="warga-item"]')];
  return rows.map((r) => {
    const ps = r.querySelectorAll('p');
    const nama = ps[0] as HTMLElement;
    const meta = ps[1] as HTMLElement;
    return {
      nama: nama.textContent,
      namaTerpotong: nama.scrollWidth > nama.clientWidth,
      meta: meta.textContent,
      metaTerpotong: meta.scrollWidth > meta.clientWidth,
    };
  });
});

// bersihkan kedua warga uji
for (let i = 0; i < 2; i++) {
  await page.click('[data-testid="btn-hapus-warga"] >> nth=0');
  await page.waitForSelector('[data-testid="dialog-hapus-warga"]', { timeout: 10000 });
  await page.click('[data-testid="btn-konfirmasi-hapus-warga"]');
  await page.waitForTimeout(1800);
}
const sisa = await page.locator('[data-testid="warga-item"]').count();

console.log('ROWS:', JSON.stringify(info, null, 1));
console.log('CLEANUP warga tersisa:', sisa);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
