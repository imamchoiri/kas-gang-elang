import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.setViewportSize({ width: 390, height: 844 });

// 1. Masuk
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="bendahara-password-input"]', { timeout: 30000 });
await page.fill('[data-testid="bendahara-password-input"]', 'elang79');
await page.click('[data-testid="bendahara-login-button"]');
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
const saldoStart = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

// 2. Catat pengeluaran + foto bukti
await page.click('[data-testid="btn-tambah-pengeluaran"]');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
await page.fill('[data-testid="input-transaksi-kategori"]', 'Konsumsi Ronda');
await page.fill('[data-testid="input-transaksi-jumlah"]', '20000');
await page.fill('[data-testid="input-transaksi-keterangan"]', 'Kopi untuk pengawal ronda');
await page.setInputFiles('[data-testid="input-foto-bukti"]', '/app/frontend/public/elang-crest.jpg');
await page.waitForSelector('[data-testid="preview-foto-bukti"]', { timeout: 15000 });
await page.screenshot({ path: 'form-foto.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
await page.waitForSelector('[data-testid="btn-lihat-foto"]', { timeout: 20000 });
await page.waitForTimeout(1200);

// 3. Lihat foto bukti
await page.click('[data-testid="btn-lihat-foto"] >> nth=0');
await page.waitForSelector('[data-testid="img-foto-bukti"]', { timeout: 10000 });
await page.screenshot({ path: 'dialog-foto.jpeg', quality: 20, type: 'jpeg' });
await page.keyboard.press('Escape');
await page.waitForTimeout(500);

// 4. Edit transaksi lewat pensil
const saldoBeforeEdit = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.click('[data-testid="btn-edit-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
const prefillJumlah = await page.inputValue('[data-testid="input-transaksi-jumlah"]');
const prefillKet = await page.inputValue('[data-testid="input-transaksi-keterangan"]');
await page.waitForSelector('[data-testid="preview-foto-bukti"]', { timeout: 10000 });
await page.fill('[data-testid="input-transaksi-jumlah"]', '25000');
await page.screenshot({ path: 'form-edit.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
await page.waitForTimeout(1500);
const saldoAfterEdit = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.screenshot({ path: 'home-after-edit.jpeg', quality: 20, type: 'jpeg' });

// 5. Pengaturan: sandi lama salah -> pesan error (sandi asli TIDAK diubah)
await page.click('[data-testid="nav-pengaturan"]');
await page.waitForSelector('[data-testid="form-ganti-sandi"]', { timeout: 15000 });
await page.fill('[data-testid="input-sandi-lama"]', 'bukan-sandi');
await page.fill('[data-testid="input-sandi-baru"]', 'sandi-baru-x');
await page.fill('[data-testid="input-konfirmasi-sandi"]', 'sandi-baru-x');
await page.click('[data-testid="btn-simpan-sandi"]');
await page.waitForSelector('[data-testid="ganti-sandi-error-message"]', { timeout: 15000 });
await page.screenshot({ path: 'pengaturan-error.jpeg', quality: 20, type: 'jpeg' });

// 6. Rekap: unduh Excel
await page.click('[data-testid="nav-rekap"]');
await page.waitForSelector('[data-testid="btn-unduh-excel"]', { timeout: 15000 });
const downloadPromise = page.waitForEvent('download', { timeout: 20000 }).catch(() => null);
await page.click('[data-testid="btn-unduh-excel"]');
const download = await downloadPromise;
const downloadOk = download ? await download.path() !== null : false;
await page.waitForTimeout(800);
await page.screenshot({ path: 'rekap-excel.jpeg', quality: 20, type: 'jpeg' });

// 7. Bersihkan transaksi uji (verifikasi hapus + foto ikut terhapus)
await page.click('[data-testid="nav-beranda"]');
await page.waitForSelector('[data-testid="btn-hapus-transaksi"]', { timeout: 15000 });
await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
await page.click('[data-testid="btn-konfirmasi-hapus"]');
await page.waitForTimeout(2500);
const saldoEnd = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

// 8. Keluar
await page.click('[data-testid="bendahara-logout-button"]');
await page.waitForSelector('[data-testid="bendahara-password-input"]', { timeout: 20000 });

console.log('SALDO start:', saldoStart, '| before edit:', saldoBeforeEdit, '| after edit:', saldoAfterEdit, '| end:', saldoEnd);
console.log('EDIT PREFILL jumlah:', prefillJumlah, '| keterangan:', prefillKet);
console.log('EXCEL DOWNLOAD OK:', downloadOk, download ? download.suggestedFilename() : '(no event)');
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
