import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTIwNjF9.gD1XhxtJuK81fe0we_E8oLXaT293zXgmqKUQXeJKbZM',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 30000 });
await page.waitForTimeout(1500);

// mode pilih aktif
await page.click('[data-testid="btn-mode-pilih"]');
await page.waitForSelector('[data-testid="toolbar-lunas-massal"]', { timeout: 10000 });
await page.click('[data-testid="btn-pilih-semua-belum"]');
await page.waitForTimeout(900);
await page.screenshot({ path: 'pilih-mode-rapi.jpeg', quality: 20, type: 'jpeg' });

// cek tidak ada yang melebihi lebar kartu & nama tidak terpotong
const cek = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('[data-testid="warga-item"]')];
  return rows.map((r) => {
    const el = r as HTMLElement;
    const nama = r.querySelector('button span span') as HTMLElement | null;
    return {
      overflowX: el.scrollWidth - el.clientWidth,
      nama: nama?.textContent,
      namaTerpotong: nama ? nama.scrollWidth > nama.clientWidth : null,
      adaTombolLunasCepat: !!r.querySelector('[data-testid="btn-tandai-lunas"]'),
      adaCheckbox: !!r.querySelector('[data-testid="checkbox-warga"]'),
    };
  });
});

// keluar mode pilih → tombol lunas cepat kembali
await page.click('[data-testid="btn-mode-pilih"]');
await page.waitForTimeout(900);
const setelahKeluar = await page.evaluate(() => {
  const r = document.querySelector('[data-testid="warga-item"]');
  return {
    adaTombolLunasCepat: !!r?.querySelector('[data-testid="btn-tandai-lunas"]'),
    adaCheckbox: !!r?.querySelector('[data-testid="checkbox-warga"]'),
  };
});
await page.screenshot({ path: 'pilih-mode-keluar.jpeg', quality: 20, type: 'jpeg' });

console.log('BARIS saat mode pilih:', JSON.stringify(cek, null, 1));
console.log('Setelah keluar mode pilih:', JSON.stringify(setelahKeluar));
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
