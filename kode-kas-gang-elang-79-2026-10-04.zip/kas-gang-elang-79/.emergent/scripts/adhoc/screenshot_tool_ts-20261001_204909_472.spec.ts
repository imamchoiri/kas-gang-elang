import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

const ctx = page.context();
await ctx.grantPermissions(['clipboard-read', 'clipboard-write'], { origin: 'https://language-learner-78.preview.emergentagent.com' });
await ctx.addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4OTAxNjF9.4pa-d3Cm9ihXW8YjeVA3emyvC-HLwhti2_yMtZY_IaE',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/warga', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 30000 });

// dua warga uji: satu akan lunas, satu kurang bayar
for (const [nama, target] of [['Pak Darmawan Kusumo', '50000'], ['Bu Sri', '25000']] as const) {
  await page.click('[data-testid="btn-tambah-warga"]');
  await page.waitForSelector('[data-testid="input-nama-warga"]', { timeout: 10000 });
  await page.fill('[data-testid="input-nama-warga"]', nama);
  await page.fill('[data-testid="input-iuran-warga"]', target);
  await page.click('[data-testid="btn-simpan-warga"]');
  await page.waitForTimeout(1600);
}

// Bu Sri bayar penuh 25rb -> Lunas; Pak Darmawan bayar 20rb -> Kurang Rp 30.000
for (const [nama, jumlah] of [['Bu Sri', '25000'], ['Pak Darmawan Kusumo', '20000']] as const) {
  await page.click('[data-testid="btn-tambah-pemasukan"]');
  await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
  await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
  await page.click('[data-testid="input-transaksi-kategori"]');
  await page.getByRole('option', { name: 'Uang Kas' }).click({ force: true });
  await page.fill('[data-testid="input-transaksi-jumlah"]', jumlah);
  await page.fill('[data-testid="input-transaksi-keterangan"]', 'Iuran uji coba');
  await page.fill('[data-testid="input-transaksi-warga"]', nama);
  await page.click('[data-testid="btn-simpan-transaksi"]');
  await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
  await page.waitForTimeout(1200);
  await page.click('[data-testid="nav-warga"]');
  await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
  await page.waitForTimeout(1200);
}

await page.waitForTimeout(800);
await page.screenshot({ path: 'warga-final.jpeg', quality: 20, type: 'jpeg' });
const rows = await page.evaluate(() => {
  return [...document.querySelectorAll('[data-testid="warga-item"]')].map((r) => {
    const ps = r.querySelectorAll('p');
    const nama = ps[0] as HTMLElement;
    const meta = ps[1] as HTMLElement;
    return {
      nama: nama.textContent,
      namaTerpotong: nama.scrollWidth > nama.clientWidth,
      meta: meta.textContent,
      metaTerpotong: meta.scrollWidth > meta.clientWidth,
      status: r.textContent?.includes('Lunas') ? 'Lunas' : r.querySelector('[data-testid="badge-kurang-bayar"]')?.textContent,
    };
  });
});
const lunas = await page.textContent('[data-testid="warga-sudah-bayar"]');
const kurang = await page.textContent('[data-testid="warga-total-kurang"]');
const terkumpul = await page.textContent('[data-testid="warga-terkumpul"]');

// filter Lunas / Belum Lunas
await page.getByTestId('filter-status-warga').nth(1).click();
await page.waitForTimeout(700);
const nLunas = await page.locator('[data-testid="warga-item"]').count();
await page.getByTestId('filter-status-warga').nth(2).click();
await page.waitForTimeout(700);
const nBelum = await page.locator('[data-testid="warga-item"]').count();
await page.getByTestId('filter-status-warga').nth(0).click();
await page.waitForTimeout(500);

// pengingat WA hanya memuat yang belum lunas
await page.click('[data-testid="btn-pengingat-wa"]');
await page.waitForTimeout(1500);
const reminder = await page.evaluate(() => navigator.clipboard.readText());

// bersihkan: 2 transaksi + 2 warga
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="input-cari-transaksi"]', { timeout: 20000 });
await page.fill('[data-testid="input-cari-transaksi"]', 'Iuran uji coba');
await page.waitForTimeout(900);
for (let i = 0; i < 2; i++) {
  await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
  await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
  await page.click('[data-testid="btn-konfirmasi-hapus"]');
  await page.waitForTimeout(2000);
}
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
for (let i = 0; i < 2; i++) {
  await page.click('[data-testid="btn-hapus-warga"] >> nth=0');
  await page.waitForSelector('[data-testid="dialog-hapus-warga"]', { timeout: 10000 });
  await page.click('[data-testid="btn-konfirmasi-hapus-warga"]');
  await page.waitForTimeout(1800);
}
const sisaWarga = await page.locator('[data-testid="warga-item"]').count();
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const saldoEnd = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

console.log('ROWS:', JSON.stringify(rows, null, 1));
console.log('RINGKASAN lunas:', lunas?.replace(/\s+/g,' ').trim(), '| terkumpul:', terkumpul, '| belum masuk:', kurang);
console.log('FILTER lunas rows:', nLunas, '| belum lunas rows:', nBelum);
console.log('PENGINGAT memuat Pak Darmawan:', reminder?.includes('Pak Darmawan Kusumo'), '| memuat Bu Sri:', reminder?.includes('Bu Sri'), '| total kurang di pesan:', reminder?.includes('Rp 30.000'));
console.log('CLEANUP warga:', sisaWarga, '| saldo akhir:', saldoEnd);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
