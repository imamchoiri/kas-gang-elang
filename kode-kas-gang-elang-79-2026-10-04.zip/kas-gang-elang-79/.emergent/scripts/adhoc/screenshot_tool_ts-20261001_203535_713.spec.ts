import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

// Sesi disuntik: sandi bendahara sudah diganti oleh pengguna, jadi login lewat token sah.
await page.context().addCookies([{
  name: 'kas_session',
  value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJiZW5kYWhhcmEiLCJleHAiOjE3OTA4ODg2NjB9.02pI1ULSmHAvq7MXztaw77WklN3_yRxzrDH7XQvqG18',
  domain: 'language-learner-78.preview.emergentagent.com',
  path: '/',
}]);

await page.setViewportSize({ width: 390, height: 844 });
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 30000 });
const saldoStart = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

// 1. Catat pemasukan dengan NAMA WARGA (fitur Saldo per Warga)
await page.click('[data-testid="btn-tambah-pemasukan"]');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
await page.click('[data-testid="input-transaksi-kategori"]');
await page.getByRole('option', { name: 'Uang Kas' }).click({ force: true });
await page.fill('[data-testid="input-transaksi-jumlah"]', '45000');
await page.fill('[data-testid="input-transaksi-keterangan"]', 'Iuran bulanan');
await page.fill('[data-testid="input-transaksi-warga"]', 'Bu Sari');
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 30000 });
await page.waitForTimeout(1500);
const saldoAfter = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.screenshot({ path: 'home-warga.jpeg', quality: 20, type: 'jpeg' });

// 2. KWITANSI DIGITAL — render canvas + pratinjau
await page.click('[data-testid="btn-kwitansi-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="img-kwitansi"]', { timeout: 20000 });
await page.waitForTimeout(1000);
await page.screenshot({ path: 'dialog-kwitansi.jpeg', quality: 20, type: 'jpeg' });
const kwitansiSize = await page.evaluate(() => {
  const img = document.querySelector('[data-testid="img-kwitansi"]') as HTMLImageElement | null;
  return img ? `${img.naturalWidth}x${img.naturalHeight}` : 'none';
});
await page.keyboard.press('Escape');
await page.waitForTimeout(600);

// 3. IURAN WARGA — status lunas
await page.click('[data-testid="nav-warga"]');
await page.waitForSelector('[data-testid="iuran-warga-container"]', { timeout: 20000 });
await page.waitForSelector('[data-testid="warga-item"]', { timeout: 20000 });
const sudahBayar = await page.textContent('[data-testid="warga-sudah-bayar"]');
const terkumpul = await page.textContent('[data-testid="warga-terkumpul"]');
const wargaCount = await page.locator('[data-testid="warga-item"]').count();
await page.screenshot({ path: 'warga-lunas.jpeg', quality: 20, type: 'jpeg' });
// filter "Belum Bayar"
await page.getByTestId('filter-status-warga').nth(2).click();
await page.waitForTimeout(600);
await page.screenshot({ path: 'warga-belum.jpeg', quality: 20, type: 'jpeg' });

// 4. GRAFIK TAHUNAN di Rekap
await page.click('[data-testid="nav-rekap"]');
await page.waitForSelector('[data-testid="chart-tahunan"]', { timeout: 20000 });
await page.waitForTimeout(1200);
const bars = await page.locator('[data-testid="chart-tahunan"] .recharts-bar-rectangle').count();
await page.screenshot({ path: 'rekap-grafik.jpeg', quality: 20, type: 'jpeg' });

// 5. MODE GELAP
await page.click('[data-testid="nav-pengaturan"]');
await page.waitForSelector('[data-testid="btn-mode-gelap"]', { timeout: 15000 });
await page.click('[data-testid="btn-mode-gelap"]');
await page.waitForTimeout(900);
const isDark = await page.evaluate(() => document.documentElement.classList.contains('dark'));
await page.screenshot({ path: 'mode-gelap-pengaturan.jpeg', quality: 20, type: 'jpeg' });
// beranda dalam mode gelap
await page.click('[data-testid="nav-beranda"]');
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(900);
await page.screenshot({ path: 'mode-gelap-beranda.jpeg', quality: 20, type: 'jpeg' });
// mode gelap bertahan setelah reload
await page.reload({ waitUntil: 'domcontentloaded' });
await page.waitForTimeout(1500);
const darkAfterReload = await page.evaluate(() => document.documentElement.classList.contains('dark'));

// 6. Bersihkan transaksi uji + kembalikan ke mode terang
await page.waitForSelector('[data-testid="btn-hapus-transaksi"]', { timeout: 20000 });
await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
await page.click('[data-testid="btn-konfirmasi-hapus"]');
await page.waitForTimeout(2500);
const saldoEnd = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.click('[data-testid="nav-pengaturan"]');
await page.waitForSelector('[data-testid="btn-mode-gelap"]', { timeout: 15000 });
await page.click('[data-testid="btn-mode-gelap"]');
await page.waitForTimeout(700);
const backToLight = await page.evaluate(() => !document.documentElement.classList.contains('dark'));

console.log('SALDO start:', saldoStart, '| after +45rb:', saldoAfter, '| end (after cleanup):', saldoEnd);
console.log('KWITANSI canvas:', kwitansiSize);
console.log('WARGA sudah bayar:', sudahBayar?.trim(), '| terkumpul:', terkumpul, '| rows:', wargaCount);
console.log('CHART bars rendered:', bars);
console.log('DARK after toggle:', isDark, '| persists after reload:', darkAfterReload, '| back to light:', backToLight);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
