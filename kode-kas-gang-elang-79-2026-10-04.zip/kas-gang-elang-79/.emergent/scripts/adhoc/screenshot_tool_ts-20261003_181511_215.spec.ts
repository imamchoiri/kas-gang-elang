import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const tok = require('fs').readFileSync('/tmp/tok.txt','utf8').trim();
await page.context().addCookies([{name:'kas_session', value:tok, domain:'language-learner-78.preview.emergentagent.com', path:'/', httpOnly:true, secure:true}]);
page.on('console', m => { if (m.type()==='error') console.log('CONSOLE ERROR:', m.text()); });
page.on('response', r => { if (r.status()>=400) console.log('HTTP', r.status(), r.url()); });
await page.setViewportSize({width:390, height:844});
await page.goto('/pengaturan', {waitUntil:'domcontentloaded'});
await page.waitForSelector('[data-testid="btn-unduh-kode-zip"]', {timeout:20000});
await page.getByTestId('btn-unduh-kode-zip').scrollIntoViewIfNeeded();
await page.screenshot({path:'kartu-unduh.png', type:'jpeg', fullPage:false});
const dl = page.waitForEvent('download', {timeout:60000});
await page.getByTestId('btn-unduh-kode-zip').click({force:true});
const file = await dl;
console.log('DOWNLOAD FILENAME:', file.suggestedFilename());
const p = await file.path();
console.log('SIZE:', require('fs').statSync(p).size);
await page.waitForTimeout(1500);
await page.screenshot({path:'setelah-unduh.png', type:'jpeg', fullPage:false});
});
