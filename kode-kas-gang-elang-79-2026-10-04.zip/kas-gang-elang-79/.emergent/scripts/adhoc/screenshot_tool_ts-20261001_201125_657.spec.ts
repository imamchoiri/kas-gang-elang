import { test, expect } from '@playwright/test';

test('screenshot', async ({ page }) => {
  const errors: string[] = [];
const failed: string[] = [];
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('response', (r) => { if (r.status() >= 400) failed.push(`${r.status()} ${r.url()}`); });

await page.setViewportSize({ width: 390, height: 844 });

// 1. Unauthenticated visit lands on the sandi gate
await page.goto('https://language-learner-78.preview.emergentagent.com/', { waitUntil: 'domcontentloaded' });
await page.waitForSelector('[data-testid="bendahara-password-input"]', { timeout: 30000 });

// 2. Wrong password shows friendly error
await page.fill('[data-testid="bendahara-password-input"]', 'salah123');
await page.click('[data-testid="bendahara-login-button"]');
await page.waitForSelector('[data-testid="login-error-message"]', { timeout: 15000 });
await page.screenshot({ path: 'login-error.jpeg', quality: 20, type: 'jpeg' });

// 3. Correct sandi opens the dashboard
await page.fill('[data-testid="bendahara-password-input"]', 'elang79');
await page.click('[data-testid="bendahara-login-button"]');
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
const saldoBefore = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

// 4. Catat pemasukan via dock
await page.click('[data-testid="btn-tambah-pemasukan"]');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
await page.waitForFunction(() => (document.querySelector('[data-testid="input-transaksi-tanggal"]') as HTMLInputElement | null)?.value !== '', undefined, { timeout: 15000 });
await page.click('[data-testid="input-transaksi-kategori"]');
await page.getByRole('option', { name: 'Uang Kas' }).click({ force: true });
await page.fill('[data-testid="input-transaksi-jumlah"]', '50000');
await page.fill('[data-testid="input-transaksi-keterangan"]', 'Uang kas warga — Pak Budi');
await page.screenshot({ path: 'form-masuk.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 20000 });
await page.waitForSelector('[data-testid="total-sisa-saldo-amount"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const saldoAfterMasuk = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.screenshot({ path: 'home-after-masuk.jpeg', quality: 20, type: 'jpeg' });

// 5. Catat pengeluaran
await page.click('[data-testid="btn-tambah-pengeluaran"]');
await page.waitForSelector('[data-testid="form-transaksi"]', { timeout: 15000 });
await page.fill('[data-testid="input-transaksi-kategori"]', 'Sembako');
await page.fill('[data-testid="input-transaksi-jumlah"]', '15000');
await page.fill('[data-testid="input-transaksi-keterangan"]', 'Beli sembako patrol ronda');
await page.click('[data-testid="btn-simpan-transaksi"]');
await page.waitForURL((u) => u.pathname === '/', { timeout: 20000 });
await page.waitForSelector('[data-testid="total-pengeluaran-amount"]', { timeout: 20000 });
await page.waitForTimeout(1500);
const pemasukanText = await page.textContent('[data-testid="total-pemasukan-amount"]');
const pengeluaranText = await page.textContent('[data-testid="total-pengeluaran-amount"]');
const saldoAfterKeluar = await page.textContent('[data-testid="total-sisa-saldo-amount"]');
await page.screenshot({ path: 'home-after-keluar.jpeg', quality: 20, type: 'jpeg' });

// 6. Hapus transaksi teratas dengan konfirmasi
await page.click('[data-testid="btn-hapus-transaksi"] >> nth=0');
await page.waitForSelector('[data-testid="dialog-konfirmasi-hapus"]', { timeout: 10000 });
await page.screenshot({ path: 'dialog-hapus.jpeg', quality: 20, type: 'jpeg' });
await page.click('[data-testid="btn-konfirmasi-hapus"]');
await page.waitForTimeout(2500);
const saldoAfterDelete = await page.textContent('[data-testid="total-sisa-saldo-amount"]');

// 7. Rekap bulanan
await page.click('[data-testid="btn-buka-rekap"]');
await page.waitForSelector('[data-testid="select-bulan-rekap"]', { timeout: 20000 });
await page.waitForTimeout(800);
await page.screenshot({ path: 'rekap.jpeg', quality: 20, type: 'jpeg' });

// 8. Keluar
await page.click('[data-testid="bendahara-logout-button"]');
await page.waitForSelector('[data-testid="bendahara-password-input"]', { timeout: 20000 });
await page.screenshot({ path: 'after-logout.jpeg', quality: 20, type: 'jpeg' });

console.log('SALDO before:', saldoBefore);
console.log('SALDO after masuk:', saldoAfterMasuk);
console.log('PEMASUKAN:', pemasukanText, '| PENGELUARAN:', pengeluaranText, '| SALDO after keluar:', saldoAfterKeluar);
console.log('SALDO after delete:', saldoAfterDelete);
console.log('CONSOLE ERRORS:', JSON.stringify(errors));
console.log('FAILED RESPONSES (>=400):', JSON.stringify(failed));
});
