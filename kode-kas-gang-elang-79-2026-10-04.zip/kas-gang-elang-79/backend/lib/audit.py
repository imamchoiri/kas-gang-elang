"""Riwayat perubahan (audit log) — dicatat tiap kali data kas diubah."""

import uuid
from datetime import datetime, timezone

from lib.db import db

ENTITAS = ("transaksi", "warga", "backup", "pengingat")
AKSI = ("tambah", "ubah", "hapus", "pulihkan", "kirim")


async def catat_audit(aksi: str, entitas: str, ringkasan: str, detail: str = "") -> None:
    """Simpan satu baris riwayat. Sengaja tidak pernah melempar error —
    gagal mencatat riwayat tidak boleh menggagalkan aksi bendahara."""
    try:
        await db.audit.insert_one(
            {
                "id": str(uuid.uuid4()),
                "at": datetime.now(timezone.utc),
                "aksi": aksi,
                "entitas": entitas,
                "ringkasan": ringkasan,
                "detail": detail,
            }
        )
    except Exception:  # noqa: BLE001 — audit bersifat best-effort
        pass


def rupiah(n: int) -> str:
    """Format Rupiah untuk teks riwayat/pengingat (1.234.567)."""
    return f"Rp {n:,.0f}".replace(",", ".")
