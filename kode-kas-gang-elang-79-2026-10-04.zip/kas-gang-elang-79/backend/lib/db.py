"""Shared Mongo handle — import `client`/`db` from here (server.py, routers, seed.py)."""

import logging
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING, IndexModel

load_dotenv(Path(__file__).parent.parent / ".env")

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

logger = logging.getLogger(__name__)

# One entry per collection: every field a route filters, sorts, or dedupes on. Applied by ensure_indexes() at startup.
INDEXES: dict[str, list[IndexModel]] = {
    "status_checks": [IndexModel([("timestamp", DESCENDING)], name="timestamp_desc")],
    "transactions": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("date", DESCENDING), ("created_at", DESCENDING)], name="date_created_desc"),
    ],
    "photos": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
    ],
    "residents": [
        IndexModel([("id", ASCENDING)], name="id", unique=True),
        IndexModel([("nama", ASCENDING)], name="nama"),
    ],
    "notes": [
        IndexModel([("year", ASCENDING)], name="year", unique=True),
    ],
    "audit": [
        IndexModel([("at", DESCENDING)], name="at_desc"),
    ],
    "reminders": [
        IndexModel([("month", ASCENDING)], name="month", unique=True),
    ],
    "cron_runs": [
        IndexModel([("run_id", ASCENDING)], name="run_id", unique=True),
    ],
}


async def ensure_indexes() -> None:
    for collection, models in INDEXES.items():
        for model in models:  # one at a time so a bad spec skips only itself
            try:
                await db[collection].create_indexes([model])
            except Exception as exc:  # never block boot on an index; the log line names what to fix
                logger.error("ensure_indexes(%s.%s): %s", collection, model.document["name"], exc)
