"""Pydantic models for Kas Gang Elang 79 — mirrors frontend/src/lib/types.ts (keep in sync)."""

import uuid
from datetime import datetime, timezone
from typing import List, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

KATEGORI_MASUK = [
    "Uang Kas",
    "Donatur",
    "Denda Kerja Bhakti",
    "Denda Ronda",
    "Kolektif Warga",
]


class Ok(BaseModel):
    ok: bool = True


class LoginRequest(BaseModel):
    password: str


class Me(BaseModel):
    authenticated: bool


class Meta(BaseModel):
    today: str  # YYYY-MM-DD, anchored server-side (WIB)
    month: str  # YYYY-MM


class PasswordChange(BaseModel):
    password_lama: str
    password_baru: str = Field(min_length=5)


class KasSettings(BaseModel):
    """Pengaturan kas yang bisa diubah bendahara."""

    iuran_default: int = 0  # target iuran bulanan default untuk warga baru


class ResidentCreate(BaseModel):
    nama: str
    iuran_bulanan: int = Field(default=0, ge=0)

    @field_validator("nama", mode="before")
    @classmethod
    def strip_nama(cls, v: object) -> object:
        return v.strip() if isinstance(v, str) else v

    @field_validator("nama")
    @classmethod
    def nama_wajib(cls, v: str) -> str:
        if not v:
            raise ValueError("Nama warga wajib diisi")
        return v


class Resident(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    nama: str
    iuran_bulanan: int = 0
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_validator("created_at", mode="before")
    @classmethod
    def naive_to_utc(cls, v: object) -> object:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class ImportResult(BaseModel):
    ditambahkan: int


class MeetingNote(BaseModel):
    """Catatan rapat warga, satu per tahun laporan."""

    year: str
    text: str = ""
    updated_at: datetime | None = None

    @field_validator("text", mode="before")
    @classmethod
    def strip_text_note(cls, v: object) -> object:
        return v.strip() if isinstance(v, str) else v

    @field_validator("updated_at", mode="before")
    @classmethod
    def naive_to_utc_note(cls, v: object) -> object:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class NoteInput(BaseModel):
    text: str = ""

    @field_validator("text", mode="before")
    @classmethod
    def strip_note(cls, v: object) -> object:
        return v.strip() if isinstance(v, str) else v


class RestoreResult(BaseModel):
    transaksi: int
    warga: int
    dilewati: int
    foto_hilang: int


class AuditEntry(BaseModel):
    id: str
    at: datetime
    aksi: str
    entitas: str
    ringkasan: str
    detail: str = ""

    @field_validator("at", mode="before")
    @classmethod
    def naive_to_utc_audit(cls, v: object) -> object:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class Reminder(BaseModel):
    """Pesan pengingat iuran yang disiapkan otomatis oleh penjadwal."""

    month: str  # YYYY-MM
    text: str
    belum_lunas: int
    total_kurang: int
    created_at: datetime
    sent_at: datetime | None = None

    @field_validator("created_at", "sent_at", mode="before")
    @classmethod
    def naive_to_utc_rem(cls, v: object) -> object:
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v


class ReminderState(BaseModel):
    """Beranda memanggil ini — `reminder` null bila belum ada yang disiapkan."""

    reminder: Reminder | None = None


class BulkResult(BaseModel):
    dibuat: int
    ids: List[str]


class PhotoRef(BaseModel):
    id: str


class TransactionCreate(BaseModel):
    type: Literal["masuk", "keluar"]
    category: str = ""
    amount: int = Field(gt=0)
    description: str = ""
    date: str  # YYYY-MM-DD
    photo_id: str = ""  # id foto bukti di koleksi photos (kosong = tanpa foto)
    warga: str = ""  # nama warga (opsional) — untuk rekap iuran per warga

    @field_validator("category", "description", "warga", mode="before")
    @classmethod
    def strip_text(cls, v: object) -> object:
        return v.strip() if isinstance(v, str) else v

    @field_validator("date")
    @classmethod
    def valid_date(cls, v: str) -> str:
        try:
            datetime.strptime(v, "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError("Tanggal harus berformat YYYY-MM-DD") from exc
        return v

    @model_validator(mode="after")
    def category_rules(self) -> "TransactionCreate":
        if self.type == "masuk" and self.category not in KATEGORI_MASUK:
            raise ValueError(
                f"Kategori pemasukan harus salah satu dari: {', '.join(KATEGORI_MASUK)}"
            )
        return self


class Transaction(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: Literal["masuk", "keluar"]
    category: str = ""
    amount: int
    description: str = ""
    date: str  # YYYY-MM-DD
    photo_id: str = ""  # id foto bukti (kosong = tanpa foto)
    warga: str = ""  # nama warga (opsional)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @field_validator("created_at", mode="before")
    @classmethod
    def naive_to_utc(cls, v: object) -> object:
        # Motor hands back naive datetimes — normalise to aware UTC so JS parses them right.
        if isinstance(v, datetime) and v.tzinfo is None:
            return v.replace(tzinfo=timezone.utc)
        return v
