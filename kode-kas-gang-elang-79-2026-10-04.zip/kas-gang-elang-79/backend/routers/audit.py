"""Riwayat perubahan data kas (audit log) — hanya dibaca."""

from typing import List

from fastapi import APIRouter, Depends, Query
from pymongo import DESCENDING

from lib.db import db
from models.kas import AuditEntry
from routers.auth import require_auth

router = APIRouter(prefix="/audit", tags=["audit"], dependencies=[Depends(require_auth)])


@router.get("", response_model=List[AuditEntry])
async def list_audit(limit: int = Query(default=100, ge=1, le=500)) -> List[AuditEntry]:
    docs = await db.audit.find({}, {"_id": 0}).sort([("at", DESCENDING)]).to_list(limit)
    return [AuditEntry(**doc) for doc in docs]
