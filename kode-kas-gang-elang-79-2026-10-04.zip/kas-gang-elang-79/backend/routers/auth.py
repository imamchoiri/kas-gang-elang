"""Shared-password auth for the bendahara: httpOnly JWT cookie sessions under /api/auth."""

import secrets
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from passlib.context import CryptContext
from pymongo.errors import DuplicateKeyError

from lib.db import db
from models.kas import KasSettings, LoginRequest, Me, Ok, PasswordChange

router = APIRouter(prefix="/auth", tags=["auth"])

COOKIE_NAME = "kas_session"
SESSION_DAYS = 30
DEFAULT_PASSWORD = "elang79"

pwd = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")


async def get_app_settings() -> dict:
    """Lazily create the singleton settings doc (password hash + session secret)."""
    doc = await db.settings.find_one({"_id": "app"})
    if doc:
        return doc
    doc = {
        "_id": "app",
        "password_hash": pwd.hash(DEFAULT_PASSWORD),
        "session_secret": secrets.token_hex(32),
    }
    try:
        await db.settings.insert_one(doc)
    except DuplicateKeyError:
        pass
    created = await db.settings.find_one({"_id": "app"})
    if created is None:  # pragma: no cover — insert just happened
        raise HTTPException(status_code=500, detail="Pengaturan aplikasi tidak tersedia")
    return created


async def require_auth(request: Request) -> None:
    """FastAPI dependency — 401 unless a valid bendahara session cookie rides the request."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Belum masuk sebagai bendahara")
    settings = await get_app_settings()
    try:
        jwt.decode(token, settings["session_secret"], algorithms=["HS256"])
    except jwt.InvalidTokenError as exc:
        raise HTTPException(status_code=401, detail="Sesi berakhir — silakan masuk lagi") from exc


@router.post("/login", response_model=Ok)
async def login(body: LoginRequest, response: Response) -> Ok:
    settings = await get_app_settings()
    if not pwd.verify(body.password, settings["password_hash"]):
        raise HTTPException(status_code=401, detail="Sandi salah")
    payload = {"sub": "bendahara", "exp": datetime.now(timezone.utc) + timedelta(days=SESSION_DAYS)}
    token = jwt.encode(payload, settings["session_secret"], algorithm="HS256")
    response.set_cookie(
        COOKIE_NAME,
        token,
        httponly=True,
        samesite="lax",
        path="/",
        max_age=SESSION_DAYS * 24 * 60 * 60,
    )
    return Ok(ok=True)


@router.put("/password", response_model=Ok, dependencies=[Depends(require_auth)])
async def change_password(body: PasswordChange) -> Ok:
    """Ganti sandi bendahara: verifikasi sandi lama, simpan hash baru. Sesi aktif tetap berlaku."""
    settings = await get_app_settings()
    if not pwd.verify(body.password_lama, settings["password_hash"]):
        raise HTTPException(status_code=401, detail="Sandi lama salah")
    await db.settings.update_one(
        {"_id": "app"}, {"$set": {"password_hash": pwd.hash(body.password_baru)}}
    )
    return Ok(ok=True)


@router.get("/settings", response_model=KasSettings, dependencies=[Depends(require_auth)])
async def read_settings() -> KasSettings:
    settings = await get_app_settings()
    return KasSettings(iuran_default=int(settings.get("iuran_default", 0) or 0))


@router.put("/settings", response_model=KasSettings, dependencies=[Depends(require_auth)])
async def write_settings(body: KasSettings) -> KasSettings:
    await get_app_settings()  # pastikan dokumen ada
    await db.settings.update_one({"_id": "app"}, {"$set": {"iuran_default": body.iuran_default}})
    return body


@router.post("/logout", response_model=Ok)
async def logout(response: Response) -> Ok:
    response.delete_cookie(COOKIE_NAME, path="/")
    return Ok(ok=True)


@router.get("/me", response_model=Me)
async def me(request: Request) -> Me:
    """200 with authenticated=false (not 401) so fresh visits stay console-clean."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        return Me(authenticated=False)
    settings = await get_app_settings()
    try:
        jwt.decode(token, settings["session_secret"], algorithms=["HS256"])
        return Me(authenticated=True)
    except jwt.InvalidTokenError:
        return Me(authenticated=False)
