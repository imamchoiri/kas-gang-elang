"""Backup buku kas: satu file Excel (dibuka pengurus) atau JSON (untuk disimpan/arsip)."""

import json
from datetime import datetime
from io import BytesIO

from fastapi import APIRouter, Depends, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font
from pydantic import ValidationError
from pymongo import ASCENDING

from lib.audit import catat_audit
from lib.dates import today_iso
from lib.db import db
from models.kas import Resident, RestoreResult, Transaction
from routers.auth import require_auth

router = APIRouter(prefix="/backup", tags=["backup"], dependencies=[Depends(require_auth)])

RUPIAH_FMT = '"Rp "#,##0'
XLSX_MEDIA = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


async def _semua_data() -> tuple[list[dict], list[dict], int]:
    txs = (
        await db.transactions.find({}, {"_id": 0})
        .sort([("date", ASCENDING), ("created_at", ASCENDING)])
        .to_list(100000)
    )
    residents = await db.residents.find({}, {"_id": 0}).sort([("nama", ASCENDING)]).to_list(5000)
    settings = await db.settings.find_one({"_id": "app"}) or {}
    return txs, residents, int(settings.get("iuran_default", 0) or 0)


@router.get("/excel")
async def backup_excel() -> StreamingResponse:
    """Seluruh buku kas dalam satu .xlsx: semua transaksi + daftar warga + ringkasan."""
    txs, residents, iuran_default = await _semua_data()
    masuk = sum(t["amount"] for t in txs if t["type"] == "masuk")
    keluar = sum(t["amount"] for t in txs if t["type"] == "keluar")

    wb = Workbook()
    bold = Font(bold=True)

    ws = wb.active
    ws.title = "Ringkasan"
    ws["A1"] = "Backup Buku Kas Gang Elang 79"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Tanggal backup: {today_iso('Asia/Jakarta')}"
    rows = [
        ("Jumlah transaksi", len(txs), None),
        ("Jumlah warga terdaftar", len(residents), None),
        ("Target iuran default", iuran_default, RUPIAH_FMT),
        ("Total pemasukan", masuk, RUPIAH_FMT),
        ("Total pengeluaran", keluar, RUPIAH_FMT),
        ("Saldo kas", masuk - keluar, RUPIAH_FMT),
    ]
    for i, (label, value, fmt) in enumerate(rows, start=4):
        ws[f"A{i}"] = label
        ws[f"A{i}"].font = bold
        ws[f"B{i}"] = value
        if fmt:
            ws[f"B{i}"].number_format = fmt
    ws.column_dimensions["A"].width = 26
    ws.column_dimensions["B"].width = 18

    ws2 = wb.create_sheet("Semua Transaksi")
    ws2.append(["Tanggal", "Jenis", "Kategori", "Nama Warga", "Keterangan", "Jumlah (Rp)", "Foto"])
    for cell in ws2[1]:
        cell.font = bold
    for t in txs:
        ws2.append(
            [
                "/".join(t["date"].split("-")[::-1]),
                "Pemasukan" if t["type"] == "masuk" else "Pengeluaran",
                t.get("category") or "-",
                (t.get("warga") or "").strip() or "-",
                t.get("description") or "-",
                t["amount"],
                "Ada" if t.get("photo_id") else "-",
            ]
        )
    for row in ws2.iter_rows(min_row=2, min_col=6, max_col=6):
        row[0].number_format = RUPIAH_FMT
    ws2.freeze_panes = "A2"
    for col, width in zip("ABCDEFG", (12, 13, 20, 20, 40, 15, 8)):
        ws2.column_dimensions[col].width = width

    ws3 = wb.create_sheet("Daftar Warga")
    ws3.append(["Nama Warga", "Target Iuran per Bulan (Rp)", "Terdaftar Sejak"])
    for cell in ws3[1]:
        cell.font = bold
    for r in residents:
        created = r.get("created_at")
        ws3.append(
            [
                r["nama"],
                int(r.get("iuran_bulanan", 0) or 0),
                created.strftime("%d/%m/%Y") if isinstance(created, datetime) else "-",
            ]
        )
    for row in ws3.iter_rows(min_row=2, min_col=2, max_col=2):
        row[0].number_format = RUPIAH_FMT
    ws3.freeze_panes = "A2"
    for col, width in zip("ABC", (28, 26, 16)):
        ws3.column_dimensions[col].width = width

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    tanggal = today_iso("Asia/Jakarta")
    return StreamingResponse(
        buf,
        media_type=XLSX_MEDIA,
        headers={"Content-Disposition": f'attachment; filename="backup-kas-gang-elang-79-{tanggal}.xlsx"'},
    )


@router.post("/restore", response_model=RestoreResult)
async def restore_backup(file: UploadFile) -> RestoreResult:
    """Pulihkan backup JSON — SELURUH transaksi & daftar warga saat ini diganti."""
    raw = await file.read()
    if not raw:
        raise HTTPException(status_code=422, detail="File backup kosong")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HTTPException(status_code=422, detail="File bukan JSON yang sah") from exc
    if not isinstance(payload, dict) or not isinstance(payload.get("transaksi"), list):
        raise HTTPException(
            status_code=422,
            detail="Struktur backup tidak dikenali — gunakan file hasil Backup JSON aplikasi ini",
        )

    # Validasi dulu; kalau isinya rusak, data lama tidak disentuh.
    txs: list[dict] = []
    dilewati = 0
    foto_hilang = 0
    for item in payload["transaksi"]:
        try:
            tx = Transaction(**item)
        except ValidationError:
            dilewati += 1
            continue
        if tx.photo_id and not await db.photos.find_one({"id": tx.photo_id}, {"_id": 1}):
            tx.photo_id = ""  # foto tidak ikut dalam backup — buang rujukan yang menggantung
            foto_hilang += 1
        txs.append(tx.model_dump())

    residents: list[dict] = []
    for item in payload.get("warga") or []:
        try:
            residents.append(Resident(**item).model_dump())
        except ValidationError:
            dilewati += 1

    await db.transactions.delete_many({})
    await db.residents.delete_many({})
    if txs:
        await db.transactions.insert_many(txs)
    if residents:
        await db.residents.insert_many(residents)

    iuran = (payload.get("pengaturan") or {}).get("iuran_default")
    if isinstance(iuran, int):
        await db.settings.update_one({"_id": "app"}, {"$set": {"iuran_default": iuran}})

    await catat_audit(
        "pulihkan",
        "backup",
        f"Pulihkan backup: {len(txs)} transaksi, {len(residents)} warga",
        f"{dilewati} baris dilewati, {foto_hilang} foto bukti tidak tersedia"
        if (dilewati or foto_hilang)
        else "Seluruh baris berhasil dipulihkan",
    )
    return RestoreResult(
        transaksi=len(txs), warga=len(residents), dilewati=dilewati, foto_hilang=foto_hilang
    )


@router.get("/json")
async def backup_json() -> StreamingResponse:
    """Backup mentah (JSON) — lengkap dan mudah diarsipkan. Sandi tidak disertakan."""
    txs, residents, iuran_default = await _semua_data()
    tanggal = today_iso("Asia/Jakarta")
    payload = {
        "aplikasi": "Kas Gang Elang 79",
        "versi_backup": 1,
        "dibuat_pada": datetime.now().astimezone().isoformat(),
        "pengaturan": {"iuran_default": iuran_default},
        "warga": residents,
        "transaksi": txs,
    }
    data = json.dumps(payload, ensure_ascii=False, indent=2, default=str).encode("utf-8")
    return StreamingResponse(
        BytesIO(data),
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="backup-kas-gang-elang-79-{tanggal}.json"'},
    )
