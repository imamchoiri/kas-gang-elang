"""Cash transactions: list, record, edit, delete, export — behind the bendahara session."""

import uuid
from datetime import datetime, timezone
from io import BytesIO
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font
from pymongo import ASCENDING, DESCENDING

from lib.audit import catat_audit, rupiah
from lib.db import db
from models.kas import BulkResult, Ok, Transaction, TransactionCreate
from routers.auth import require_auth

router = APIRouter(prefix="/transactions", tags=["transactions"], dependencies=[Depends(require_auth)])

BULAN_EXPORT = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]


@router.get("", response_model=List[Transaction])
async def list_transactions() -> List[Transaction]:
    docs = (
        await db.transactions.find()
        .sort([("date", DESCENDING), ("created_at", DESCENDING)])
        .to_list(5000)
    )
    return [Transaction(**doc) for doc in docs]


async def _ensure_photo(photo_id: str) -> None:
    if photo_id and not await db.photos.find_one({"id": photo_id}, {"_id": 1}):
        raise HTTPException(status_code=422, detail="Foto bukti tidak ditemukan")


def _ringkas(tx: Transaction) -> str:
    jenis = "Pemasukan" if tx.type == "masuk" else "Pengeluaran"
    bagian = [f"{jenis} {rupiah(tx.amount)}", tx.date]
    if tx.warga:
        bagian.append(tx.warga)
    if tx.description:
        bagian.append(tx.description)
    return " · ".join(bagian)


@router.post("", response_model=Transaction, status_code=201)
async def create_transaction(body: TransactionCreate) -> Transaction:
    await _ensure_photo(body.photo_id)
    tx = Transaction(**body.model_dump())
    await db.transactions.insert_one(tx.model_dump())
    await catat_audit("tambah", "transaksi", f"Catat {_ringkas(tx)}")
    return tx


@router.post("/bulk", response_model=BulkResult, status_code=201)
async def create_transactions_bulk(items: list[TransactionCreate]) -> BulkResult:
    """Catat beberapa transaksi sekaligus — dipakai 'Tandai Lunas Massal'."""
    if not items:
        raise HTTPException(status_code=422, detail="Tidak ada transaksi untuk dicatat")
    if len(items) > 200:
        raise HTTPException(status_code=422, detail="Maksimal 200 transaksi sekali kirim")
    txs = []
    for body in items:
        await _ensure_photo(body.photo_id)
        txs.append(Transaction(**body.model_dump()))
    await db.transactions.insert_many([t.model_dump() for t in txs])
    total = sum(t.amount for t in txs)
    nama = ", ".join(t.warga for t in txs if t.warga) or "-"
    await catat_audit(
        "tambah",
        "transaksi",
        f"Tandai lunas massal {len(txs)} warga · {rupiah(total)}",
        f"Warga: {nama}",
    )
    return BulkResult(dibuat=len(txs), ids=[t.id for t in txs])


@router.put("/{tx_id}", response_model=Transaction)
async def update_transaction(tx_id: str, body: TransactionCreate) -> Transaction:
    existing = await db.transactions.find_one({"id": tx_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Transaksi tidak ditemukan")
    await _ensure_photo(body.photo_id)
    updated = Transaction(
        id=tx_id,
        type=body.type,
        category=body.category,
        amount=body.amount,
        description=body.description,
        date=body.date,
        photo_id=body.photo_id,
        warga=body.warga,
        created_at=existing.get("created_at", datetime.now(timezone.utc)),
    )
    await db.transactions.replace_one({"id": tx_id}, updated.model_dump())
    sebelum = Transaction(**existing)
    await catat_audit(
        "ubah",
        "transaksi",
        f"Ubah {_ringkas(updated)}",
        f"Sebelumnya: {_ringkas(sebelum)}",
    )
    old_photo = existing.get("photo_id") or ""
    if old_photo and old_photo != body.photo_id:  # foto diganti/dihapus — bersihkan yang lama
        await db.photos.delete_one({"id": old_photo})
    return updated


@router.delete("/{tx_id}", response_model=Ok)
async def delete_transaction(tx_id: str) -> Ok:
    existing = await db.transactions.find_one({"id": tx_id})
    result = await db.transactions.delete_one({"id": tx_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Transaksi tidak ditemukan")
    if existing:
        await catat_audit("hapus", "transaksi", f"Hapus {_ringkas(Transaction(**existing))}")
    old_photo = (existing or {}).get("photo_id") or ""
    if old_photo:
        await db.photos.delete_one({"id": old_photo})
    return Ok(ok=True)


def _build_workbook(month: str, txs: List[Transaction]) -> BytesIO:
    """Rekap Excel dua sheet: ringkasan + rincian transaksi sebulan."""
    y, m = month.split("-")
    periode = f"{BULAN_EXPORT[int(m) - 1]} {y}"
    chronological = sorted(txs, key=lambda t: (t.date, t.created_at))
    masuk = sum(t.amount for t in txs if t.type == "masuk")
    keluar = sum(t.amount for t in txs if t.type == "keluar")
    saldo_semua = 0
    for t in txs or []:
        saldo_semua += t.amount if t.type == "masuk" else -t.amount

    wb = Workbook()
    rupiah_fmt = '"Rp "#,##0'
    bold = Font(bold=True)

    ws = wb.active
    ws.title = "Rekap"
    ws["A1"] = "Laporan Kas Gang Elang 79"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Periode: {periode}"
    ws["A4"] = "Total Pemasukan"
    ws["B4"] = masuk
    ws["A5"] = "Total Pengeluaran"
    ws["B5"] = keluar
    ws["A6"] = "Selisih Bulan Ini"
    ws["B6"] = masuk - keluar
    ws["A7"] = "Saldo Kas Saat Ini"
    ws["B7"] = saldo_semua
    for row in ("B4", "B5", "B6", "B7"):
        ws[row].number_format = rupiah_fmt
    for row in ("A4", "A5", "A6", "A7"):
        ws[row].font = bold

    ws["A9"] = "Rincian per Kategori Pemasukan"
    ws["A9"].font = bold
    row_idx = 10
    kategori_tercatat: dict[str, int] = {}
    for t in chronological:
        if t.type == "masuk":
            kategori_tercatat[t.category] = kategori_tercatat.get(t.category, 0) + t.amount
    for kategori in ("Uang Kas", "Donatur", "Denda Kerja Bhakti", "Denda Ronda", "Kolektif Warga"):
        ws[f"A{row_idx}"] = kategori
        ws[f"B{row_idx}"] = kategori_tercatat.get(kategori, 0)
        ws[f"B{row_idx}"].number_format = rupiah_fmt
        row_idx += 1

    row_idx += 1
    ws[f"A{row_idx}"] = "Rincian Pengeluaran"
    ws[f"A{row_idx}"].font = bold
    row_idx += 1
    pengeluaran: dict[str, int] = {}
    for t in chronological:
        if t.type == "keluar":
            k = t.category or "Lain-lain"
            pengeluaran[k] = pengeluaran.get(k, 0) + t.amount
    if pengeluaran:
        for k, v in sorted(pengeluaran.items()):
            ws[f"A{row_idx}"] = k
            ws[f"B{row_idx}"] = v
            ws[f"B{row_idx}"].number_format = rupiah_fmt
            row_idx += 1
    else:
        ws[f"A{row_idx}"] = "Tidak ada"
        row_idx += 1

    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 16

    ws2 = wb.create_sheet("Transaksi")
    headers = ["Tanggal", "Jenis", "Kategori", "Keterangan", "Jumlah (Rp)", "Foto Bukti"]
    ws2.append(headers)
    for cell in ws2[1]:
        cell.font = bold
    for t in chronological:
        ws2.append(
            [
                "/".join(t.date.split("-")[::-1]),
                "Pemasukan" if t.type == "masuk" else "Pengeluaran",
                t.category or "-",
                t.description or "-",
                t.amount,
                "Ada" if t.photo_id else "-",
            ]
        )
    for row in ws2.iter_rows(min_row=2, min_col=5, max_col=5):
        row[0].number_format = rupiah_fmt
    ws2.freeze_panes = "A2"
    for col, width in zip("ABCDEF", (12, 12, 18, 42, 14, 10)):
        ws2.column_dimensions[col].width = width

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def _build_year_workbook(year: str, txs: List[Transaction]) -> BytesIO:
    """Laporan tahunan satu halaman: ringkasan, tabel 12 bulan, kategori, dan setoran warga."""
    chronological = sorted(txs, key=lambda t: (t.date, t.created_at))
    masuk = sum(t.amount for t in txs if t.type == "masuk")
    keluar = sum(t.amount for t in txs if t.type == "keluar")

    wb = Workbook()
    rupiah_fmt = '"Rp "#,##0'
    bold = Font(bold=True)

    ws = wb.active
    ws.title = f"Laporan {year}"
    ws["A1"] = "Laporan Tahunan Kas Gang Elang 79"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Tahun: {year}"

    ws["A4"] = "Total Pemasukan"
    ws["B4"] = masuk
    ws["A5"] = "Total Pengeluaran"
    ws["B5"] = keluar
    ws["A6"] = "Selisih Tahun Ini"
    ws["B6"] = masuk - keluar
    for r in ("A4", "A5", "A6"):
        ws[r].font = bold
    for r in ("B4", "B5", "B6"):
        ws[r].number_format = rupiah_fmt

    row = 8
    ws[f"A{row}"] = "Rekap per Bulan"
    ws[f"A{row}"].font = bold
    row += 1
    for head, col in zip(("Bulan", "Pemasukan", "Pengeluaran", "Selisih"), "ABCD"):
        ws[f"{col}{row}"] = head
        ws[f"{col}{row}"].font = bold
    row += 1
    for i, nama_bulan in enumerate(BULAN_EXPORT, start=1):
        key = f"{year}-{i:02d}"
        bulan_txs = [t for t in chronological if t.date.startswith(key)]
        m = sum(t.amount for t in bulan_txs if t.type == "masuk")
        k = sum(t.amount for t in bulan_txs if t.type == "keluar")
        ws[f"A{row}"] = nama_bulan
        ws[f"B{row}"] = m
        ws[f"C{row}"] = k
        ws[f"D{row}"] = m - k
        for col in "BCD":
            ws[f"{col}{row}"].number_format = rupiah_fmt
        row += 1

    row += 1
    ws[f"A{row}"] = "Total Pemasukan per Kategori"
    ws[f"A{row}"].font = bold
    row += 1
    per_kategori: dict[str, int] = {}
    for t in chronological:
        if t.type == "masuk":
            per_kategori[t.category] = per_kategori.get(t.category, 0) + t.amount
    for kategori in ("Uang Kas", "Donatur", "Denda Kerja Bhakti", "Denda Ronda", "Kolektif Warga"):
        ws[f"A{row}"] = kategori
        ws[f"B{row}"] = per_kategori.get(kategori, 0)
        ws[f"B{row}"].number_format = rupiah_fmt
        row += 1

    row += 1
    ws[f"A{row}"] = "Setoran per Warga"
    ws[f"A{row}"].font = bold
    row += 1
    per_warga: dict[str, int] = {}
    for t in chronological:
        nama = (t.warga or "").strip()
        if t.type == "masuk" and nama:
            per_warga[nama] = per_warga.get(nama, 0) + t.amount
    if per_warga:
        for nama, total in sorted(per_warga.items(), key=lambda kv: (-kv[1], kv[0])):
            ws[f"A{row}"] = nama
            ws[f"B{row}"] = total
            ws[f"B{row}"].number_format = rupiah_fmt
            row += 1
    else:
        ws[f"A{row}"] = "Belum ada setoran bernama warga"
        row += 1

    for col, width in zip("ABCD", (30, 16, 16, 16)):
        ws.column_dimensions[col].width = width

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


@router.get("/export")
async def export_rekap(
    month: str | None = Query(default=None, pattern=r"^\d{4}-\d{2}$"),
    year: str | None = Query(default=None, pattern=r"^\d{4}$"),
) -> StreamingResponse:
    """Unduh rekap sebulan (`month=YYYY-MM`) atau laporan setahun (`year=YYYY`) sebagai .xlsx."""
    if (month is None) == (year is None):
        raise HTTPException(status_code=422, detail="Kirim salah satu: month=YYYY-MM atau year=YYYY")
    prefix = month or year
    docs = (
        await db.transactions.find({"date": {"$regex": f"^{prefix}"}})
        .sort([("date", ASCENDING), ("created_at", ASCENDING)])
        .to_list(5000)
    )
    txs = [Transaction(**doc) for doc in docs]
    if month:
        buf = _build_workbook(month, txs)
        filename = f"rekap-kas-gang-elang-79-{month}.xlsx"
    else:
        buf = _build_year_workbook(str(year), txs)
        filename = f"laporan-tahunan-kas-gang-elang-79-{year}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )

