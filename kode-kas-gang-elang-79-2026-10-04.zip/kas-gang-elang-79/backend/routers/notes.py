"""Catatan rapat warga — satu catatan per tahun laporan."""

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Path

from lib.db import db
from models.kas import MeetingNote, NoteInput
from routers.auth import require_auth

router = APIRouter(prefix="/notes", tags=["notes"], dependencies=[Depends(require_auth)])

YEAR_PATTERN = r"^\d{4}$"


@router.get("/{year}", response_model=MeetingNote)
async def read_note(year: str = Path(pattern=YEAR_PATTERN)) -> MeetingNote:
    doc = await db.notes.find_one({"year": year})
    if not doc:
        return MeetingNote(year=year, text="")
    return MeetingNote(**doc)


@router.put("/{year}", response_model=MeetingNote)
async def write_note(body: NoteInput, year: str = Path(pattern=YEAR_PATTERN)) -> MeetingNote:
    note = MeetingNote(year=year, text=body.text, updated_at=datetime.now(timezone.utc))
    await db.notes.replace_one({"year": year}, note.model_dump(), upsert=True)
    return note
