"""Foto bukti transaksi: upload, serve, hapus — disimpan sebagai bytes di Mongo (koleksi `photos`)."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile
from pymongo import ASCENDING

from lib.db import db
from models.kas import Ok, PhotoRef
from routers.auth import require_auth

router = APIRouter(prefix="/photos", tags=["photos"], dependencies=[Depends(require_auth)])

MAX_BYTES = 12 * 1024 * 1024  # 12 MB — klien mengompres sebelum mengirim
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"}


@router.post("", response_model=PhotoRef, status_code=201)
async def upload_photo(file: UploadFile) -> PhotoRef:
    content_type = file.content_type or ""
    if content_type not in ALLOWED_TYPES:
        raise HTTPException(status_code=422, detail="File harus berupa foto (JPG/PNG/WebP/HEIC)")
    data = await file.read()
    if not data:
        raise HTTPException(status_code=422, detail="Foto kosong")
    if len(data) > MAX_BYTES:
        raise HTTPException(status_code=422, detail="Ukuran foto terlalu besar (maks 12 MB)")
    photo_id = str(uuid.uuid4())
    await db.photos.insert_one(
        {
            "id": photo_id,
            "data": data,
            "content_type": content_type,
            "created_at": datetime.now(timezone.utc),
        }
    )
    return PhotoRef(id=photo_id)


@router.get("/{photo_id}")
async def get_photo(photo_id: str) -> Response:
    doc = await db.photos.find_one({"id": photo_id}, {"data": 1, "content_type": 1})
    if not doc:
        raise HTTPException(status_code=404, detail="Foto tidak ditemukan")
    return Response(
        content=doc["data"],
        media_type=doc.get("content_type", "image/jpeg"),
        headers={"Cache-Control": "private, max-age=86400"},
    )


@router.delete("/{photo_id}", response_model=Ok)
async def delete_photo(photo_id: str) -> Ok:
    await db.photos.delete_one({"id": photo_id})
    return Ok(ok=True)
