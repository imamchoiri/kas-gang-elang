"""Daftar warga tetap + target iuran bulanan — di belakang sesi bendahara."""

from typing import List

from fastapi import APIRouter, Depends, HTTPException
from pymongo import ASCENDING

from lib.audit import catat_audit, rupiah
from lib.db import db
from models.kas import ImportResult, Ok, Resident, ResidentCreate
from routers.auth import require_auth

router = APIRouter(prefix="/residents", tags=["residents"], dependencies=[Depends(require_auth)])


async def _nama_dipakai(nama: str, kecuali_id: str = "") -> bool:
    """Cegah nama ganda (tanpa peduli besar/kecil huruf)."""
    docs = await db.residents.find({}, {"id": 1, "nama": 1}).to_list(5000)
    target = nama.casefold()
    return any(d["nama"].casefold() == target and d["id"] != kecuali_id for d in docs)


@router.get("", response_model=List[Resident])
async def list_residents() -> List[Resident]:
    docs = await db.residents.find().sort([("nama", ASCENDING)]).to_list(5000)
    return [Resident(**doc) for doc in docs]


@router.post("", response_model=Resident, status_code=201)
async def create_resident(body: ResidentCreate) -> Resident:
    if await _nama_dipakai(body.nama):
        raise HTTPException(status_code=409, detail="Nama warga sudah terdaftar")
    warga = Resident(**body.model_dump())
    await db.residents.insert_one(warga.model_dump())
    await catat_audit(
        "tambah",
        "warga",
        f"Tambah warga {warga.nama}",
        f"Target iuran {rupiah(warga.iuran_bulanan)}/bulan" if warga.iuran_bulanan else "Tanpa target",
    )
    return warga


@router.put("/{resident_id}", response_model=Resident)
async def update_resident(resident_id: str, body: ResidentCreate) -> Resident:
    existing = await db.residents.find_one({"id": resident_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Warga tidak ditemukan")
    if await _nama_dipakai(body.nama, kecuali_id=resident_id):
        raise HTTPException(status_code=409, detail="Nama warga sudah terdaftar")
    updated = Resident(
        id=resident_id,
        nama=body.nama,
        iuran_bulanan=body.iuran_bulanan,
        created_at=existing.get("created_at"),
    )
    await db.residents.replace_one({"id": resident_id}, updated.model_dump())
    await catat_audit(
        "ubah",
        "warga",
        f"Ubah data warga {updated.nama}",
        f"Sebelumnya: {existing.get('nama')} · target {rupiah(int(existing.get('iuran_bulanan', 0) or 0))}"
        f" → sekarang target {rupiah(updated.iuran_bulanan)}",
    )
    return updated


@router.delete("/{resident_id}", response_model=Ok)
async def delete_resident(resident_id: str) -> Ok:
    existing = await db.residents.find_one({"id": resident_id}, {"nama": 1})
    result = await db.residents.delete_one({"id": resident_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Warga tidak ditemukan")
    await catat_audit("hapus", "warga", f"Hapus warga {(existing or {}).get('nama', '-')} dari daftar")
    return Ok(ok=True)


@router.post("/import", response_model=ImportResult)
async def import_from_transactions() -> ImportResult:
    """Daftarkan nama warga yang sudah pernah muncul di transaksi pemasukan."""
    from routers.auth import get_app_settings  # hindari impor melingkar saat modul dimuat

    settings = await get_app_settings()
    default_iuran = int(settings.get("iuran_default", 0) or 0)

    txs = await db.transactions.find({"type": "masuk"}, {"warga": 1}).to_list(5000)
    nama_tx = {t["warga"].strip() for t in txs if (t.get("warga") or "").strip()}
    if not nama_tx:
        return ImportResult(ditambahkan=0)

    sudah = {d["nama"].casefold() for d in await db.residents.find({}, {"nama": 1}).to_list(5000)}
    baru = [Resident(nama=n, iuran_bulanan=default_iuran) for n in sorted(nama_tx) if n.casefold() not in sudah]
    if baru:
        await db.residents.insert_many([w.model_dump() for w in baru])
        await catat_audit(
            "tambah", "warga", f"Impor {len(baru)} nama warga dari transaksi",
            ", ".join(w.nama for w in baru),
        )
    return ImportResult(ditambahkan=len(baru))
