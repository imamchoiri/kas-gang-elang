"""Unduh seluruh kode sumber aplikasi sebagai satu file ZIP (hanya untuk bendahara)."""

import os
import zipfile
from io import BytesIO
from pathlib import Path

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse

from lib.dates import today_iso
from routers.auth import require_auth

router = APIRouter(prefix="/kode-sumber", tags=["kode-sumber"], dependencies=[Depends(require_auth)])

PROJECT_ROOT = Path(__file__).resolve().parents[2]  # /app

# Folder berat / hasil build / rahasia — tidak perlu ikut dalam arsip kode.
SKIP_DIRS = {
    "node_modules",
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
    ".vite",
    ".cache",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".screenshots",
    "test_reports",
    ".yarn",
}
SKIP_SUFFIXES = {".pyc", ".pyo", ".log", ".zip", ".swp", ".db"}
MAX_FILE_BYTES = 5 * 1024 * 1024  # lewati file raksasa (mis. aset biner tak terduga)


def _ikut(path: Path) -> bool:
    name = path.name
    if name.startswith(".env"):  # kredensial tidak pernah diikutkan
        return False
    if path.suffix.lower() in SKIP_SUFFIXES:
        return False
    return path.stat().st_size <= MAX_FILE_BYTES


def _buat_zip() -> BytesIO:
    buf = BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            root_path = Path(root)
            for nama in sorted(files):
                berkas = root_path / nama
                try:
                    if not _ikut(berkas):
                        continue
                    zf.write(berkas, arcname=str(Path("kas-gang-elang-79") / berkas.relative_to(PROJECT_ROOT)))
                except OSError:
                    continue  # symlink rusak / file hilang saat berjalan — lewati saja
        zf.writestr(
            "kas-gang-elang-79/CATATAN-UNDUHAN.txt",
            "Arsip kode sumber aplikasi Kas Gang Elang 79.\n"
            "File .env (sandi & kredensial), node_modules, dan hasil build TIDAK disertakan.\n"
            "Cara menjalankan: lihat README.md di dalam arsip ini.\n",
        )
    buf.seek(0)
    return buf


@router.get("/zip")
async def unduh_kode_sumber() -> StreamingResponse:
    """Seluruh file kode proyek (backend + frontend) dalam satu .zip."""
    buf = _buat_zip()
    tanggal = today_iso("Asia/Jakarta")
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="kode-kas-gang-elang-79-{tanggal}.zip"'
        },
    )
