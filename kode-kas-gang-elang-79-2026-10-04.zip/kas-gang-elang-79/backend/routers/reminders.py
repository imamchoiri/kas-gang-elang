"""Penjadwal pengingat iuran: endpoint cron + pembacaan pengingat oleh beranda.

Pengingat TIDAK dikirim otomatis ke WhatsApp (butuh layanan pihak ketiga).
Penjadwal hanya MENYIAPKAN teksnya; bendahara mengirim sekali ketuk dari beranda.
"""

import os
import secrets as pysecrets
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException, Path, Request
from pymongo import ASCENDING, DESCENDING

from lib.audit import catat_audit, rupiah
from lib.dates import today_iso
from lib.db import db
from models.kas import Reminder, ReminderState
from routers.auth import require_auth

cron_router = APIRouter(prefix="/cron", tags=["cron"])
router = APIRouter(prefix="/reminders", tags=["reminders"], dependencies=[Depends(require_auth)])

MONTH_PATTERN = r"^\d{4}-\d{2}$"
BULAN = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember",
]


async def _susun_pengingat(month: str) -> Reminder:
    """Hitung warga yang belum lunas pada `month` lalu susun pesan sopan."""
    residents = await db.residents.find({}, {"_id": 0}).sort([("nama", ASCENDING)]).to_list(5000)
    txs = await db.transactions.find({"type": "masuk", "date": {"$regex": f"^{month}"}}).to_list(5000)

    dibayar: dict[str, int] = {}
    for t in txs:
        nama = (t.get("warga") or "").strip().casefold()
        if nama:
            dibayar[nama] = dibayar.get(nama, 0) + int(t["amount"])

    belum: list[tuple[str, int]] = []
    total_kurang = 0
    lunas = 0
    for w in residents:
        target = int(w.get("iuran_bulanan", 0) or 0)
        bayar = dibayar.get(w["nama"].strip().casefold(), 0)
        if (target > 0 and bayar >= target) or (target == 0 and bayar > 0):
            lunas += 1
            continue
        kurang = max(0, target - bayar)
        total_kurang += kurang
        belum.append((w["nama"], kurang))

    y, m = month.split("-")
    periode = f"{BULAN[int(m) - 1]} {y}"
    lines = [
        "🙏 *Pengingat Iuran Kas Gang Elang 79*",
        f"Periode: {periode}",
        "",
        "Assalamualaikum / salam sejahtera Bapak/Ibu warga Gang Elang 79.",
        "Mohon maaf mengganggu, berikut pengingat iuran kas bulan ini:",
        "",
    ]
    if not belum:
        lines.append("✅ Alhamdulillah seluruh warga sudah menyetor iuran bulan ini.")
        lines.append("Terima kasih banyak atas kerja samanya 🙏")
    else:
        for i, (nama, kurang) in enumerate(belum, start=1):
            lines.append(f"{i}. {nama}" + (f" — kurang {rupiah(kurang)}" if kurang > 0 else ""))
        lines.append("")
        if total_kurang > 0:
            lines.append(f"Total yang belum masuk: *{rupiah(total_kurang)}*")
        lines.append("Jika sudah menyetor namun masih tercatat di sini, mohon kabari bendahara ya 🙏")
        lines.append("Terima kasih atas perhatian dan kerja samanya.")
    lines.append("")
    lines.append(f"Sudah setor bulan ini: {lunas}/{len(residents)} warga")

    return Reminder(
        month=month,
        text="\n".join(lines),
        belum_lunas=len(belum),
        total_kurang=total_kurang,
        created_at=datetime.now(timezone.utc),
    )


async def _kerjakan_pengingat(month: str, run_id: str) -> None:
    """Pekerjaan asli cron — dijalankan di background setelah endpoint meng-ack."""
    reminder = await _susun_pengingat(month)
    doc = reminder.model_dump()
    doc["run_id"] = run_id
    await db.reminders.replace_one({"month": month}, doc, upsert=True)
    await catat_audit(
        "tambah",
        "pengingat",
        f"Pengingat iuran {month} disiapkan otomatis",
        f"{reminder.belum_lunas} warga belum lunas, kurang {rupiah(reminder.total_kurang)}",
    )


@cron_router.post("/pengingat-iuran", status_code=202)
async def cron_pengingat_iuran(
    request: Request,
    background: BackgroundTasks,
    authorization: str | None = Header(default=None),
    x_webhook_id: str | None = Header(default=None),
) -> dict:
    # Cron endpoints must ack 2xx immediately; enqueue/background the actual work.
    secret = os.environ.get("WEBHOOK_CRON_SECRET", "")
    token = ""
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    if not secret or not token or not pysecrets.compare_digest(token, secret):
        raise HTTPException(status_code=401, detail="Unauthorized")

    try:
        envelope = await request.json()
    except Exception:  # noqa: BLE001 — body boleh kosong
        envelope = {}
    if envelope is not None and not isinstance(envelope, dict):
        raise HTTPException(status_code=400, detail="Body tidak sah")

    run_id = x_webhook_id or (envelope or {}).get("run_id") or ""
    if run_id:
        sudah = await db.cron_runs.find_one({"run_id": run_id})
        if sudah:
            return {"status": "duplicate", "run_id": run_id}
        await db.cron_runs.insert_one(
            {"run_id": run_id, "at": datetime.now(timezone.utc), "job": "pengingat-iuran"}
        )

    month = today_iso("Asia/Jakarta")[:7]
    background.add_task(_kerjakan_pengingat, month, run_id)
    return {"status": "accepted", "month": month, "run_id": run_id}


@router.get("/current", response_model=ReminderState)
async def pengingat_terkini() -> ReminderState:
    """Pengingat bulan berjalan yang belum ditandai terkirim (untuk banner beranda)."""
    month = today_iso("Asia/Jakarta")[:7]
    doc = await db.reminders.find_one({"month": month, "sent_at": None}, {"_id": 0})
    return ReminderState(reminder=Reminder(**doc) if doc else None)


@router.get("", response_model=list[Reminder])
async def daftar_pengingat() -> list[Reminder]:
    docs = await db.reminders.find({}, {"_id": 0}).sort([("month", DESCENDING)]).to_list(60)
    return [Reminder(**d) for d in docs]


@router.post("/{month}/sent", response_model=Reminder)
async def tandai_terkirim(month: str = Path(pattern=MONTH_PATTERN)) -> Reminder:
    doc = await db.reminders.find_one({"month": month})
    if not doc:
        raise HTTPException(status_code=404, detail="Pengingat tidak ditemukan")
    now = datetime.now(timezone.utc)
    await db.reminders.update_one({"month": month}, {"$set": {"sent_at": now}})
    await catat_audit("kirim", "pengingat", f"Pengingat iuran {month} ditandai sudah dikirim")
    doc["sent_at"] = now
    doc.pop("_id", None)
    return Reminder(**doc)


@router.post("/siapkan", response_model=Reminder)
async def siapkan_sekarang() -> Reminder:
    """Susun ulang pengingat bulan ini tanpa menunggu tanggal 10."""
    month = today_iso("Asia/Jakarta")[:7]
    reminder = await _susun_pengingat(month)
    await db.reminders.replace_one({"month": month}, reminder.model_dump(), upsert=True)
    await catat_audit("tambah", "pengingat", f"Pengingat iuran {month} disusun manual")
    return reminder
